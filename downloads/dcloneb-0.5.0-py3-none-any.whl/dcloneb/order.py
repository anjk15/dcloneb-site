"""Execution order with NetworkX (plan Phase 8)."""

from typing import Optional

import networkx as nx


class InternalError(RuntimeError):
    """A bug in dcloneb, not a problem with the user's DDL."""


def execution_order(active: nx.MultiDiGraph, errors: bool = False) -> Optional[list[str]]:
    """Tables in load order: every parent before its children, ties broken by table name.

    `active` holds only the non-deferred FKs (Phase 7), so it must be acyclic. Returns None when
    the plan has blocking errors (the order isn't guessed). Self-loops never reach here: a
    self-reference is either deferred or reported as an unsupported cycle.
    """
    if errors:
        return None
    try:
        return list(nx.lexicographical_topological_sort(active, key=str))
    except nx.NetworkXUnfeasible:
        cycle = nx.find_cycle(active)
        path = " → ".join([cycle[0][0]] + [edge[1] for edge in cycle])
        raise InternalError(f"dependency graph still has a cycle after cycle breaking: {path}") from None
