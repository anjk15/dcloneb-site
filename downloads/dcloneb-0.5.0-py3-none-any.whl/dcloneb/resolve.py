"""Resolve and validate references (plan Phase 4).

Every constraint that doesn't hold up is reported and removed, so later phases can rely on
every column and FK target in the resolved schema existing.
"""

from dataclasses import replace
from typing import Optional

from dcloneb.model import Diagnostic, ForeignKey, Schema, Table


class _Resolver:
    def __init__(self, schema: Schema):
        self.schema = schema
        self.diagnostics: list[Diagnostic] = list(schema.diagnostics)
        self.tables: dict[str, Table] = {}  # pass-1 tables, by name

    def error(self, code: str, message: str, where) -> None:
        self.diagnostics.append(Diagnostic("error", code, message, where.statement, where.line))

    def missing(self, table: Table, columns, what: str, where) -> bool:
        """Report columns of `table` that don't exist; True if any are missing."""
        unknown = [c for c in columns if table.column(c) is None]
        for name in unknown:
            self.error("unknown_column", f"{table.name}: {what} names column '{name}', which {table.name} doesn't have", where)
        return bool(unknown)

    def own_keys(self, table: Table) -> Table:
        """Pass 1: the table's own PK, unique keys and CHECK columns."""
        primary_key: Optional[tuple[str, ...]] = table.primary_key
        if primary_key and self.missing(table, primary_key, f"PRIMARY KEY ({', '.join(primary_key)})", table):
            primary_key = None
        unique_keys = tuple(k for k in table.unique_keys
                            if not self.missing(table, k.columns, f"UNIQUE ({', '.join(k.columns)})", k))
        check_columns = frozenset(c for c in table.check_columns if not self.missing(table, [c], "a CHECK constraint", table))
        return replace(table, primary_key=primary_key, unique_keys=unique_keys, check_columns=check_columns)

    def with_foreign_keys(self, table: Table) -> Table:
        """Pass 2: FKs, checked against the pass-1 tables (so a parent's invalid PK doesn't count)."""
        foreign_keys = tuple(r for r in (self.foreign_key(table, fk) for fk in table.foreign_keys) if r is not None)
        return replace(table, foreign_keys=foreign_keys)

    def target_table(self, label: str, fk: ForeignKey) -> Optional[Table]:
        """Exact name first; an unqualified name may match exactly one schema-qualified table.
        A qualified name never matches an unqualified table (no search_path guessing)."""
        exact = self.tables.get(fk.ref_table)
        if exact is not None:
            return exact
        matches = [] if "." in fk.ref_table else [t for t in self.tables.values() if t.name.split(".")[-1] == fk.ref_table]
        if len(matches) == 1:
            return matches[0]
        if matches:
            self.error("fk_ambiguous_table",
                       f"{label}: '{fk.ref_table}' matches several tables ({', '.join(sorted(t.name for t in matches))})", fk)
        else:
            self.error("fk_unknown_table", f"{label}: table '{fk.ref_table}' is not defined in the DDL", fk)
        return None

    def foreign_key(self, table: Table, fk: ForeignKey) -> Optional[ForeignKey]:
        """The FK with its target resolved, or None (after reporting why) if it can't be used."""
        label = f"foreign key {table.name}({', '.join(fk.columns)}) -> {fk.ref_table}"
        if self.missing(table, fk.columns, f"FOREIGN KEY ({', '.join(fk.columns)})", fk):
            return None
        parent = self.target_table(label, fk)
        if parent is None:
            return None
        ref_columns = fk.ref_columns or parent.primary_key
        if ref_columns is None:
            self.error("fk_no_primary_key", f"{label}: no columns given and {parent.name} has no primary key", fk)
            return None
        if len(ref_columns) != len(fk.columns):
            self.error("fk_column_count",
                       f"{label}: {len(fk.columns)} column(s) reference {len(ref_columns)} column(s) ({', '.join(ref_columns)})", fk)
            return None
        unknown = [c for c in ref_columns if parent.column(c) is None]
        if unknown:
            for name in unknown:
                self.error("fk_unknown_column", f"{label}: {parent.name} has no column '{name}'", fk)
            return None
        if not any(set(key) == set(ref_columns) for key in parent.keys()):
            self.error("fk_target_not_unique",
                       f"{label}: ({', '.join(ref_columns)}) is not the primary key or a unique key of {parent.name}", fk)
            return None
        return replace(fk, ref_table=parent.name, ref_columns=tuple(ref_columns))

    def resolve(self) -> Schema:
        own = [self.own_keys(t) for t in self.schema.tables]
        self.tables = {t.name: t for t in own}
        tables = tuple(self.with_foreign_keys(t) for t in own)
        return Schema(tables=tables, diagnostics=tuple(self.diagnostics))


def resolve(schema: Schema) -> Schema:
    return _Resolver(schema).resolve()
