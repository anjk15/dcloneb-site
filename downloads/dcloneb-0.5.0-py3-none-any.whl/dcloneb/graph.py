"""Dependency graph of tables, built with NetworkX (plan Phase 6).

Edges point **parent → child** ("parent loads first"). One keyed edge per FK, so parallel FKs
between the same tables stay separate and can be deferred one at a time.
"""

import networkx as nx

from dcloneb.eligibility import fk_eligibility
from dcloneb.model import ForeignKey, Schema, Table


def fk_key(table: Table, fk: ForeignKey) -> str:
    """Stable edge key: `child.constraint_name`, or `child(cols)->parent(cols)` for unnamed FKs."""
    if fk.name:
        return f"{table.name}.{fk.name}"
    return f"{table.name}({', '.join(fk.columns)})->{fk.ref_table}({', '.join(fk.ref_columns)})"


def build_graph(schema: Schema) -> nx.MultiDiGraph:
    """Needs a resolved schema (Phase 4): every FK has a known target and ref_columns."""
    graph = nx.MultiDiGraph()
    graph.add_nodes_from(sorted(t.name for t in schema.tables))
    for table in schema.tables:
        for fk in table.foreign_keys:
            base = key = fk_key(table, fk)
            n = 1
            while graph.has_edge(fk.ref_table, table.name, key=key):  # identical unnamed FKs: keep both
                n += 1
                key = f"{base}#{n}"
            graph.add_edge(fk.ref_table, table.name, key=key,
                           child=table.name, fk=fk, eligibility=fk_eligibility(schema, table, fk))
    return graph


def components(graph: nx.MultiDiGraph) -> list[tuple[str, ...]]:
    """Strongly connected components as sorted tuples, sorted by their first table.
    NetworkX's own iteration order depends on node insertion order (spike finding), so we sort."""
    return sorted(tuple(sorted(c)) for c in nx.strongly_connected_components(graph))


def cyclic_components(graph: nx.MultiDiGraph) -> list[tuple[str, ...]]:
    """Components that contain a cycle: 2+ tables, or one table with a self-loop.
    A self-loop node is its own single-node component, so self-loops are checked separately."""
    looped = {u for u, _ in nx.selfloop_edges(graph)}
    return [c for c in components(graph) if len(c) > 1 or c[0] in looped]


def selection_key(edge) -> tuple:
    """Deterministic order for picking an FK to defer: self-loops first, then child table,
    FK columns, parent table, and the edge key as a last tie-break."""
    parent, child, key, data = edge
    return (parent != child, child, data["fk"].columns, parent, key)


def edges_within(graph: nx.MultiDiGraph, component: tuple[str, ...]) -> list[tuple]:
    """(parent, child, key, data) for every edge with both ends in `component`, in selection order."""
    members = set(component)
    inside = [e for e in graph.edges(keys=True, data=True) if e[0] in members and e[1] in members]
    return sorted(inside, key=selection_key)
