"""Cycle breaking: a deterministic, valid (not minimal) choice of FKs to backfill (plan Phase 7).

1. `active` and `search` start as copies of the dependency graph.
2. While `search` has a cyclic component, take the first one. Defer the first eligible FK inside
   it (by `graph.selection_key`): remove only that keyed edge from both graphs. If none is
   eligible, report `cycle_unsupported` and drop the component's edges from `search` only, so the
   other components are still examined.
Every step removes at least one edge from `search`, so the loop ends. On success `active` is acyclic.
"""

from dataclasses import dataclass, field

import networkx as nx

from dcloneb.eligibility import Eligibility
from dcloneb.graph import cyclic_components, edges_within
from dcloneb.model import Diagnostic, ForeignKey


FILL_AFTER = "all tables are initially loaded"
REQUIREMENT = "set null_columns so the full FK tuple equals an existing parent key; keep retained_columns unchanged"


@dataclass(frozen=True)
class Backfill:
    table: str  # the child table whose FK columns are temporarily NULL
    key: str  # the FK's edge key in the graph
    fk: ForeignKey
    eligibility: Eligibility
    cycle: tuple[str, ...]  # tables of the cyclic component this FK was deferred to break

    def to_dict(self) -> dict:
        """The plan.json backfill entry: planning metadata for the generator, never executed here."""
        fk, e = self.fk, self.eligibility
        return {
            "table": self.table,
            "foreign_key": {
                "name": fk.name,
                "columns": list(fk.columns),
                "references": {"table": fk.ref_table, "columns": list(fk.ref_columns)},
                "match": fk.match,
                "deferrable": fk.deferrable,
                "initially_deferred": fk.initially_deferred,
            },
            "null_columns": list(e.null_columns),
            "retained_columns": list(e.retained_columns),
            "fill": [{"column": child, "parent_column": parent} for child, parent in e.fill],
            "cycle": list(self.cycle),
            "fill_after": FILL_AFTER,
            "requirement": REQUIREMENT,
        }


@dataclass
class CycleBreak:
    active: nx.MultiDiGraph  # dependencies that still order the load
    backfills: list[Backfill] = field(default_factory=list)
    diagnostics: list[Diagnostic] = field(default_factory=list)


def _label(edge) -> str:
    parent, child, _, data = edge
    return f"{child}({', '.join(data['fk'].columns)}) -> {parent}"


def _cycle_path(graph: nx.MultiDiGraph, component: tuple[str, ...]) -> str:
    """One cycle through the component, in reference direction (child → parent), e.g. `a → b → a`."""
    references = graph.subgraph(component).reverse(copy=True)
    cycle = nx.find_cycle(references, source=component[0])
    return " → ".join([cycle[0][0]] + [edge[1] for edge in cycle])


def _unsupported(graph: nx.MultiDiGraph, component: tuple[str, ...], inside: list) -> Diagnostic:
    why = "; ".join(
        f"{_label(e)}: " + "; ".join(f"{col}: {', '.join(rs)}" for col, rs in e[3]["eligibility"].reasons.items())
        for e in inside
    )
    message = (f"cycle {_cycle_path(graph, component)} is unsupported by the current loading strategy: "
               f"no foreign key in it can be temporarily set to NULL. {why}.")
    deferrable = [_label(e) for e in inside if e[3]["fk"].deferrable]
    if deferrable:
        message += (f" {', '.join(deferrable)} is DEFERRABLE; deferred-constraint loading (not supported yet) "
                    "might handle this cycle.")
    first = inside[0][3]["fk"]
    return Diagnostic("error", "cycle_unsupported", message, first.statement, first.line)


def break_cycles(graph: nx.MultiDiGraph) -> CycleBreak:
    active, search = graph.copy(), graph.copy()
    result = CycleBreak(active=active)
    while True:
        cyclic = cyclic_components(search)
        if not cyclic:
            return result
        component = cyclic[0]
        inside = edges_within(search, component)
        chosen = next((e for e in inside if e[3]["eligibility"].eligible), None)
        if chosen is None:
            result.diagnostics.append(_unsupported(search, component, inside))
            search.remove_edges_from([(u, v, k) for u, v, k, _ in inside])
            continue
        parent, child, key, data = chosen
        active.remove_edge(parent, child, key=key)
        search.remove_edge(parent, child, key=key)
        result.backfills.append(Backfill(child, key, data["fk"], data["eligibility"], component))
