"""Loading a run into Databricks (plan9). The only module that writes to Databricks.

Fixed templates only, and every statement passes `check_write` before it is sent: it may create in, load into, or
read from the one target schema, and nothing else (no DROP, DELETE, UPDATE, INSERT, MERGE, TRUNCATE, or REPLACE).
"""

import re
from dataclasses import dataclass
from pathlib import Path

import sqlglot
from sqlglot import exp

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.model import ForeignKey, Table
from dcloneb.sources.databricks import Query, Runner, _query, quote, redact

PLAIN = re.compile(r"[A-Za-z0-9_-]+")  # catalog, schema, and table names: also used in volume paths, never escaped
RUN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")
VOLUME = "dcloneb_landing"
COMMENT = "Test data made by dcloneb"
CSV_OPTIONS = ("'header' = 'true', 'mode' = 'FAILFAST', 'nullValue' = '', "
               "'timestampFormat' = 'yyyy-MM-dd HH:mm:ss[XXX]', 'timestampNTZFormat' = 'yyyy-MM-dd HH:mm:ss'")
WRITE_TIMEOUT = 600.0  # seconds per statement: a COPY INTO can take longer than a profiling query
WRITE_BUDGET = 3600.0


def _fail(code: str, message: str) -> GenerationError:
    return GenerationError([Problem("input", code, message)])


@dataclass(frozen=True)
class Target:
    catalog: str
    schema: str

    def ref(self, table: str = "") -> str:
        if table and not PLAIN.fullmatch(table):
            raise _fail("push_target_invalid", f"table name {table!r} can't be loaded: use letters, digits, '_' or '-'")
        return ".".join(quote(p) for p in (self.catalog, self.schema, table) if p)

    def __str__(self) -> str:
        return f"{self.catalog}.{self.schema}"


def target(catalog: str, schema: str) -> Target:
    for what, name in (("catalog", catalog), ("schema", schema)):
        if not PLAIN.fullmatch(name or ""):
            raise _fail("push_target_invalid", f"{what} {name!r} can't be a push target: use letters, digits, '_' or '-'")
    return Target(catalog, schema)


def landing(t: Target, run: str) -> str:
    """The volume folder the run's CSVs are uploaded to."""
    if not RUN.fullmatch(run):
        raise _fail("push_target_invalid", f"run name {run!r} can't be used in a path")
    return f"/Volumes/{t.catalog}/{t.schema}/{VOLUME}/{run}"


def create_schema(t: Target) -> Query:
    return _query("create_schema", f"CREATE SCHEMA {t.ref()} COMMENT '{COMMENT}'", {})


def create_volume(t: Target) -> Query:
    return _query("create_volume", f"CREATE VOLUME IF NOT EXISTS {t.ref(VOLUME)} COMMENT '{COMMENT}: uploaded CSVs'", {})


def _type(table: str, column) -> str:
    try:
        rendered = exp.DataType.build(column.type, dialect="databricks").sql("databricks")
    except (sqlglot.errors.ParseError, ValueError):
        rendered = ""
    if re.sub(r"\s", "", rendered).upper() != re.sub(r"\s", "", column.type).upper():  # all of it, read back the same
        raise _fail("push_type_invalid", f"{table}.{column.name} has a type dcloneb can't create: {column.type!r}")
    return rendered


def create_table(t: Target, table: Table, run: str) -> Query:
    """Columns with their types and NOT NULL, and the primary key. Identity columns become plain columns: the
    generated IDs are loaded as they are. Foreign keys come after every table exists (`add_foreign_key`)."""
    parts = [f"{quote(c.name)} {_type(table.name, c)}{'' if c.nullable else ' NOT NULL'}" for c in table.columns]
    if table.primary_key:
        parts.append(f"CONSTRAINT {quote(table.name + '_pk')} PRIMARY KEY ({', '.join(map(quote, table.primary_key))})")
    landing(t, run)  # the run name is checked like a path
    return _query("create_table", f"CREATE TABLE {t.ref(table.name)} ({', '.join(parts)}) COMMENT '{COMMENT}, run {run}'", {})


def add_foreign_key(t: Target, table: Table, fk: ForeignKey, n: int) -> Query:
    return _query("add_foreign_key", f"ALTER TABLE {t.ref(table.name)} ADD CONSTRAINT {quote(f'{table.name}_fk{n}')} "
                                     f"FOREIGN KEY ({', '.join(map(quote, fk.columns))}) REFERENCES {t.ref(fk.ref_table)} "
                                     f"({', '.join(map(quote, fk.ref_columns))})", {})


def copy_into(t: Target, table: str, path: str) -> Query:
    if not (path.startswith(f"/Volumes/{t.catalog}/{t.schema}/{VOLUME}/") and re.fullmatch(r"[A-Za-z0-9._/-]+", path)):
        raise _fail("push_target_invalid", f"{path!r} isn't in the target's landing volume")
    return _query("copy_into", f"COPY INTO {t.ref(table)} FROM '{path}' FILEFORMAT = CSV FORMAT_OPTIONS ({CSV_OPTIONS})", {})


def count_rows(t: Target, table: str) -> Query:
    return _query("count_rows", f"SELECT COUNT(*) AS n FROM {t.ref(table)}", {})


def tables_named(catalog: str, names) -> Query:
    """Read-only: which schemas of `catalog` already hold a table with one of these names."""
    names = sorted(set(names))
    params = {"catalog": catalog} | {f"n{i}": n for i, n in enumerate(names)}
    return _query("tables_named", "SELECT table_schema, table_name FROM system.information_schema.tables WHERE "
                                  f"table_catalog = :catalog AND table_name IN ({', '.join(f':n{i}' for i in range(len(names)))}) "
                                  "ORDER BY table_schema, table_name", params)


def current_user() -> Query:
    return _query("current_user", "SELECT current_user() AS principal", {})


def _refused(query: Query, t: Target, why: str) -> GenerationError:
    return _fail("push_statement_refused", f"'{query.name}' wasn't sent: {why}; dcloneb only creates in, loads into, and "
                                           f"reads from {t}")


def check_write(query: Query, t: Target) -> None:
    """Refuse anything but one CREATE SCHEMA/TABLE/VOLUME, ALTER TABLE ADD CONSTRAINT, COPY INTO, or SELECT, all inside
    the target schema."""
    if query.sql == create_volume(t).sql:
        return  # sqlglot reads CREATE VOLUME as a raw command: only this exact text passes
    try:
        statements = [s for s in sqlglot.parse(query.sql, read="databricks") if s is not None]
    except sqlglot.errors.ParseError:
        statements = []
    if len(statements) != 1:
        raise _refused(query, t, "it isn't exactly one statement")
    statement = statements[0]
    allowed = (isinstance(statement, exp.Create) and statement.kind in ("SCHEMA", "TABLE") and not statement.args.get("replace")
               or isinstance(statement, exp.Alter) and all(isinstance(a, exp.AddConstraint) for a in statement.actions)
               or isinstance(statement, (exp.Copy, exp.Select)))
    if not allowed:
        raise _refused(query, t, f"a {type(statement).__name__.upper()} statement isn't allowed")
    ctes = {cte.alias for cte in statement.find_all(exp.CTE)}
    for table in statement.find_all(exp.Table):
        if not table.catalog and not table.db and table.name in ctes:
            continue  # the statement's own WITH name
        if (table.catalog, table.db) != (t.catalog, t.schema):
            raise _refused(query, t, f"it names {'.'.join(p for p in (table.catalog, table.db, table.name) if p)}")
    for literal in statement.find_all(exp.Literal):
        if literal.is_string and literal.this.startswith("/") and not literal.this.startswith(f"/Volumes/{t.catalog}/{t.schema}/"):
            raise _refused(query, t, f"it reads files from {literal.this}")


def writer(connection, t: Target) -> Runner:
    """A runner for the push: longer time limits, and the write guard instead of the read-only one."""
    return Runner(connection, WRITE_TIMEOUT, WRITE_BUDGET, check=lambda q: check_write(q, t))


# --- the least permissions, and uploads --------------------------------------------------------------------

DENIED = re.compile(r"PERMISSION_DENIED|INSUFFICIENT_PERMISSIONS|does not have|not authorized|403", re.IGNORECASE)
EXISTS = re.compile(r"ALREADY_EXISTS|already exists", re.IGNORECASE)
WAREHOUSE_GRANT = "CAN USE on the SQL warehouse (set in the warehouse's Permissions tab; it has no GRANT statement)"


def grants(principal: str, t: Target, new_schema: bool, source=None) -> dict:
    """The fewest Unity Catalog privileges a run needs, as GRANT statements: reading the source (when given), and
    pushing into a new schema (CREATE SCHEMA on the catalog) or an existing one (CREATE TABLE and CREATE VOLUME on the
    schema). What dcloneb creates it owns, so loading needs nothing more."""
    who = quote(principal)
    push = ([f"GRANT USE CATALOG, CREATE SCHEMA ON CATALOG {quote(t.catalog)} TO {who};"] if new_schema else
            [f"GRANT USE CATALOG ON CATALOG {quote(t.catalog)} TO {who};",
             f"GRANT USE SCHEMA, CREATE TABLE, CREATE VOLUME ON SCHEMA {t.ref()} TO {who};"])
    out = {"push": push, "warehouse": WAREHOUSE_GRANT}
    if source:
        catalog, schema = source
        out["read"] = [f"GRANT USE CATALOG ON CATALOG {quote(catalog)} TO {who};",
                       f"GRANT USE SCHEMA, SELECT ON SCHEMA {quote(catalog)}.{quote(schema)} TO {who};"]
    return out


def upload(files_api, local, path: str) -> None:
    """One CSV into the landing volume (the SDK's Files API), never overwriting. The folder is named after the run's
    contents, so a file already at `path` is this run's, from an earlier attempt: it is kept and used (the row counts
    are checked after loading)."""
    try:
        with Path(local).open("rb") as contents:
            files_api.upload(path, contents, overwrite=False)
    except Exception as e:
        if EXISTS.search(str(e)):
            return
        code = "push_permission_denied" if DENIED.search(str(e)) else "push_upload_failed"
        raise _fail(code, f"couldn't upload {path}: {redact(e)}") from None


def files_api(profile: str):
    """The SDK's Files API for the profile (needs `dcloneb[databricks]`); the SDK handles sign-in."""
    try:
        from databricks.sdk import WorkspaceClient
    except ImportError:
        raise _fail("connection_extra_missing", "Databricks support isn't installed: pip install 'dcloneb[databricks]'") from None
    return WorkspaceClient(profile=profile).files
