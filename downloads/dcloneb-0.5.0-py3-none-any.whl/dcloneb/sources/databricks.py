"""Databricks Unity Catalog through a SQL warehouse (plan6 A). Needs `dcloneb[databricks]`.

The Databricks CLI/SDK obtains, stores, and refreshes tokens (`databricks auth login`). dcloneb hands the SDK's
header factory to the connector, and keeps credentials out of messages, logs, and files.
"""

import configparser
import datetime as dt
import os
import re
import threading
import time
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Callable, Iterable, Optional

import sqlglot
from sqlglot import exp

from dcloneb import profile as prof
from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.support import key_columns
from dcloneb.generate.types import type_spec
from dcloneb.model import Column, Diagnostic, ForeignKey, Key, Schema, Table, short_names
from dcloneb.readers.postgres import column_type

QUERY_TIMEOUT = 60.0  # seconds per query
BUDGET = 300.0  # seconds for all queries of one runner
CANCEL_WAIT = 5.0  # seconds to let a cancelled statement return
SAMPLE_ROWS = 100_000  # profiling default: TABLESAMPLE (n ROWS); a full scan only when asked for
TOP_VALUES = 50  # values listed per approved categorical column
CONDITIONAL_KINDS = ("int", "decimal", "date")  # compared within each category (plan8); text only when approved
CONDITIONAL_MIN_ROWS = 5  # rows a category needs before a constant column in it is suggested as a rule
ID_FORMATS = {"uuid": "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
              "digits": "^[0-9]+$", "code": "^[A-Za-z]{1,10}-?[0-9]+$"}  # format checks on text key columns
WAREHOUSE_ID = re.compile(r"[0-9A-Za-z]+")
SECRET = re.compile(r"dapi[0-9a-f]{16,}|eyJ[\w-]+\.[\w-]+\.[\w-]+|Bearer\s+\S+", re.IGNORECASE)


def redact(error) -> str:
    return SECRET.sub("[redacted]", str(error))


def _fail(code: str, message: str) -> GenerationError:
    return GenerationError([Problem("input", code, message)])


def _login(profile: str) -> str:
    return f"run `databricks auth login --profile {profile}` and try again"


def connect(profile: str, warehouse_id: str, config: Optional[Callable] = None, sql_connect: Optional[Callable] = None):
    """A DB-API connection to the warehouse, authenticated by the CLI profile. `config`/`sql_connect` are for tests."""
    if not WAREHOUSE_ID.fullmatch(warehouse_id or ""):
        raise _fail("connection_warehouse_invalid",
                    f"warehouse ID {warehouse_id!r} isn't valid: use the ID from the warehouse's Connection details")
    try:
        if config is None:
            from databricks.sdk.core import Config as config
        if sql_connect is None:
            from databricks.sql import connect as sql_connect
    except ImportError:
        raise _fail("connection_extra_missing", "Databricks support isn't installed: pip install 'dcloneb[databricks]'") from None
    try:
        cfg = config(profile=profile)
    except ValueError as e:
        raise _fail("connection_profile_missing", f"Databricks profile '{profile}' isn't usable ({redact(e)}); {_login(profile)}") from None
    try:
        return sql_connect(server_hostname=cfg.hostname, http_path=f"/sql/1.0/warehouses/{warehouse_id}",
                           credentials_provider=lambda: cfg.authenticate)
    except Exception as e:
        raise _fail("connection_failed", f"couldn't connect to warehouse {warehouse_id} with profile '{profile}': "
                                         f"{redact(e)}; {_login(profile)}") from None


# --- picking a source one step at a time (plan8 A1) ------------------------------------------------------

HIDDEN_CATALOGS = {"system", "__databricks_internal"}
HIDDEN_SCHEMAS = {"information_schema"}


def list_profiles(path=None) -> list[dict]:
    """The Databricks CLI profiles in ~/.databrickscfg (or $DATABRICKS_CONFIG_FILE): names and hosts only, never
    token fields. A profile without a host isn't usable and is left out."""
    path = Path(path or os.environ.get("DATABRICKS_CONFIG_FILE") or Path.home() / ".databrickscfg")
    parser = configparser.ConfigParser(default_section="\0", interpolation=None)  # [DEFAULT] is a real profile here
    try:
        parser.read_string(path.read_text(encoding="utf-8"))
    except (OSError, configparser.Error):
        return []
    found = []
    for name in parser.sections():
        host = parser[name].get("host", "").strip()
        if host:
            found.append({"name": name, "host": re.sub(r"^https?://", "", host).rstrip("/")})
    return found


def list_warehouses(profile: str, client: Optional[Callable] = None) -> list[dict]:
    """The SQL warehouses this profile can see, running ones first. `client` (profile -> WorkspaceClient) is for tests."""
    try:
        if client is None:
            from databricks.sdk import WorkspaceClient
            client = lambda profile: WorkspaceClient(profile=profile)
    except ImportError:
        raise _fail("connection_extra_missing", "Databricks support isn't installed: pip install 'dcloneb[databricks]'") from None
    try:
        workspace = client(profile)
    except ValueError as e:
        raise _fail("connection_profile_missing", f"Databricks profile '{profile}' isn't usable ({redact(e)}); {_login(profile)}") from None
    try:
        items = list(workspace.warehouses.list())
    except Exception as e:
        raise _fail("connection_failed", f"couldn't list SQL warehouses with profile '{profile}': {redact(e)}; "
                                         f"{_login(profile)}") from None
    found = [{"id": w.id, "name": w.name, "state": getattr(w.state, "value", w.state), "size": w.cluster_size}
             for w in items]
    return sorted(found, key=lambda w: (w["state"] != "RUNNING", str(w["name"]).lower()))


def list_catalogs() -> "Query":
    return _query("list_catalogs", "SELECT catalog_name, comment FROM system.information_schema.catalogs "
                                   "ORDER BY catalog_name", {})


def list_schemas(catalog: str) -> "Query":
    return _query("list_schemas", "SELECT schema_name, comment FROM system.information_schema.schemata "
                                  "WHERE catalog_name = :catalog ORDER BY schema_name", {"catalog": catalog})


def catalogs(runner: "Runner") -> list[dict]:
    return [{"name": r["catalog_name"], "comment": r.get("comment")} for r in runner.run(list_catalogs())
            if r["catalog_name"] not in HIDDEN_CATALOGS]


def schemas(runner: "Runner", catalog: str) -> list[dict]:
    return [{"name": r["schema_name"], "comment": r.get("comment")} for r in runner.run(list_schemas(catalog))
            if r["schema_name"] not in HIDDEN_SCHEMAS]


@dataclass(frozen=True)
class Query:
    """One fixed template: its SQL text (no user strings) and bound parameters, sorted by name."""
    name: str
    sql: str
    params: tuple[tuple[str, object], ...]


def _query(name: str, sql: str, params: dict) -> Query:
    return Query(name, f"/* {name} */ {sql}", tuple(sorted(params.items())))


def quote(name: str) -> str:
    return "`" + name.replace("`", "``") + "`"


class Selection:
    """The tables the user chose. Templates that name a table in SQL text get it only through `ref`."""

    def __init__(self, tables: Iterable[tuple[str, str, str]]):
        self.tables = tuple(sorted(set(tables)))

    def ref(self, catalog: str, schema: str, table: str) -> str:
        if (catalog, schema, table) not in self.tables:
            raise _fail("query_table_not_selected", f"{catalog}.{schema}.{table} isn't one of the selected tables")
        return ".".join(quote(part) for part in (catalog, schema, table))


def list_tables(catalog: str, schema: str) -> Query:
    return _query("list_tables", "SELECT table_name, table_type, comment FROM system.information_schema.tables "
                                 "WHERE table_catalog = :catalog AND table_schema = :schema ORDER BY table_name",
                  {"catalog": catalog, "schema": schema})


def _selected(selection: Selection, alias: str = "") -> tuple[str, dict]:
    """A WHERE condition matching exactly the selected tables, with bound parameters."""
    params, where = {}, []
    for i, (catalog, schema, table) in enumerate(selection.tables):
        params |= {f"c{i}": catalog, f"s{i}": schema, f"t{i}": table}
        where.append(f"({alias}table_catalog = :c{i} AND {alias}table_schema = :s{i} AND {alias}table_name = :t{i})")
    return " OR ".join(where), params


def columns(selection: Selection) -> Query:
    where, params = _selected(selection)
    return _query("columns", "SELECT table_catalog, table_schema, table_name, column_name, ordinal_position, "
                             "full_data_type, data_type, numeric_precision, numeric_scale, character_maximum_length, "
                             "is_nullable, comment FROM system.information_schema.columns WHERE " + where +
                  " ORDER BY table_catalog, table_schema, table_name, ordinal_position", params)


def constraints(selection: Selection) -> Query:
    """Each PK/UNIQUE/FK column of the selected tables; for an FK, the parent table and column it references."""
    where, params = _selected(selection, "k.")
    same = "{a}.constraint_catalog = {b}_catalog AND {a}.constraint_schema = {b}_schema AND {a}.constraint_name = {b}_name"
    return _query("constraints",
                  "SELECT k.table_catalog, k.table_schema, k.table_name, k.constraint_name, c.constraint_type, "
                  "k.column_name, k.ordinal_position, p.table_catalog AS ref_catalog, p.table_schema AS ref_schema, "
                  "p.table_name AS ref_table, pk.column_name AS ref_column "
                  "FROM system.information_schema.key_column_usage k "
                  "JOIN system.information_schema.table_constraints c ON " + same.format(a="c", b="k.constraint") +
                  " LEFT JOIN system.information_schema.referential_constraints r ON " + same.format(a="r", b="k.constraint") +
                  " LEFT JOIN system.information_schema.table_constraints p ON " + same.format(a="p", b="r.unique_constraint") +
                  " LEFT JOIN system.information_schema.key_column_usage pk ON " + same.format(a="pk", b="r.unique_constraint") +
                  " AND pk.ordinal_position = k.position_in_unique_constraint WHERE " + where +
                  " ORDER BY k.table_catalog, k.table_schema, k.table_name, k.constraint_name, k.ordinal_position", params)


def _read_only(query: Query) -> None:
    try:
        statements = sqlglot.parse(query.sql, read="databricks")
    except sqlglot.errors.ParseError:
        statements = []
    if len(statements) != 1 or not isinstance(statements[0], exp.Select):
        raise _fail("query_not_read_only", f"query '{query.name}' isn't a single read-only SELECT; nothing was sent")


class Runner:
    """Runs templates one at a time. A statement still running at its time limit is cancelled on the warehouse.
    The limits are safeguards, not a guaranteed cap on warehouse cost."""

    def __init__(self, connection, query_timeout: float = QUERY_TIMEOUT, budget: float = BUDGET, clock=time.monotonic,
                 check: Callable[[Query], None] = None):
        """`check` refuses a query before it is sent: read-only SELECTs by default (plan9: a push passes its own guard)."""
        self.connection, self.query_timeout, self.budget, self.clock = connection, query_timeout, budget, clock
        self.check, self.spent = check or _read_only, 0.0

    def run(self, query: Query) -> list[dict]:
        self.check(query)
        remaining = self.budget - self.spent
        if remaining <= 0:
            raise _fail("profiling_budget_exhausted", f"the {self.budget:g}s query budget is used up; '{query.name}' wasn't sent")
        wait = min(self.query_timeout, remaining)
        cursor, result = self.connection.cursor(), {}

        def work():
            try:
                cursor.execute(query.sql, dict(query.params))
                if cursor.description is None:  # a statement with no result set (plan9: CREATE, COPY INTO)
                    result["rows"] = []
                    return
                names = [d[0] for d in cursor.description]
                result["rows"] = [dict(zip(names, row)) for row in cursor.fetchall()]
            except Exception as e:
                result["error"] = e

        worker = threading.Thread(target=work, daemon=True)
        started = self.clock()
        worker.start()
        worker.join(wait)
        try:
            if worker.is_alive():
                cursor.cancel()  # stops the statement on the warehouse, not just the local wait
                worker.join(CANCEL_WAIT)
                self.spent += self.clock() - started
                if wait < self.query_timeout:
                    raise _fail("profiling_budget_exhausted", f"the {self.budget:g}s query budget ran out during "
                                                              f"'{query.name}'; the statement was cancelled")
                raise _fail("query_timeout", f"'{query.name}' took longer than {self.query_timeout:g}s; "
                                             f"the statement was cancelled")
            self.spent += self.clock() - started
            if "error" in result:
                raise _fail("query_failed", f"'{query.name}' failed: {redact(result['error'])}")
            return result["rows"]
        finally:
            cursor.close()


def _name(*parts) -> str:
    return ".".join(parts)


def _column(row: dict) -> Column:
    try:
        declared, type_name, params = column_type(exp.DataType.build(row["full_data_type"], dialect="databricks"), "databricks")
    except (sqlglot.errors.ParseError, ValueError):  # kept as written; the support check reports it
        declared, type_name, params = row["full_data_type"].upper(), "", ()
    return Column(row["column_name"], declared, row["is_nullable"] != "NO", type_name=type_name, type_params=params,
                  comment=row["comment"])


def _table(name: str, columns_: list[Column], keys: dict, selected: set, diagnostics: list, comment) -> Table:
    primary_key, unique, fks = None, [], []
    for (constraint, kind), rows in keys.items():
        rows = sorted(rows, key=lambda r: r["ordinal_position"])
        cols = tuple(r["column_name"] for r in rows)
        if kind == "PRIMARY KEY":
            primary_key = cols
        elif kind == "UNIQUE":
            unique.append(Key(cols))
        elif kind == "FOREIGN KEY":
            first = rows[0]
            parent = _name(first["ref_catalog"], first["ref_schema"], first["ref_table"]) if first["ref_table"] else None
            if parent not in selected:
                diagnostics.append(Diagnostic("error", "fk_parent_not_selected",
                                              f"foreign key {name}({', '.join(cols)}) references {parent or 'a table this account cannot see'}, "
                                              f"which isn't selected; add it to the selected tables"))
                continue
            fks.append(ForeignKey(constraint, cols, parent, tuple(r["ref_column"] for r in rows)))
    return Table(name, tuple(columns_), primary_key, tuple(unique), tuple(fks), comment=comment)


def discover(runner: Runner, catalog: str, schema: str, tables: list[str]) -> Schema:
    """The selected tables of `catalog.schema` as a Schema: columns, types, nullability, comments, declared keys."""
    available = {row["table_name"]: row for row in runner.run(list_tables(catalog, schema))}
    missing = sorted(set(tables) - set(available))
    if missing:
        raise _fail("table_not_found", f"{', '.join(_name(catalog, schema, t) for t in missing)} not found, or not visible "
                                       f"to this account; {catalog}.{schema} has: {', '.join(sorted(available)) or 'no tables'}")
    selection = Selection((catalog, schema, t) for t in tables)
    by_table: dict[str, list[Column]] = {}
    for row in runner.run(columns(selection)):
        by_table.setdefault(_name(row["table_catalog"], row["table_schema"], row["table_name"]), []).append(_column(row))
    keys: dict[str, dict] = {}
    for row in runner.run(constraints(selection)):
        table = _name(row["table_catalog"], row["table_schema"], row["table_name"])
        keys.setdefault(table, {}).setdefault((row["constraint_name"], row["constraint_type"]), []).append(row)
    selected, diagnostics = {_name(*t) for t in selection.tables}, []
    built = tuple(_table(_name(c, s, t), by_table.get(_name(c, s, t), []), keys.get(_name(c, s, t), {}), selected,
                         diagnostics, available[t]["comment"]) for c, s, t in selection.tables)
    return short_names(Schema(built, tuple(diagnostics)))


# --- profiling (plan6 C) ---------------------------------------------------------------------------


def _sample(rows: Optional[int]) -> str:
    return f" TABLESAMPLE ({int(rows)} ROWS)" if rows else ""


def _kind(column: Column) -> Optional[str]:
    try:
        return type_spec(column).kind
    except ValueError:  # an unsupported type: null counts only
        return None


def profile_table(selection: Selection, catalog: str, schema: str, table: Table, sample_rows: Optional[int]) -> Query:
    """One aggregate row: `n` rows profiled, and `c<i>_*` statistics for the i-th column."""
    keys, parts = key_columns(table), ["COUNT(*) AS n"]
    for i, column in enumerate(table.columns):
        q, kind = quote(column.name), _kind(column)
        parts.append(f"COUNT({q}) AS c{i}_nn")
        if kind in ("int", "decimal", "float", "date", "timestamp"):
            parts += [f"MIN({q}) AS c{i}_min", f"MAX({q}) AS c{i}_max"]
        if kind == "text":
            parts += [f"MIN(LENGTH({q})) AS c{i}_minlen", f"MAX(LENGTH({q})) AS c{i}_maxlen"]
            if column.name not in keys:
                parts.append(f"APPROX_COUNT_DISTINCT({q}) AS c{i}_ndv")  # a count: tells categories apart (plan8)
        if column.name in keys:
            parts.append(f"COUNT(DISTINCT {q}) AS c{i}_distinct")
            if kind == "text":
                parts += [f"SUM(CASE WHEN {q} RLIKE '{pattern}' THEN 1 ELSE 0 END) AS c{i}_{name}"
                          for name, pattern in ID_FORMATS.items()]
    source = selection.ref(catalog, schema, table.name) + _sample(sample_rows)
    return _query("profile_table", f"WITH s AS (SELECT * FROM {source}) SELECT {', '.join(parts)} FROM s", {})


def top_values(selection: Selection, catalog: str, schema: str, table: str, column: str, sample_rows: Optional[int],
               top: int) -> Query:
    """The most common values of one approved column; one more than `top`, to tell whether the list is complete."""
    q = quote(column)
    return _query("top_values", f"SELECT {q} AS value, COUNT(*) AS n FROM {selection.ref(catalog, schema, table)}"
                                f"{_sample(sample_rows)} WHERE {q} IS NOT NULL GROUP BY {q} ORDER BY n DESC, value "
                                f"LIMIT {int(top) + 1}", {})


def _then_columns(table: Table, when: str, approved: set) -> list[Column]:
    """Columns compared within each value of `when`: numbers and dates (their min/max are already measured), and text
    only when the user approved reading its values. Never keys or foreign keys."""
    keys = key_columns(table)
    return [c for c in table.columns if c.name != when and c.name not in keys
            and (_kind(c) in CONDITIONAL_KINDS or (_kind(c) == "text" and c.name in approved))]


def conditional_query(selection: Selection, catalog: str, schema: str, table: Table, when: str, approved: set,
                      sample_rows: Optional[int], top: int) -> Optional[Query]:
    """Per value of the approved column `when`: row count, and each compared column's non-null count, min and max.
    A column whose min equals its max (and has no NULLs) in one category is constant there. None: nothing to compare."""
    then = _then_columns(table, when, approved)
    if not then:
        return None
    q = quote(when)
    parts = [f"{q} AS value", "COUNT(*) AS n"]
    for i, column in enumerate(then):
        b = quote(column.name)
        parts += [f"COUNT({b}) AS t{i}_nn", f"MIN({b}) AS t{i}_min", f"MAX({b}) AS t{i}_max"]
    return _query("conditional_candidates", f"SELECT {', '.join(parts)} FROM {selection.ref(catalog, schema, table.name)}"
                                            f"{_sample(sample_rows)} WHERE {q} IS NOT NULL GROUP BY {q} "
                                            f"ORDER BY n DESC, value LIMIT {int(top) + 1}", {})


def _conditionals(table: Table, when: str, approved: set, groups: list[dict], top: int, estimate: bool) -> list[dict]:
    """Columns constant within a category (enough rows, no NULLs) but not constant everywhere."""
    found = []
    if len(groups) > top or len(groups) < 2:
        return found
    for i, column in enumerate(_then_columns(table, when, approved)):
        constant = {g["value"]: g[f"t{i}_min"] for g in groups
                    if g["n"] >= CONDITIONAL_MIN_ROWS and g[f"t{i}_nn"] == g["n"] and g[f"t{i}_min"] == g[f"t{i}_max"]}
        if len(constant) == len(groups) and len(set(constant.values())) == 1:
            continue  # the same value in every category: a constant column, not a rule about `when`
        found += [{"when": when, "value": _json(g["value"]), "rows": g["n"], "then": column.name,
                   "equals": _json(constant[g["value"]]), "estimate": estimate} for g in groups if g["value"] in constant]
    return found


def unmatched_fk(selection: Selection, catalog: str, schema: str, table: str, fk: ForeignKey,
                 sample_rows: Optional[int]) -> Query:
    """Child rows (sampled) whose key has no match in the **full** parent table."""
    keys = ", ".join(f"{quote(c)} AS k{i}" for i, c in enumerate(fk.columns))
    present = " AND ".join(f"{quote(c)} IS NOT NULL" for c in fk.columns)
    on = " AND ".join(f"s.k{i} = p.{quote(r)}" for i, r in enumerate(fk.ref_columns))
    child, parent = selection.ref(catalog, schema, table), selection.ref(catalog, schema, fk.ref_table)
    return _query("unmatched_fk", f"WITH s AS (SELECT {keys} FROM {child}{_sample(sample_rows)} WHERE {present}) "
                                  f"SELECT (SELECT COUNT(*) FROM s) AS checked, "
                                  f"(SELECT COUNT(*) FROM s LEFT ANTI JOIN {parent} AS p ON {on}) AS unmatched", {})


def _json(value):
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, dt.datetime):
        return value.isoformat(sep=" ")
    if isinstance(value, dt.date):
        return value.isoformat()
    return value


def _pct(part, whole) -> Optional[float]:
    return round(100 * part / whole, 2) if whole else None


def _column_stats(i: int, column: Column, row: dict, rows: int, keys: set, estimate: bool) -> dict:
    kind, present = _kind(column), row[f"c{i}_nn"]
    out = {"null_count": rows - present, "null_pct": _pct(rows - present, rows)}
    if kind in ("int", "decimal", "float"):
        out |= {"min": _json(row[f"c{i}_min"]), "max": _json(row[f"c{i}_max"])}
    if kind in ("date", "timestamp"):
        out |= {"earliest": _json(row[f"c{i}_min"]), "latest": _json(row[f"c{i}_max"])}
    if kind == "text":
        out |= {"min_length": row[f"c{i}_minlen"], "max_length": row[f"c{i}_maxlen"]}
        if column.name not in keys:
            out["distinct_estimate"] = row[f"c{i}_ndv"]
    if column.name in keys:
        distinct = row[f"c{i}_distinct"]
        out |= {"distinct": distinct, "duplicates": present - distinct, "proves_whole_table": not estimate}
        if kind == "text":
            out["formats"] = {name: _pct(row[f"c{i}_{name}"], present) for name in ID_FORMATS}
    out["estimate"] = estimate
    return out


def _attempt(runner: Runner, query: Query, incomplete: list) -> Optional[list[dict]]:
    """The rows, or None after recording why the section is incomplete (time limits, a failed query)."""
    try:
        return runner.run(query)
    except GenerationError as e:
        problem = e.problems[0]
        if problem.code not in ("query_timeout", "profiling_budget_exhausted", "query_failed"):
            raise
        incomplete.append({"query": query.name, "code": problem.code, "message": problem.message})
        return None


def _check_categorical(schema: Schema, categorical: dict) -> None:
    unknown = [f"{t}.{c}" for t, cols in categorical.items() for c in cols
               if schema.table(t) is None or schema.table(t).column(c) is None]
    if unknown:
        raise _fail("profile_unknown_column", f"can't collect values for {', '.join(unknown)}: not a column of the selected tables")


def profile(runner: Runner, schema: Schema, catalog: str, schema_name: str, categorical: Optional[dict] = None,
            mode: str = "sample", sample_rows: int = SAMPLE_ROWS, top: int = TOP_VALUES, now=None) -> dict:
    """profile.json for the discovered `schema`. Values are listed only for `categorical` columns ({table: [column]})."""
    if mode not in ("sample", "full"):
        raise _fail("profile_mode_invalid", f"mode must be 'sample' or 'full', got {mode!r}")
    categorical = categorical or {}
    _check_categorical(schema, categorical)
    rows_arg, estimate = (sample_rows, True) if mode == "sample" else (None, False)
    selection = Selection((catalog, schema_name, t.name) for t in schema.tables)
    profiled_at = (now or (lambda: dt.datetime.now(dt.timezone.utc)))().isoformat()
    tables = {}
    for table in schema.tables:
        incomplete, columns, rows = [], {}, None
        result = _attempt(runner, profile_table(selection, catalog, schema_name, table, rows_arg), incomplete)
        if result:
            row, keys = result[0], key_columns(table)
            rows = row["n"]
            columns = {c.name: _column_stats(i, c, row, rows, keys, estimate) for i, c in enumerate(table.columns)}
        for name in categorical.get(table.name, []):
            values = _attempt(runner, top_values(selection, catalog, schema_name, table.name, name, rows_arg, top), incomplete)
            if values is not None:
                columns.setdefault(name, {}).update(
                    values=[{"value": _json(v["value"]), "count": v["n"], "pct": _pct(v["n"], rows)} for v in values[:top]],
                    values_complete=len(values) <= top)
        approved, conditionals = set(categorical.get(table.name, [])), []
        for name in categorical.get(table.name, []):
            query = conditional_query(selection, catalog, schema_name, table, name, approved, rows_arg, top)
            groups = _attempt(runner, query, incomplete) if query is not None else None
            if groups is not None:
                conditionals += _conditionals(table, name, approved, groups, top, estimate)
        fks = []
        for fk in table.foreign_keys:
            found = _attempt(runner, unmatched_fk(selection, catalog, schema_name, table.name, fk, rows_arg), incomplete)
            if found:
                fks.append({"columns": list(fk.columns), "references": {"table": fk.ref_table, "columns": list(fk.ref_columns)},
                            "checked": found[0]["checked"], "unmatched": found[0]["unmatched"], "estimate": estimate,
                            "proves_whole_table": not estimate})
        tables[table.name] = {"rows_profiled": rows, "table_rows": None if estimate else rows, "estimate": estimate,
                              "columns": columns, "foreign_keys": fks, "incomplete": incomplete} | \
            ({"conditionals": conditionals} if approved else {})
    return {"format_version": prof.FORMAT_VERSION, "profiled_at": profiled_at, "method": mode,
            "sample_rows_requested": rows_arg, "source": {"catalog": catalog, "schema": schema_name},
            "notes": prof.NOTES, "tables": tables}
