"""profile.json, and suggested settings from a profile (plan6 C).

A profile holds observed patterns only. Generation never reads it: suggestions become rules only once the
user confirms them.
"""

import json
import re
from typing import Optional

from dcloneb.generate.providers import date_name
from dcloneb.generate.support import key_columns
from dcloneb.generate.types import type_spec
from dcloneb.model import Schema

FORMAT_VERSION = 1
NOTES = ["Figures from a sample are estimates (`estimate: true`).",
         "Uniqueness and foreign-key checks on a sample never prove anything about the whole table.",
         "A foreign key's `unmatched` counts sampled child rows whose key isn't in the whole parent table.",
         "Sampling and query time limits are safeguards, not a guaranteed cap on warehouse cost."]


CATEGORY_MAX = 20  # distinct values at most, for a text column to be offered as a category (plan8)
DATE_VALUE = re.compile(r"\d{4}-\d{2}-\d{2}")  # fits, so never a fixed list of values


def dump(profile: dict) -> str:
    return json.dumps(profile, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def _kind(column) -> Optional[str]:
    try:
        return type_spec(column).kind
    except ValueError:
        return None


def _suggestion(rule_type: str, table: str, column: str, fields: dict, observed: dict, basis: str) -> dict:
    rule = {"id": f"observed_{table}_{column}_{rule_type}", "type": rule_type, "table": table, "column": column,
            **fields, "origin": "observed"}
    return {"rule": rule, "estimate": observed["estimate"], "basis": basis}


def _id_width(table: str, column, stats: dict, observed: dict, basis: str) -> list[dict]:
    """A fixed ID width, from measured min/max or lengths and format match rates (ID values themselves are never read)."""
    kind, policy = _kind(column), "allow" if column.nullable else "forbid"
    low, high = stats.get("min"), stats.get("max")
    if kind == "int" and isinstance(low, int) and isinstance(high, int) and 0 < low and len(str(low)) == len(str(high)):
        digits = len(str(low))
        return [_suggestion("range", table, column.name, {"min": 10 ** (digits - 1), "min_inclusive": True,
                                                          "max": 10 ** digits - 1, "max_inclusive": True, "null_policy": policy},
                            observed, f"{basis}: {digits}-digit IDs")]
    length = stats.get("min_length")
    if kind == "text" and (stats.get("formats") or {}).get("digits") == 100.0 and length and length == stats.get("max_length") \
            and length <= 18:
        return [_suggestion("id_format", table, column.name, {"prefix": "", "digits": length, "null_policy": policy},
                            observed, f"{basis}: {length}-digit IDs")]
    return []


def suggest(profile: dict, schema: Schema) -> list[dict]:
    """Settings the observed patterns suggest, for the user to confirm, edit, or reject. Each is `{"rule": a rules.json v2
    rule, "estimate", "basis"}`: a `range` from observed
    min/max (numbers, dates, timestamps), `allowed_values` with `weights` from a complete list of approved category
    values, a `null_rate` for nullable columns, and a `conditional` for each column constant within one approved
    category (plan8). Keys the generator makes get only their ID width, when every
    measured ID has the same number of digits: a `range` (numbers) or an `id_format` without a prefix (all-digit text);
    foreign keys get none, since they copy their parent's IDs."""
    found = []
    for name, observed in profile["tables"].items():
        table = schema.table(name)
        if table is None:
            continue
        keys, rows = key_columns(table), observed["rows_profiled"]
        basis = f"sample of {rows} rows" if observed["estimate"] else f"all {rows} rows"
        for column in table.columns:
            stats = observed["columns"].get(column.name)
            if stats and column.name in keys and not any(column.name in fk.columns for fk in table.foreign_keys):
                found += _id_width(name, column, stats, observed, basis)
            if not stats or column.name in keys:
                continue
            kind, policy = _kind(column), "allow" if column.nullable else "forbid"
            low, high = ((stats.get("min"), stats.get("max")) if kind in ("int", "decimal")
                         else (stats.get("earliest"), stats.get("latest")) if kind in ("date", "timestamp") else (None, None))
            if low is not None and high is not None:
                found.append(_suggestion("range", name, column.name, {"min": low, "min_inclusive": True, "max": high,
                                                                      "max_inclusive": True, "null_policy": policy},
                                         observed, f"{basis}: {low} to {high}"))
            if stats.get("values") and stats.get("values_complete") and not _date_values(stats["values"]):
                values = [v["value"] for v in stats["values"]]
                found.append(_suggestion("allowed_values", name, column.name,
                                         {"values": values, "weights": [v["count"] for v in stats["values"]],
                                          "null_policy": policy},
                                         observed, f"{basis}: {len(values)} values, most often {values[0]!r}"))
            if column.nullable and stats.get("null_pct") is not None:
                found.append(_suggestion("null_rate", name, column.name, {"rate": round(stats["null_pct"] / 100, 4)},
                                         observed, f"{basis}: {stats['null_pct']}% NULL"))
        found += _conditional_suggestions(name, observed.get("conditionals", []), basis)
    return found


def _conditional_suggestions(table: str, findings: list[dict], basis: str) -> list[dict]:
    """A column constant within one category ("every CLOSED account had balance 0") as a conditional rule (plan8). A
    finding whose value column is another finding's condition is left out: chained conditionals aren't supported."""
    whens = {f["when"] for f in findings}
    out = []
    for f in findings:
        if f["then"] in whens:
            continue
        slug = re.sub(r"[^0-9a-z]+", "_", str(f["value"]).lower()).strip("_")
        rule = {"id": f"observed_{table}_{f['when']}_{slug}_{f['then']}_conditional", "type": "conditional", "table": table,
                "when": {"column": f["when"], "equals": f["value"]}, "then": {"column": f["then"], "equals": f["equals"]},
                "origin": "observed"}
        out.append({"rule": rule, "estimate": f["estimate"],
                    "basis": f"{basis}: all {f['rows']} rows with {f['when']} {json.dumps(f['value'])} had {f['then']} {f['equals']}"})
    return out


def _date_values(values: list[dict]) -> bool:
    return sum(bool(DATE_VALUE.match(str(v["value"]))) for v in values) * 2 >= len(values)


def categorical_candidates(profile: dict, schema: Schema) -> list[dict]:
    """Text columns that look like categories (few distinct values, each repeated), to offer the user for reading
    their values. From counts and names only: no value is read to decide. Dates stored as text (by name) aren't
    categories: in a sample they repeat, but any date fits."""
    found = []
    for name, observed in profile["tables"].items():
        table, rows = schema.table(name), observed["rows_profiled"] or 0
        for column in table.columns if table else ():
            stats = observed["columns"].get(column.name) or {}
            distinct = stats.get("distinct_estimate")
            present = rows - stats.get("null_count", 0)
            if distinct and distinct <= CATEGORY_MAX and distinct * 2 <= present and not date_name(column.name):
                found.append({"table": name, "column": column.name, "distinct": distinct, "max_length": stats["max_length"]})
    return found
