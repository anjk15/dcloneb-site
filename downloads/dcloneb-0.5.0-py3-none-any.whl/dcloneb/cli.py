"""Command-line entry point (plan Phase 11).

The plan JSON goes to stdout (or --out); problems go to stderr, so `dcloneb analyze ... > plan.json`
always yields valid JSON. Exit codes: 0 = ok, 2 = errors (the plan is still written).
"""

from pathlib import Path
from typing import Optional

import typer

from dcloneb.dialects import PLANNED, SUPPORTED, UnsupportedDialect, check_dialect
from dcloneb.plan import analyze as analyze_ddl

app = typer.Typer(help="Plan table load order, FK backfills, and relationships from SQL DDL; generate test data from the plan.",
                  no_args_is_help=True)


def _version(value: bool) -> None:
    if value:
        from dcloneb import __version__
        typer.echo(f"dcloneb {__version__}")
        raise typer.Exit()


@app.callback()
def _main(version: bool = typer.Option(False, "--version", callback=_version, is_eager=True,
                                       help="Show the installed version and exit.")) -> None:
    pass


def _fail(message: str) -> None:
    typer.echo(message, err=True)
    raise typer.Exit(code=2)


def _read_ddl(ddl: Path) -> str:
    try:
        return ddl.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        _fail(f"cannot read DDL file {ddl}: not valid UTF-8")
    except OSError as e:
        _fail(f"cannot read DDL file {ddl}: {e.strerror or e}")


def _count(n: int, word: str) -> str:
    return f"{n} {word}" if n == 1 else f"{n} {word}s"


@app.command()
def analyze(
    ddl: Path = typer.Option(..., help="SQL DDL file (UTF-8)."),
    dialect: str = typer.Option(..., help="SQL dialect of the DDL (see `dcloneb dialects`)."),
    out: Optional[Path] = typer.Option(None, help="Write plan JSON here instead of stdout."),
) -> None:
    """Analyze DDL and produce the load plan (execution order, backfills, relationships)."""
    try:
        check_dialect(dialect)  # before reading the file: the more fundamental problem first
    except UnsupportedDialect as e:
        _fail(str(e))
    sql = _read_ddl(ddl)

    plan = analyze_ddl(sql, dialect)

    data = plan.to_dict()
    text = plan.to_json()
    if out is None:
        typer.echo(text, nl=False)
    else:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        severities = [d.severity for d in plan.diagnostics]
        typer.echo(
            f"Wrote {out}: {_count(len(data['tables']), 'table')}, {_count(len(data['backfill'] or []), 'backfill')}, "
            f"{_count(severities.count('error'), 'error')}, {_count(severities.count('warning'), 'warning')}, "
            f"{severities.count('info')} info."
        )
    for d in plan.diagnostics:
        if d.severity == "error":
            typer.echo(f"error {d.code} (statement {d.statement}, line {d.line}): {d.message}", err=True)
    if plan.status == "error":
        raise typer.Exit(code=2)


# plan2 error kinds -> exit codes: 2 = fix the input/schema/request, 3 = retries ran out, 4 = a dcloneb bug
GENERATE_EXIT = {"input": 2, "unsupported": 2, "impossible": 2, "retry_exhausted": 3, "validation_failed": 4}


@app.command()
def generate(
    plan: Path = typer.Option(..., help="plan.json from `dcloneb analyze`."),
    config: Path = typer.Option(..., help="generation.json (seed, default_rows, table_rows, null_probability, locale)."),
    out: Path = typer.Option(..., help="Output bundle directory (must not exist unless --force)."),
    force: bool = typer.Option(False, "--force", help="Replace an existing bundle, only after the new one validates."),
    rules: Optional[Path] = typer.Option(None, help="Optional rules.json of business rules (range, allowed_values, format)."),
    scenario: Optional[Path] = typer.Option(None, help="Optional scenario.json: named rows, links, background groups, "
                                                       "negative tests. Its row counts replace the config's."),
) -> None:
    """Generate synthetic CSVs that satisfy the plan's constraints (local, deterministic)."""
    from dcloneb.generate import api  # the generator's dependencies load only for these commands

    _report(lambda: api.generate(plan, config, out, force=force, rules=rules, scenario=scenario))


@app.command()
def make(
    ddl: Path = typer.Argument(..., help="PostgreSQL DDL file (UTF-8)."),
    out: Path = typer.Option(Path("generated"), help="Output folder for the CSVs."),
    rows: Optional[int] = typer.Option(None, min=0, help="Rows per table (default 100)."),
    seed: Optional[int] = typer.Option(None, help="Random seed; the same seed gives the same data (default 42)."),
    config: Optional[Path] = typer.Option(None, help="Optional generation.json for per-table rows, NULL rate, locale."),
    force: bool = typer.Option(False, "--force", help="Replace an existing output folder."),
    rules: Optional[Path] = typer.Option(None, help="Optional rules.json of business rules (range, allowed_values, format)."),
    scenario: Optional[Path] = typer.Option(None, help="Optional scenario.json; its row counts replace --rows."),
) -> None:
    """DDL in, CSV folder out: one command for `analyze` + `generate`."""
    from dcloneb.generate import api

    sql = _read_ddl(ddl)
    _report(lambda: api.make(sql, out, rows=rows, seed=seed, config=config, force=force, rules=rules, scenario=scenario))


def _report(run_generation) -> None:
    """Run a generation, print the one-line summary, or every problem on stderr with its exit code."""
    from dcloneb.generate.errors import GenerationError

    try:
        result = run_generation()
    except GenerationError as e:
        for p in e.problems:
            typer.echo(f"error {p.kind} {p.code}: {p.message}", err=True)
        raise typer.Exit(code=max(GENERATE_EXIT[p.kind] for p in e.problems))
    m = result.manifest
    rows = sum(t["rows"] for t in m["tables"].values())
    filled = sum(b["rows_filled"] for b in m["backfills"])
    verdict = "validation passed"
    if m["validation"] == "passed_with_intentional_exceptions":  # plan7: never just "passed"
        broken = m["scenario"]["violations"]
        verdict += (f" with {_count(len(broken), 'intentional exception')} ("
                    + ", ".join(f"{v['alias']} breaks {v['rule']}" for v in broken) + "), 0 unexpected failures")
    typer.echo(f"Wrote {result.out}: {_count(len(m['tables']), 'table')}, {_count(rows, 'row')}, "
               f"{_count(filled, 'backfilled row')}; {verdict}.")


mcp_app = typer.Typer(help="Use dcloneb from an AI agent (Claude Desktop) through a local MCP server.", no_args_is_help=True)
app.add_typer(mcp_app, name="mcp")


@mcp_app.command("serve")
def mcp_serve(
    workspace: Path = typer.Option(..., help="The folder tools may read and write; nothing outside it is touched."),
    max_rows_per_table: int = typer.Option(100_000, help="Largest row count a tool may request per table."),
    max_rows_total: int = typer.Option(1_000_000, help="Largest total row count a tool may request."),
) -> None:
    """Run the local MCP server over stdio (Claude Desktop starts this; see `dcloneb mcp install`)."""
    from dcloneb.generate.errors import GenerationError
    from dcloneb.mcp.limits import Limits
    from dcloneb.mcp.workspace import Workspace

    try:
        ws = Workspace(workspace)
        limits = Limits(per_table=max_rows_per_table, total=max_rows_total)
    except GenerationError as e:
        _fail("; ".join(f"error {p.kind} {p.code}: {p.message}" for p in e.problems))
    except ValueError as e:
        _fail(f"error input bad_limits: {e}")
    try:
        from dcloneb.mcp.server import build_server
    except ImportError:
        _fail("the MCP server needs the mcp extra: uv tool install \"dcloneb[mcp] @ git+https://github.com/anjk15/dcloneb\" "
              "(or pip install \"dcloneb[mcp]\")")
    build_server(ws, limits).run()


CLIENT_HELP = "Which app to connect: claude-desktop (the desktop app) or claude-code (the CLI, and Claude in VS Code)."
CLIENTS = ("claude-desktop", "claude-code")


def _client(client: str) -> str:
    if client not in CLIENTS:
        _fail(f"error input unknown_client: {client!r}; choose claude-desktop or claude-code")
    return client


def _problems(e) -> None:
    _fail("; ".join(f"error {p.kind} {p.code}: {p.message}" for p in e.problems))


@mcp_app.command("install")
def mcp_install(
    workspace: Path = typer.Option(..., help="The folder dcloneb may read and write. Created if missing."),
    max_rows_per_table: int = typer.Option(100_000, help="Largest row count the agent may request per table."),
    max_rows_total: int = typer.Option(1_000_000, help="Largest total row count the agent may request."),
    yes: bool = typer.Option(False, "--yes", help="Don't ask before using a folder that already has files in it."),
    client: str = typer.Option("claude-desktop", help=CLIENT_HELP),
) -> None:
    """Connect dcloneb to Claude Desktop (merges into its config, with a backup) or to Claude Code."""
    from dcloneb.generate.errors import GenerationError
    from dcloneb.mcp import claude_code, claude_desktop
    from dcloneb.mcp.limits import Limits

    client = _client(client)
    if client == "claude-desktop" and claude_desktop.claude_running():
        _fail(claude_desktop.QUIT_FIRST)
    try:
        Limits(per_table=max_rows_per_table, total=max_rows_total)
    except ValueError as e:
        _fail(f"error input bad_limits: {e}")
    folder = workspace.expanduser()
    if folder.is_dir() and any(folder.iterdir()) and not yes:
        typer.confirm(f"{folder} already has files in it. The agent's tools will be able to read files there. Use it?",
                      abort=True)
    executable = claude_desktop.find_executable()
    if executable is None:
        _fail("error input executable_invalid: can't find the dcloneb command; install it with uv tool install first")
    try:
        if client == "claude-code":
            claude_code.install(executable, folder, max_rows_per_table, max_rows_total)
        else:
            change = claude_desktop.install(claude_desktop.config_path(), executable, folder, max_rows_per_table,
                                            max_rows_total)
    except GenerationError as e:
        _problems(e)
    if client == "claude-code":
        typer.echo(f"Added dcloneb to Claude Code, for all your projects.\nWorkspace: {folder.resolve()}\n"
                   "Run `dcloneb mcp test --client claude-code` to check it, then start a new Claude Code session.")
        return
    typer.echo(f"Added dcloneb to Claude Desktop ({change.config}).")
    if change.backup:
        typer.echo(f"Your previous config is saved as {change.backup}.")
    typer.echo(f"Workspace: {folder.resolve()}\nNow open Claude Desktop, then run `dcloneb mcp test` to check the connection.")


@mcp_app.command("uninstall")
def mcp_uninstall(client: str = typer.Option("claude-desktop", help=CLIENT_HELP)) -> None:
    """Remove dcloneb from Claude Desktop (only its own entry; with a backup) or from Claude Code."""
    from dcloneb.generate.errors import GenerationError
    from dcloneb.mcp import claude_code, claude_desktop

    client = _client(client)
    if client == "claude-code":
        try:
            removed = claude_code.uninstall()
        except GenerationError as e:
            _problems(e)
        typer.echo("Removed dcloneb from Claude Code." if removed else "dcloneb wasn't in Claude Code; nothing changed.")
        return
    if claude_desktop.claude_running():
        _fail(claude_desktop.QUIT_FIRST)
    try:
        change = claude_desktop.uninstall(claude_desktop.config_path())
    except GenerationError as e:
        _problems(e)
    if change.removed:
        typer.echo(f"Removed dcloneb from Claude Desktop ({change.config}); backup: {change.backup}. You can open Claude Desktop again.")
    else:
        typer.echo(f"dcloneb wasn't in {change.config}; nothing changed.")


@mcp_app.command("test")
def mcp_test(client: str = typer.Option("claude-desktop", help=CLIENT_HELP)) -> None:
    """Check the setup: starts the configured server and runs a tiny generation in a temp folder."""
    from dcloneb.generate.errors import GenerationError
    from dcloneb.mcp import claude_code, claude_desktop

    client = _client(client)
    try:
        from dcloneb.mcp.selftest import CLIENTS as APPS, run_selftest
        path = claude_code.config_path() if client == "claude-code" else claude_desktop.config_path()
    except ImportError:
        _fail("the MCP commands need the mcp extra: uv tool install \"dcloneb[mcp] @ git+https://github.com/anjk15/dcloneb\"")
    except GenerationError as e:
        _problems(e)
    if run_selftest(path, typer.echo, client):
        typer.echo(f"All checks passed. In {APPS[client][0]}, ask for test data (see the README's checklist).")
    else:
        raise typer.Exit(code=1)


@app.command()
def dialects() -> None:
    """List supported and planned SQL dialects."""
    names = [(name, "supported") for name in sorted(SUPPORTED)] + [(name, "planned") for name in PLANNED]
    width = max(len(name) for name, _ in names) + 2
    for name, status in names:
        typer.echo(f"{name:<{width}}{status}")
