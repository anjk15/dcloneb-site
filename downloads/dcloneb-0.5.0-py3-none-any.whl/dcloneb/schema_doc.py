"""schema.json, and relationships and unique keys the user confirmed (plan6 B3).

A relationship is never inferred from column names: only declared keys and the ones confirmed here exist.
"""

import json
from dataclasses import asdict, replace

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.model import Column, Diagnostic, ForeignKey, Key, Schema, Table
from dcloneb.resolve import resolve

FORMAT_VERSION = 1


def _problem(code: str, message: str) -> Problem:
    return Problem("input", code, message)


def _new_errors(before: Schema, after: Schema) -> list[Problem]:
    """Errors the resolver finds in `after` but not in `before`: the ones the confirmations caused."""
    old = set(resolve(before).diagnostics)
    return [_problem(d.code, d.message) for d in resolve(after).diagnostics if d.severity == "error" and d not in old]


def _type_mismatches(schema: Schema, fks: list[tuple[str, ForeignKey]]) -> list[Problem]:
    problems = []
    for table, fk in fks:
        child, parent = schema.table(table), schema.table(fk.ref_table)
        for name, ref in zip(fk.columns, fk.ref_columns):
            a, b = child.column(name), parent.column(ref)
            if (a.type_name, a.type_params) != (b.type_name, b.type_params):
                problems.append(_problem("fk_type_mismatch", f"{table}.{name} ({a.type}) can't reference "
                                                             f"{parent.name}.{ref} ({b.type}): the types differ"))
    return problems


def confirm(schema: Schema, relationships=(), unique_keys=()) -> Schema:
    """`schema` plus the confirmed FKs (`{"table", "columns", "references": {"table", "columns"}}`) and unique keys
    (`{"table", "columns"}`), each marked `source: confirmed`. Raises GenerationError if any doesn't hold up."""
    problems, fks, keys = [], [], []
    for link in relationships:
        table, parent = link["table"], link["references"]["table"]
        if schema.table(table) is None:
            problems.append(_problem("confirm_unknown_table", f"{table} isn't one of the selected tables"))
        elif schema.table(parent) is None:
            problems.append(_problem("fk_parent_not_selected", f"{table}({', '.join(link['columns'])}) references {parent}, "
                                                               f"which isn't selected; add it to the selected tables"))
        else:
            fks.append((table, ForeignKey(None, tuple(link["columns"]), parent, tuple(link["references"]["columns"]),
                                          source="confirmed")))
    for key in unique_keys:
        if schema.table(key["table"]) is None:
            problems.append(_problem("confirm_unknown_table", f"{key['table']} isn't one of the selected tables"))
        else:
            keys.append((key["table"], Key(tuple(key["columns"]), source="confirmed")))
    if problems:
        raise GenerationError(problems)
    confirmed = replace(schema, tables=tuple(
        replace(t, foreign_keys=t.foreign_keys + tuple(fk for name, fk in fks if name == t.name),
                unique_keys=t.unique_keys + tuple(k for name, k in keys if name == t.name)) for t in schema.tables))
    problems = _new_errors(schema, confirmed) or _type_mismatches(confirmed, fks)
    if problems:
        raise GenerationError(problems)
    return confirmed


def dump(schema: Schema) -> str:
    data = asdict(schema)
    for table in data["tables"]:
        table["check_columns"] = sorted(table["check_columns"])
    return json.dumps({"format_version": FORMAT_VERSION, **data}, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def _table(t: dict) -> Table:
    return Table(**{
        **t,
        "columns": tuple(Column(**{**c, "type_params": tuple(c["type_params"])}) for c in t["columns"]),
        "primary_key": tuple(t["primary_key"]) if t["primary_key"] else None,
        "unique_keys": tuple(Key(**{**k, "columns": tuple(k["columns"])}) for k in t["unique_keys"]),
        "foreign_keys": tuple(ForeignKey(**{**fk, "columns": tuple(fk["columns"]),
                                            "ref_columns": tuple(fk["ref_columns"]) if fk["ref_columns"] else None})
                              for fk in t["foreign_keys"]),
        "check_columns": frozenset(t["check_columns"]),
        "checks": tuple(t["checks"]),
    })


def load(text: str) -> Schema:
    data = json.loads(text)
    if data.get("format_version") != FORMAT_VERSION:
        raise GenerationError([_problem("schema_unsupported_version",
                                        f"schema.json format_version must be {FORMAT_VERSION}, got {data.get('format_version')!r}")])
    return Schema(tuple(_table(t) for t in data["tables"]), tuple(Diagnostic(**d) for d in data["diagnostics"]))
