"""Backfill eligibility: which FK columns may be temporarily NULL during the initial load (plan Phase 5).

Works on a resolved schema (Phase 4), so every FK target and column exists.
"""

from dataclasses import dataclass, field

from dcloneb.model import ForeignKey, Schema, Table


@dataclass(frozen=True)
class Eligibility:
    """Whether an FK can be deferred, and exactly how (planning metadata only)."""

    eligible: bool
    null_columns: tuple[str, ...]  # temporarily NULL during the initial load
    retained_columns: tuple[str, ...]  # keep their values; the backfill must not change them
    fill: tuple[tuple[str, str], ...]  # (child column, parent column) for each nulled column, in FK order
    reasons: dict[str, tuple[str, ...]] = field(default_factory=dict)  # ineligible only: column -> why


def column_reasons(schema: Schema, table: Table, column: str, fk: ForeignKey) -> list[str]:
    """Why `column` may NOT be temporarily nulled while deferring `fk` ([] = eligible).

    Reasons appear in a fixed order. Each one protects another constraint the NULL could violate.
    """
    col = table.column(column)
    reasons = []
    if not col.nullable:
        reasons.append("NOT NULL")
    if table.primary_key and column in table.primary_key:
        reasons.append("primary key")
    if col.generated:
        reasons.append("generated column")
    if column in table.check_columns:
        reasons.append("referenced by CHECK")  # CHECK expressions aren't evaluated, so be conservative
    if any(not k.nulls_distinct and column in k.columns for k in table.unique_keys):
        reasons.append("in UNIQUE NULLS NOT DISTINCT")  # several NULLs would collide
    if any(other is not fk and column in other.columns for other in table.foreign_keys):
        reasons.append("part of another foreign key")  # nulling it would also switch off that FK's check
    # Rows that reference this key would find no parent while it's NULL (MVP: block, don't reason about timing).
    referencing = sorted(
        f"referenced by foreign key {child.name}({', '.join(ref.columns)})"
        for child in schema.tables
        for ref in child.foreign_keys
        if ref.ref_table == table.name and column in ref.ref_columns
    )
    return reasons + referencing


def fk_eligibility(schema: Schema, table: Table, fk: ForeignKey) -> Eligibility:
    """MATCH SIMPLE: null exactly the first eligible column (FK order) and retain the rest.
    MATCH FULL: every column must be eligible; all are nulled together."""
    per_column = {c: column_reasons(schema, table, c, fk) for c in fk.columns}
    eligible_columns = [c for c in fk.columns if not per_column[c]]
    if fk.match == "full":
        nulled = tuple(fk.columns) if len(eligible_columns) == len(fk.columns) else ()
    else:
        nulled = tuple(eligible_columns[:1])
    if not nulled:
        return Eligibility(False, (), (), (), {c: tuple(r) for c, r in per_column.items() if r})
    parent_of = dict(zip(fk.columns, fk.ref_columns))
    return Eligibility(
        eligible=True,
        null_columns=nulled,
        retained_columns=tuple(c for c in fk.columns if c not in nulled),
        fill=tuple((c, parent_of[c]) for c in nulled),
    )
