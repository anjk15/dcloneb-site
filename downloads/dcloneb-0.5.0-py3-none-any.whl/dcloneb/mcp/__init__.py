"""dcloneb for agents: a local MCP server wrapping the Python API (plan4.md).

Only `server.py` (and the CLI commands that start it) import the `mcp` SDK, installed with `dcloneb[mcp]`.
"""
