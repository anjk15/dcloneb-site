"""Approval (plan4 M3, M9). A request hash only binds an approval to one exact request; the approval
itself must come from the user through a channel the agent can't answer (MCP elicitation, or the local
approval page). See plan4.md "Approval design".
"""

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class Approval:
    approved: bool
    method: str  # elicitation | local_page | none
    reason: str = ""


def request_sha256(request, output: Path, revises: Optional[str] = None) -> str:
    """Hash of everything the user approves: the plan, the normalized rules (order-independent), the
    resolved row counts, seed, NULL rate, the output folder, and the earlier run it revises (plan8)."""
    body = {
        "plan_sha256": request.plan.loaded.sha256,
        "rules_sha256": request.rules.sha256 if request.rules else None,
        "rows": dict(sorted(request.rows.items())),
        "seed": request.config["seed"],
        "null_probability": request.config["null_probability"],
        "output": str(output),
    }
    if getattr(request, "scenario", None) is not None:  # plan6: the approval covers the scenario too
        body["scenario_sha256"] = hashlib.sha256(request.scenario.to_json().encode("utf-8")).hexdigest()
    if revises is not None:
        body["revises"] = revises
    return hashlib.sha256(json.dumps(body, sort_keys=True).encode("utf-8")).hexdigest()
