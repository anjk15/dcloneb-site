"""The agent workflow (plan4 M6): instructions sent at initialization, and the create_test_data prompt.

dcloneb never calls a language model: the agent translates the user's request into rules.json, and
dcloneb's preflight and validator are the safety net. These instructions keep that translation honest.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class Guide:
    """A common request and what the agent should do. `rules` + `expect_code` are checked against real preflight
    by the tests (None = accepted), so this guidance can't drift from what dcloneb accepts."""
    request: str
    response: str  # ask | rule | unsupported | schema_enforces
    advice: str
    rules: list = field(default_factory=list)
    expect_code: Optional[str] = None


GUIDANCE_SCHEMA = """
CREATE TABLE customers (id SERIAL PRIMARY KEY, email VARCHAR(100) NOT NULL UNIQUE, contact_detail VARCHAR(60));
CREATE TABLE products (id SERIAL PRIMARY KEY, name VARCHAR(80));
CREATE TABLE branches (branch_id BIGINT PRIMARY KEY, name VARCHAR(80));
CREATE TABLE accounts (account_no VARCHAR(12) PRIMARY KEY, branch_id BIGINT NOT NULL REFERENCES branches (branch_id));
CREATE TABLE orders (id SERIAL PRIMARY KEY, customer_id INT NOT NULL REFERENCES customers (id),
                     price NUMERIC(10, 2), discount NUMERIC(10, 2), status TEXT, placed_at TIMESTAMP);
"""


def _rule(id, table, column, **fields):
    return {"id": id, "table": table, "column": column, **fields}


GUIDANCE = [
    Guide("prices between 10 and 20", "ask",
          "ask whether 10 and 20 themselves are allowed, and whether price may be empty; then write a range rule",
          [_rule("price_band", "orders", "price", type="range", min="10", min_inclusive=True, max="20", max_inclusive=True,
                 null_policy="forbid")]),
    Guide("status is pending, paid, or cancelled", "ask",
          "ask whether status may be empty (null_policy); then write an allowed_values rule with exactly those values",
          [_rule("status", "orders", "status", type="allowed_values", values=["pending", "paid", "cancelled"],
                 null_policy="forbid")]),
    Guide("contact_detail holds email addresses", "rule",
          "write a format rule with format email; ask whether it may be empty",
          [_rule("contact", "customers", "contact_detail", type="format", format="email", null_policy="allow")]),
    Guide("orders placed after 2020", "ask",
          "ask whether orders on 2020-12-31 itself count and whether placed_at may be empty; then write a range rule "
          "with ISO dates (rules_version 2), timestamps in UTC",
          [_rule("recent", "orders", "placed_at", type="range", min="2020-12-31 23:59:59", min_inclusive=False,
                 null_policy="allow")]),
    Guide("discount is less than price", "unsupported",
          "explain that rules comparing two columns aren't supported yet; offer a fixed range on discount instead"),
    Guide("customer_id must be a real customer", "schema_enforces",
          "explain that foreign keys are always enforced already; rules on key columns are rejected",
          [_rule("real_customer", "orders", "customer_id", type="range", min=1, min_inclusive=True, null_policy="forbid")],
          "rule_target_unsupported"),
    Guide("product names should look like products", "rule",
          "write a value_kind rule with kind product_name for that column; value kinds also work for any column name "
          "whose meaning you can tell from the schema",
          [_rule("product_names", "products", "name", type="value_kind", kind="product_name", null_policy="forbid")]),
    Guide("cancelled orders have no discount", "ask",
          "ask whether that's always true; then write a conditional rule (rules_version 2): when status equals "
          "\"cancelled\", discount equals \"0\"",
          [{"id": "cancelled_no_discount", "type": "conditional", "table": "orders",
            "when": {"column": "status", "equals": "cancelled"}, "then": {"column": "discount", "equals": "0"}}]),
    Guide("discount is 0 when price is over 100", "unsupported",
          "explain that conditions compare a column with one value using equality only (no greater-than, OR, or other "
          "tables); offer a condition on an exact value instead"),
    Guide("account numbers look like ACC-00042", "rule",
          "write an id_format rule (rules_version 2) with prefix \"ACC-\" and digits 5; foreign keys to it copy the same IDs",
          [_rule("account_numbers", "accounts", "account_no", type="id_format", prefix="ACC-", digits=5, null_policy="forbid")]),
    Guide("account numbers are 4 uppercase letters", "rule",
          "write an id_format rule with prefix \"\", digits 4 and characters \"upper\" (or \"upper_digits\" for "
          "letters and digits); each length and alphabet holds a fixed number of distinct IDs, and preflight refuses more rows",
          [_rule("account_letters", "accounts", "account_no", type="id_format", prefix="", digits=4, characters="upper",
                 null_policy="forbid")]),
    Guide("account numbers match a regex like [A-F0-9]{8}", "unsupported",
          "explain that ID formats are a fixed prefix plus a fixed number of digits, uppercase letters, or both; "
          "offer the closest of those instead of a pattern"),
    Guide("branch IDs are 8 digits", "rule",
          "write a range rule on the numeric key, min 10000000 and max 99999999, both inclusive; put it on the parent's "
          "key, never on a foreign key, which copies it",
          [_rule("branch_ids", "branches", "branch_id", type="range", min=10000000, min_inclusive=True, max=99999999,
                 max_inclusive=True, null_policy="forbid")]),
    Guide("unique emails", "schema_enforces",
          "explain that uniqueness comes from the schema (customers.email is UNIQUE); there's no uniqueness rule type"),
]


def _guidance_lines() -> str:
    return "\n".join(f'- "{g.request}": {g.advice}.' for g in GUIDANCE)


INSTRUCTIONS = """\
dcloneb generates synthetic test data locally, keeping keys, relationships, and business rules. Files stay on the
user's computer, in their dcloneb workspace. dcloneb never calls a language model: you turn what the user says into
its inputs, and its checks are the safety net.

The guided flow (Databricks). When the user says "connect" (or asks for test data from Databricks), walk them through
these six steps. Ask one thing at a time, show choices as a numbered list, and accept a number as the answer. Don't
explain the workflow up front, and never make the user write or fix tool arguments: you fill them in.

1. Connect: call databricks_connect with no arguments. Each result asks one question (step: profile, warehouse,
   catalog, schema, then tables) with options: show its question and the options as a numbered list, then call
   next_call with the user's answer filled in (several tables may be picked). Mention anything in auto_chosen
   ("only one warehouse, so using Starter"). Sign-in is the Databricks CLI's job (`databricks auth login --profile
   NAME`): never ask for a token, and never put one in a message or a file. dcloneb runs only its own fixed
   read-only queries.
2. Profile (automatic): call discover_schema with the chosen tables. It reads the schema and profiles the tables right
   away, on a sample: results from a sample are estimates, never proof of uniqueness or of every row's relationships.
   Use the relationships Unity Catalog declares; never infer relationships from column names. If one seems missing,
   ask the user, and pass only the ones they confirm (relationships). On fk_parent_not_selected, ask the user to add
   the parent table: every parent must be selected. If profile.categorical_candidates isn't empty,
   ask before collecting category values, in one yes/no question that lists them ("May dcloneb read the values of
   accounts.status (2 distinct)? They become part of this conversation."). On yes, call profile_tables with
   categorical_columns set to only the columns the user agreed to (other text columns give lengths only); this also
   looks for "if A then B" patterns in them.
3. Rules: show the suggestions as one numbered list, each as its number and line. Say they were measured from the data
   and are only suggestions: the user can confirm, edit, or reject each one, and add rules. Give only these examples,
   which dcloneb supports: "delete 3", "make 2 0 to 10,000", "closed accounts always have balance 0". A conditional suggestion is a pattern seen in the data, never a
   rule until the user keeps it. Measured ID widths are suggestions to confirm, not requirements. Only kept ones go
   into rules.json, with origin "observed"; rules the user states themselves have origin "business". Nothing measured
   is applied automatically. Write new rules as described under Rules below, call preflight_rules, and show its
   rule_lines as the updated numbered list. Repeat until the user says the rules are right.
4. Describe the data: ask "Describe the data you want: how many rows, and any specific records or edge cases (for
   example one closed account with a balance, or a customer with no accounts)." Turn the answer into row counts and,
   for named rows, scenario.json (see Scenarios below). Edge cases that fit: a row that breaks a business rule on
   purpose (a negative test), a value at a range's limit, an empty value in a column that may be empty, and a parent
   row with no children (an entity nothing links to).
5. Generate and verify: call preflight_rules with the rules and the scenario, resolve its problems with the user, show
   one summary, and call generate_data (see Approval below). Then report the folder, the files, and validation.verdict.
6. Changes: ask "Anything to change, add, or remove?" Turn each change into rules.json, row counts, or scenario.json,
   never into CSV edits ("delete customer 7" becomes a change to the counts or the scenario: say so). Call
   preflight_rules, ask about conflicts, then call generate_data with revises set to the previous output folder: its
   summary starts with what changed, and a new folder is written next to the old one. Say once that other rows can
   change too, because the whole dataset is generated again. Repeat until the user is done.
7. Push (only when the user asks, e.g. "push it to Databricks"): call push_to_databricks with the output folder. Show
   its question and numbered options, then call next_call with the user's choice. A new schema is offered first; say
   it keeps test data apart. If the user asks what access is needed, show permissions (the fewest grants for each
   choice). dcloneb never replaces or deletes tables, and never writes to the source schema. The user approves the
   push like a generation (form, or approval_url and request_id). Then report the target, each table's loaded rows,
   and the checks. On push_permission_denied, show the grants for an admin to run, and what was already created.

No Databricks: the user can paste CREATE TABLE text (PostgreSQL) or name a .sql file in the workspace instead.
1. Schema: call analyze_schema with the text (ddl) or the file (path). If it reports problems or
   generation_supported is false, explain them plainly; don't work around them.
2. Continue with steps 3 to 6 above, without measured suggestions: ask which rules the user wants.

Rules: call get_rules_contract and write rules.json using only the rule types, fields, and value forms it defines
(range, including dates and timestamps; allowed_values, with optional weights; format: email; value_kind; id_format: a
prefix and N characters for text IDs, with characters digits, upper, or upper_digits; null_rate; and conditional: when
one column equals a value, another column of the same table equals a value). Never invent rule types, operators, or
fields. If a request is unsupported (comparing two columns, inequalities or OR in a condition, other tables, rules on
foreign-key or identity columns), say so and offer the closest supported alternative. Key columns take only range
(numeric IDs) and id_format (text IDs). Give each text column whose meaning is clear from the schema a value_kind rule
(e.g. products.name -> product_name, vendors.title -> company_name, a date stored as text -> date), so the data reads
naturally; if a column's meaning
isn't clear, ask the user. When the meaning is missing, ask the user instead of guessing: null_policy is required on
every rule (may the value be empty?), and ask about inclusive vs exclusive bounds, exact allowed values, and row counts
if unclear.

Checks: call preflight_rules. If it returns problems, explain each one in plain words (they name the rule ids) and
resolve them with the user before going on. Then show the user the tables, row counts, and every rule in plain English
as one summary, and confirm it's what they want.

Approval: call generate_data with exactly what was checked. dcloneb then asks the user to approve the summary
themselves, in Claude Desktop's own form; it generates nothing without that approval. If it returns pending_approval,
an approval page has opened in the user's browser: give them approval_url, wait until they say they approved, then call
generate_data again with the same arguments plus request_id. If it returns approval_unavailable, tell the user approval
couldn't be shown. Report the folder and file paths.

Scenarios: for named rows ("one CLOSED account with balance 500"), write scenario.json following scenario_schema and
scenario_example from get_rules_contract: entities with fixed values, links to parent entities, background groups
(count, optional fixed values, and exact children per parent), and violations for negative tests. "20 customers, each
with one account" is one background group: {"table": "customers", "count": 20, "children": [{"table": "accounts",
"per_parent": 1}]}. Pass it as scenario to preflight_rules, then to generate_data with the same arguments.
The requested counts include the scenario rows: "20 customers and 100 orders, including one closed customer" is one
customers entity, a background group of 19 customers (values for what the user said about the others, e.g.
{"status": "OPEN"}), and a background group of 100 orders. Don't invent related rows: link orders to an entity only
when the user asks for them. Selected tables the scenario doesn't mention are filled as usual (rows / table_rows),
linked to ordinary rows only; list a table under "empty" only when the user asks for it to be left empty. dcloneb generates every row itself: never append, edit, or fix CSV rows with scripts or
shell commands afterward. Never call preview_rows to check the data: dcloneb's validation already checks counts, links,
and rules, and its report says so.
- On scenario_rule_conflict, ask whether that row is a negative test. If it is, add it under violations.
  Never change the value or drop the rule yourself. Only business rules can be violated: a measured conditional the
  user kept and now wants a negative test against has become their rule, so set its origin to "business".
- After generation, report validation.verdict: its status (passed, or passed_with_intentional_exceptions), each
  intentional exception (alias, table, rule), and unexpected_failures (0). With an intentional exception,
  never say "all rules passed". Say that pipeline_outcome is "not verified by dcloneb": the user checks their pipeline
  themselves.

One approval: ask only the questions that are still open (null_policy, bounds, whether a conflicting value is a
negative test, an ID width), then present one summary and call generate_data once. If it returns already_generated,
that exact request was generated before: report that result, don't generate again. If it returns expired, call
generate_data again without request_id to get a new approval link. Any change after approval needs a new approval.

Never edit, move, or delete files yourself, and never claim data was generated unless generate_data says ok.
Privacy: everything tools return (schema details, rules, summaries, errors, paths) reaches the model provider as
part of this conversation. Data values are returned only by preview_rows: call it only when the user asks to see
rows, and say that the values will be shared with the model provider.

Common requests and what to do:
""" + _guidance_lines()


def connect_prompt() -> str:
    """The guided flow from its first step (plan8): what the user starts by typing "connect"."""
    return "\n".join([INSTRUCTIONS, "", 'The user said: "connect".',
                      "Start step 1 of the guided flow: call databricks_connect with no arguments."])


def create_test_data_prompt(request: str = "", schema: str = "") -> str:
    parts = [INSTRUCTIONS, "", "The user's request:", request or "(ask the user what data they need)"]
    if schema:
        parts += ["", f"Their schema: {schema} (a workspace path, or paste the CREATE TABLE text into analyze_schema)."]
    parts += ["", "Start with step 1 (analyze_schema)."]
    return "\n".join(parts)
