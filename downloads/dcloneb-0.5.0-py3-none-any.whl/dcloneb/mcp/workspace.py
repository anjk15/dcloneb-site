"""The workspace guard (plan4 M1.1): every path a tool reads or writes must resolve inside the folder
the user chose at setup. `..`, absolute paths elsewhere, and symlinks that lead out are rejected."""

import re
from pathlib import Path
from typing import Union

from dcloneb.generate.errors import GenerationError, Problem

NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")  # output folder names: no separators, no leading dot or dash


def _fail(code: str, message: str) -> GenerationError:
    return GenerationError([Problem("input", code, message)])


class Workspace:
    def __init__(self, root: Union[str, Path]):
        path = Path(root).expanduser()
        if not path.is_dir():
            raise _fail("workspace_invalid", f"workspace {path} is not an existing folder; choose one with "
                                             "`dcloneb mcp install --workspace PATH`")
        self.root = path.resolve()

    def contains(self, path: Path) -> bool:
        return path == self.root or self.root in path.parents

    def resolve(self, path: str, must_exist: bool = False) -> Path:
        """The real location of `path` (relative to the workspace, or absolute), only if it is inside."""
        if not path or path.startswith("~"):
            raise _fail("workspace_path_outside", f"{path!r} is not a path inside the workspace {self.root}")
        candidate = Path(path)
        real = (candidate if candidate.is_absolute() else self.root / candidate).resolve()  # follows symlinks
        if not self.contains(real):
            raise _fail("workspace_path_outside",
                        f"{path!r} leads outside the workspace {self.root}; tools can only use files inside it")
        if must_exist and not real.exists():
            raise _fail("workspace_path_missing", f"{path!r} doesn't exist in the workspace {self.root}")
        return real

    def free_output(self, name: str) -> Path:
        """A new folder for a bundle: `name`, else `name-2`, `name-3`, ... Never an existing entry (a dcloneb
        tool never overwrites)."""
        if not NAME.fullmatch(name or ""):
            raise _fail("workspace_name_invalid",
                        f"output name {name!r} must be letters, digits, '.', '_' or '-', starting with a letter or digit")
        candidate, n = self.root / name, 1
        while candidate.exists() or candidate.is_symlink():  # is_symlink: a dangling link is taken too
            n += 1
            candidate = self.root / f"{name}-{n}"
        return candidate
