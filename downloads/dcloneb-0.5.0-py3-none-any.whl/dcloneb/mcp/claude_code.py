"""Claude Code setup: add or remove dcloneb for Claude Code (the CLI, and Claude in VS Code).

Claude Code owns its config file, so dcloneb registers through `claude mcp add --scope user` (all your
projects) and never edits that file. `dcloneb mcp test --client claude-code` reads it to check the entry.

Approval with Claude Code is a guardrail, not a guarantee: Claude Code can run shell commands, so it could
generate data without the approval step (for example with `dcloneb make`) or act on the approval page.
"""

import os
import shutil
import subprocess
from pathlib import Path
from typing import Callable, Optional

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.mcp.claude_desktop import SERVER_NAME, server_args
from dcloneb.mcp.limits import DEFAULT_PER_TABLE, DEFAULT_TOTAL


def config_path(home: Optional[Path] = None) -> Path:
    """Where Claude Code keeps user-scope MCP servers (DCLONEB_CLAUDE_CODE_CONFIG overrides, e.g. for tests)."""
    override = os.environ.get("DCLONEB_CLAUDE_CODE_CONFIG")
    return Path(override) if override else (home or Path.home()) / ".claude.json"


def _claude(which: Callable) -> str:
    found = which("claude")
    if not found:
        raise GenerationError([Problem("input", "claude_code_not_found",
                                       "can't find the `claude` command; install Claude Code first "
                                       "(https://claude.com/claude-code), then run this again")])
    return found


def install(executable: Path, workspace: Path, per_table: int = DEFAULT_PER_TABLE, total: int = DEFAULT_TOTAL,
            run: Callable = subprocess.run, which: Callable = shutil.which) -> None:
    claude = _claude(which)
    workspace = workspace.expanduser().resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    run([claude, "mcp", "remove", "--scope", "user", SERVER_NAME], capture_output=True, text=True)  # an older entry
    added = run([claude, "mcp", "add", "--scope", "user", SERVER_NAME, "--", str(executable),
                 *server_args(workspace, per_table, total)], capture_output=True, text=True)
    if added.returncode != 0:
        raise GenerationError([Problem("input", "claude_code_add_failed",
                                       f"`claude mcp add` failed: {(added.stderr or added.stdout).strip()}")])


def uninstall(run: Callable = subprocess.run, which: Callable = shutil.which) -> bool:
    """True if dcloneb was removed, False if it wasn't there."""
    removed = run([_claude(which), "mcp", "remove", "--scope", "user", SERVER_NAME], capture_output=True, text=True)
    return removed.returncode == 0
