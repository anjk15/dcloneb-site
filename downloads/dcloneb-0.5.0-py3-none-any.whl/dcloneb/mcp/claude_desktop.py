"""Claude Desktop setup (plan4 M11): add or remove the dcloneb server entry in Claude Desktop's config.

The config also holds the user's other settings, so this:
- merges, never replaces, and keeps every other key exactly;
- writes a timestamped backup first;
- refuses a file it can't parse;
- writes atomically;
- removes only its own entry.
"""

import datetime as dt
import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.mcp.limits import DEFAULT_PER_TABLE, DEFAULT_TOTAL

SERVER_NAME = "dcloneb"
FILE_NAME = "claude_desktop_config.json"


def _fail(code: str, message: str) -> GenerationError:
    return GenerationError([Problem("input", code, message)])


def config_path(platform: str = sys.platform, home: Optional[Path] = None, appdata: Optional[str] = None) -> Path:
    """Where Claude Desktop reads its config (DCLONEB_CLAUDE_CONFIG overrides, e.g. for tests)."""
    override = os.environ.get("DCLONEB_CLAUDE_CONFIG")
    if override:
        return Path(override)
    home = home or Path.home()
    if platform == "darwin":
        return home / "Library" / "Application Support" / "Claude" / FILE_NAME
    if platform == "win32":
        return Path(appdata or os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))) / "Claude" / FILE_NAME
    raise _fail("claude_desktop_unsupported_platform",
                f"Claude Desktop runs on macOS and Windows; {platform!r} isn't supported by `dcloneb mcp install`")


QUIT_FIRST = ("Quit Claude Desktop first (Cmd+Q on Mac; on Windows, right-click its tray icon and choose Quit), "
              "then run this again. It rewrites its config when it quits, which would undo this change. "
              "Nothing was changed.")


def claude_running(platform: str = sys.platform, run: Callable = subprocess.run) -> bool:
    """Whether Claude Desktop is open. If that can't be checked, assume it isn't (never block on a guess)."""
    try:
        if platform == "darwin":
            return run(["pgrep", "-x", "Claude"], capture_output=True, text=True).returncode == 0
        if platform == "win32":
            found = run(["tasklist", "/FI", "IMAGENAME eq Claude.exe", "/NH"], capture_output=True, text=True)
            return "claude.exe" in (found.stdout or "").lower()
    except (OSError, subprocess.SubprocessError):
        pass
    return False


@dataclass(frozen=True)
class Change:
    config: Path
    backup: Optional[Path]
    removed: bool = False


def read_config(config: Path) -> dict:
    if not config.exists():
        return {}
    try:
        data = json.loads(config.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise _fail("claude_desktop_config_invalid",
                    f"{config} isn't valid JSON ({e}); fix or move it, then run this again. Nothing was changed.") from None
    if not isinstance(data, dict) or not isinstance(data.get("mcpServers", {}), dict):
        raise _fail("claude_desktop_config_invalid",
                    f"{config} doesn't have the expected shape (an object, with mcpServers an object). Nothing was changed.")
    return data


def _backup(config: Path) -> Optional[Path]:
    if not config.exists():
        return None
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = config.with_name(f"{config.name}.dcloneb-backup-{stamp}")
    n = 1
    while backup.exists():
        n += 1
        backup = config.with_name(f"{config.name}.dcloneb-backup-{stamp}-{n}")
    shutil.copy2(config, backup)
    return backup


def _write(config: Path, data: dict) -> None:
    config.parent.mkdir(parents=True, exist_ok=True)
    temp = config.with_name(f".{config.name}.dcloneb-tmp")
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(temp, config)  # atomic: Claude Desktop never sees a half-written file


def server_args(workspace: Path, per_table: int, total: int) -> list[str]:
    """How an agent app starts dcloneb (after the executable)."""
    return ["mcp", "serve", "--workspace", str(workspace),
            "--max-rows-per-table", str(per_table), "--max-rows-total", str(total)]


def install(config: Path, executable: Path, workspace: Path, per_table: int = DEFAULT_PER_TABLE,
            total: int = DEFAULT_TOTAL) -> Change:
    if not executable.is_absolute():
        raise _fail("executable_invalid", f"the dcloneb executable must be an absolute path, got {executable}")
    data = read_config(config)  # refuses bad JSON before anything else happens
    workspace = workspace.expanduser().resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    backup = _backup(config)
    data.setdefault("mcpServers", {})[SERVER_NAME] = {"command": str(executable),
                                                      "args": server_args(workspace, per_table, total)}
    _write(config, data)
    return Change(config, backup)


def uninstall(config: Path) -> Change:
    data = read_config(config)
    if SERVER_NAME not in data.get("mcpServers", {}):
        return Change(config, None, removed=False)
    backup = _backup(config)
    del data["mcpServers"][SERVER_NAME]
    _write(config, data)
    return Change(config, backup, removed=True)


def find_executable() -> Optional[Path]:
    """The dcloneb command Claude Desktop should start: the one running now if it is the console script,
    else the one next to this Python, else the first on PATH. Not resolved through symlinks, so a `uv tool`
    install's stable link in ~/.local/bin survives upgrades."""
    running = Path(sys.argv[0])
    if running.name.startswith("dcloneb") and running.exists():
        return Path(os.path.abspath(running))
    sibling = Path(sys.executable).parent / ("dcloneb.exe" if sys.platform == "win32" else "dcloneb")
    if sibling.exists():
        return sibling
    found = shutil.which("dcloneb")
    return Path(found) if found else None
