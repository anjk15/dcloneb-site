"""Row limits (plan4 M1.2): set at install time, checked before approval is asked."""

from dataclasses import dataclass

from dcloneb.generate.errors import GenerationError, Problem

DEFAULT_PER_TABLE = 100_000
DEFAULT_TOTAL = 1_000_000


@dataclass(frozen=True)
class Limits:
    per_table: int = DEFAULT_PER_TABLE
    total: int = DEFAULT_TOTAL

    def __post_init__(self):
        if self.per_table < 1 or self.total < 1 or self.per_table > self.total:
            raise ValueError(f"limits must be positive with per_table <= total; got {self.per_table}, {self.total}")

    def check(self, rows: dict[str, int]) -> None:
        problems = [Problem("input", "row_limit_exceeded",
                            f"{table}: {n} rows requested, but this workspace allows at most {self.per_table} per table "
                            "(set at install time); ask for fewer rows")
                    for table, n in rows.items() if n > self.per_table]
        total = sum(rows.values())
        if total > self.total:
            problems.append(Problem("input", "row_limit_exceeded",
                                    f"{total} rows requested in total, but this workspace allows at most {self.total}"))
        if problems:
            raise GenerationError(problems)
