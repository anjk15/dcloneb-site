"""The dcloneb MCP server (plan4): tools that wrap `dcloneb.generate.api`, run locally over stdio.

The only module that imports the `mcp` SDK (installed with `dcloneb[mcp]`).
"""

import json
import secrets
import time
import webbrowser
from dataclasses import dataclass
from typing import Annotated, Any, Optional

from mcp.server.mcpserver import Context, Elicit, MCPServer, Resolve
from mcp.types import ToolAnnotations
from pydantic import BaseModel, Field

from dcloneb import __version__
from dcloneb.generate.rules.contract import SCHEMA
from dcloneb.generate.rules.registry import COMBINING, NULL_BEHAVIOR, render_rules_table
from dcloneb.generate.support import render_matrix
from dcloneb.mcp import tools
from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.mcp.approval import Approval
from dcloneb.mcp.approval_page import ApprovalPage
from dcloneb.mcp.limits import Limits
from dcloneb.mcp.workflow import INSTRUCTIONS, connect_prompt, create_test_data_prompt
from dcloneb.mcp.workspace import Workspace

class Approve(BaseModel):
    """The approval form the client shows the user."""
    approve: bool = Field(title="Approve", description="Tick to generate exactly the data described above")


class ApprovePush(BaseModel):
    """The approval form for loading a run into Databricks (plan9)."""
    approve: bool = Field(title="Approve", description="Tick to load exactly these tables into Databricks")


@dataclass(frozen=True)
class NotAsked:
    reason: str  # problems | no_user_channel | local_page | already_generated


WRITES_NEW_FILES = ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=False, open_world_hint=False)
WRITES_DATABRICKS = ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=False, open_world_hint=True)


def _pending(request_id: str, page: ApprovalPage, summary: str, tool: str = "generate_data") -> dict[str, Any]:
    done = "generated" if tool == "generate_data" else "sent to Databricks"
    return {"ok": False, "status": "pending_approval", "request_id": request_id, "approval_url": page.url,
            "summary": summary,
            "message": f"Nothing {done} yet. The user must approve on the page that opened in their browser "
                       f"(or open approval_url); then call {tool} again with the same arguments and request_id."}


READ_ONLY = ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=False)
READS_DATABRICKS = ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=True)


def build_server(workspace: Workspace, limits: Limits, opener=webbrowser.open, clock=time.monotonic,
                 connect=None, profiles=None, warehouses=None, files=None) -> MCPServer:
    """`opener` opens the local approval page in the user's browser; tests pass a no-op. `connect` (profile,
    warehouse_id) -> connection, `profiles` () -> profiles and `warehouses` (profile) -> warehouses replace the
    Databricks connector and listings in tests; `files` (profile) -> the Files API replaces uploads (plan9)."""
    state = tools.State(workspace, limits, connect=connect, profiles=profiles, warehouses=warehouses, files=files)
    pending: dict[str, tuple[ApprovalPage, str]] = {}  # request_id -> (local approval page, request hash)

    def page_flow(prepared, request_id: Optional[str], run=None, tool: str = "generate_data") -> dict[str, Any]:
        """The fallback for clients without approval forms: the user approves on a local page, then the agent
        calls again with request_id. Generates only the exact request the user approved."""
        if request_id is None:
            page = ApprovalPage(prepared.summary, prepared.sha, opener=opener, clock=clock,
                                details=getattr(prepared, "details", None),
                                kind="generate" if tool == "generate_data" else "push")
            try:
                page.start()
            except OSError as e:
                return {"ok": False, "status": "approval_unavailable",
                        "message": f"couldn't open a local approval page ({e}); nothing was generated"}
            request_id = secrets.token_hex(8)
            pending[request_id] = (page, prepared.sha)
            return _pending(request_id, page, prepared.summary, tool)
        if request_id not in pending:
            return tools.problems_result(GenerationError([Problem(
                "input", "unknown_request_id", f"no pending approval {request_id!r}; call {tool} without request_id")]))
        page, approved_sha = pending[request_id]
        if approved_sha != prepared.sha:
            del pending[request_id]
            page.close()
            return {"ok": False, "status": "request_changed",
                    "message": "these arguments differ from the request the user was asked about; nothing was generated"}
        decision = page.decision
        if decision is None:
            return _pending(request_id, page, prepared.summary, tool)
        del pending[request_id]
        page.close()
        if decision == "expired":
            return {"ok": False, "status": "expired", "message": "the approval link expired; nothing was generated",
                    "next_step": f"call {tool} again without request_id to get a new approval link, and give it "
                                 "to the user"}
        return (run or tools.run_generation)(state, prepared, Approval(decision == "approved", "local_page",
                                                                       "the user declined on the approval page"), prepared.sha)
    server = MCPServer(name="dcloneb", version=__version__, instructions=INSTRUCTIONS, log_level="WARNING")

    @server.tool(annotations=READ_ONLY)
    def get_capabilities() -> dict[str, Any]:
        """What dcloneb supports: column types, schema features, rule types, row limits, and the privacy note."""
        return tools.get_capabilities(state)

    @server.tool(annotations=READ_ONLY)
    def get_rules_contract() -> dict[str, Any]:
        """The rules.json contract: its JSON Schema, what each rule type means, and an example; and the scenario.json
        contract (scenario_schema, scenario_example) for named rows and edge cases. Draft both only from this."""
        return tools.get_rules_contract(state)

    @server.tool(annotations=READ_ONLY)
    def analyze_schema(ddl: Optional[str] = None, path: Optional[str] = None) -> dict[str, Any]:
        """Analyze a PostgreSQL schema: pass `ddl` (the CREATE TABLE text) or `path` (a .sql file inside the
        workspace). Returns a plan_id and a summary of tables, keys, and relationships. Writes nothing."""
        return tools.analyze_schema(state, ddl=ddl, path=path)

    @server.tool(annotations=READ_ONLY)
    def preflight_rules(plan_id: str, rules: Optional[dict[str, Any]] = None, rows: int = tools.DEFAULT_ROWS,
                        table_rows: Optional[dict[str, int]] = None, seed: int = tools.DEFAULT_SEED,
                        null_probability: float = tools.DEFAULT_NULL_PROBABILITY,
                        scenario: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        """Check business rules (rules.json, optional), row counts, and a scenario (scenario.json, optional: named rows,
        links, background groups, declared negative tests; its row counts replace rows/table_rows) against an analyzed
        schema, before generating. Returns the normalized rules, rule_lines (the rules numbered in plain words, to show
        the user), and resolved rows, or problems to resolve. Writes nothing."""
        return tools.preflight_rules(state, plan_id, rules, rows, table_rows, seed, null_probability, scenario)

    @server.tool(annotations=READS_DATABRICKS)
    def databricks_connect(profile: Optional[str] = None, warehouse_id: Optional[str] = None, catalog: Optional[str] = None,
                           schema: Optional[str] = None) -> dict[str, Any]:
        """Start here when the user says "connect". Call it with no arguments: each result asks one question (step:
        profile, warehouse, catalog, schema, then tables) with numbered options; show them, and call next_call with the
        user's choice filled in. A single option is chosen automatically (auto_chosen). Sign-in is the Databricks CLI
        profile's job (`databricks auth login`): never ask the user for a token."""
        return tools.databricks_connect(state, profile, warehouse_id, catalog, schema)

    @server.tool(annotations=READS_DATABRICKS)
    def discover_schema(tables: list[str], relationships: Optional[list[dict[str, Any]]] = None,
                        unique_keys: Optional[list[dict[str, Any]]] = None, profile: str = "sample",
                        sample_rows: int = tools.db.SAMPLE_ROWS) -> dict[str, Any]:
        """Read the selected tables' columns and declared keys (Unity Catalog), plus relationships
        ({"table", "columns", "references": {"table", "columns"}}) and unique keys ({"table", "columns"}) the user
        confirmed. Returns a plan_id like analyze_schema, and the tables available. Every parent table must be selected.
        Also profiles the tables right away (profile: "sample" by default, "full", or "none") and returns, under
        profile, the suggested settings and the categorical_candidates whose values may be read only after the user says yes."""
        return tools.discover_schema(state, tables, relationships, unique_keys, profile, sample_rows)

    @server.tool(annotations=READS_DATABRICKS)
    def profile_tables(plan_id: str, categorical_columns: Optional[dict[str, list[str]]] = None, mode: str = "sample",
                       sample_rows: int = tools.db.SAMPLE_ROWS) -> dict[str, Any]:
        """Measure the discovered tables with fixed aggregate queries (a sample by default; mode "full" scans all rows)
        and return numbered suggested settings (number, line) for the user to confirm, edit, or reject. Category values
        are read only for categorical_columns ({table: [column]}) the user approved; for those, "if A then B" patterns
        come back as conditional suggestions. discover_schema already profiles once: call this after the user agrees to
        category values."""
        return tools.profile_tables(state, plan_id, categorical_columns, mode, sample_rows)

    def ask_user(plan_id: str, ctx: Context, rules: Optional[dict[str, Any]] = None, rows: int = tools.DEFAULT_ROWS,
                 table_rows: Optional[dict[str, int]] = None, seed: int = tools.DEFAULT_SEED,
                 null_probability: float = tools.DEFAULT_NULL_PROBABILITY, output: str = "generated",
                 request_id: Optional[str] = None, scenario: Optional[dict[str, Any]] = None, revises: Optional[str] = None):
        """Resolver for `approval`: describe the request and ask the *user* through the client's own UI.
        Never returns an outcome object of its own (the SDK would coerce it into an acceptance; plan4 M0)."""
        if request_id is not None:
            return NotAsked("local_page")  # a second call for a page approval: don't ask again here
        prepared = tools.prepare_generation(state, plan_id, rules, rows, table_rows, seed, null_probability, output, scenario,
                                               revises)
        if not isinstance(prepared, tools.Prepared):
            return NotAsked("problems")  # the tool body returns those problems; the user is never asked
        if tools.finished(state, prepared):
            return NotAsked("already_generated")  # the body returns the earlier result
        caps = ctx.client_capabilities
        if not (caps and caps.elicitation):
            return NotAsked("no_user_channel")
        state.asked.add(prepared.sha)  # idempotent: the body generates only a request that was shown to the user
        return Elicit(f"{prepared.summary}\n\nApprove generating this data? (request {prepared.sha[:12]})", Approve)

    @server.tool(annotations=WRITES_NEW_FILES)
    def generate_data(plan_id: str, approval: Annotated[Any, Resolve(ask_user)], rules: Optional[dict[str, Any]] = None,
                      rows: int = tools.DEFAULT_ROWS, table_rows: Optional[dict[str, int]] = None,
                      seed: int = tools.DEFAULT_SEED, null_probability: float = tools.DEFAULT_NULL_PROBABILITY,
                      output: str = "generated", request_id: Optional[str] = None,
                      scenario: Optional[dict[str, Any]] = None, revises: Optional[str] = None) -> dict[str, Any]:
        """Generate test data locally into a new folder in the workspace (never overwriting). The user is asked
        to approve a plain-English summary first, in Claude Desktop's own form; nothing is written without that.
        If the result is pending_approval, give the user the approval_url (it also opens in their browser), and
        after they approve call generate_data again with the same arguments plus request_id.
        Returns file paths, row counts, and check results, not data values. Pass the same scenario preflight_rules checked.
        Calling again with the same arguments after it generated returns that result (status already_generated);
        any change is a new request the user approves again. For changes after a run, pass revises (the earlier
        output folder): the summary then starts with what changed, and a new folder is written next to the old one."""
        prepared = tools.prepare_generation(state, plan_id, rules, rows, table_rows, seed, null_probability, output, scenario,
                                               revises)
        if not isinstance(prepared, tools.Prepared):
            return prepared  # problems, found before asking anyone
        earlier = tools.finished(state, prepared)
        if earlier:
            if request_id in pending:
                pending.pop(request_id)[0].close()
            return earlier
        if request_id is not None or (isinstance(approval, NotAsked) and approval.reason == "no_user_channel"):
            return page_flow(prepared, request_id)
        approved = isinstance(approval, Approve) and approval.approve is True and prepared.sha in state.asked
        state.asked.discard(prepared.sha)
        decision = Approval(approved, "elicitation", "" if approved else "the user didn't approve")
        return tools.run_generation(state, prepared, decision, prepared.sha if approved else "")

    def ask_push(output: str, ctx: Context, catalog: Optional[str] = None, schema: Optional[str] = None,
                 request_id: Optional[str] = None):
        """Resolver for push_to_databricks's approval (plan9): asks only once the target is chosen and checked."""
        if request_id is not None:
            return NotAsked("local_page")
        prepared = tools.push_to_databricks(state, output, catalog, schema)
        if not isinstance(prepared, tools.PreparedPush):
            return NotAsked("problems")  # a question or problems: the body returns it, nobody is asked
        caps = ctx.client_capabilities
        if not (caps and caps.elicitation):
            return NotAsked("no_user_channel")
        state.asked.add(prepared.sha)
        return Elicit(f"{prepared.summary}\n\nApprove loading this into Databricks? (request {prepared.sha[:12]})", ApprovePush)

    @server.tool(annotations=WRITES_DATABRICKS)
    def push_to_databricks(output: str, approval: Annotated[Any, Resolve(ask_push)], catalog: Optional[str] = None,
                           schema: Optional[str] = None, request_id: Optional[str] = None) -> dict[str, Any]:
        """Load a run (an output folder made from Databricks tables) into Databricks. Call it with just output: each
        result asks one question (step: catalog, then target) with numbered options; show them, and call next_call with
        the user's choice. A new schema is offered first; the source schema and schemas that already have these tables
        are never offered, and dcloneb never replaces or deletes anything. Once the target is chosen, the user is asked
        to approve the push (as with generate_data: in the client's form, or on a local page with request_id). Then it
        creates the tables, uploads and loads the CSVs, and checks row counts and foreign keys. Show the user
        permissions (the fewest grants needed) when asked, and grants on push_permission_denied."""
        prepared = tools.push_to_databricks(state, output, catalog, schema)
        if not isinstance(prepared, tools.PreparedPush):
            return prepared
        if request_id is not None or (isinstance(approval, NotAsked) and approval.reason == "no_user_channel"):
            return page_flow(prepared, request_id, tools.run_push, "push_to_databricks")
        approved = isinstance(approval, ApprovePush) and approval.approve is True and prepared.sha in state.asked
        state.asked.discard(prepared.sha)
        decision = Approval(approved, "elicitation", "" if approved else "the user didn't approve")
        return tools.run_push(state, prepared, decision, prepared.sha if approved else "")

    @server.resource("dcloneb://rules/schema.json", mime_type="application/json",
                     description="The rules.json JSON Schema (version 1). Rules must validate against it.")
    def rules_schema() -> str:
        return json.dumps(SCHEMA, indent=2)

    @server.resource("dcloneb://rules/semantics.md", mime_type="text/markdown",
                     description="What each rule type means, how NULL policies work, and how rules combine.")
    def rules_semantics() -> str:
        return f"# dcloneb rule semantics\n\n{render_rules_table()}\n\n**NULL policy.** {NULL_BEHAVIOR}\n\n**Combining.** {COMBINING}\n"

    @server.resource("dcloneb://support-matrix.md", mime_type="text/markdown",
                     description="Supported column types, schema features, and plan diagnostics.")
    def support_matrix() -> str:
        return f"# dcloneb support matrix\n\n{render_matrix()}\n"

    @server.resource("dcloneb://rules/example.json", mime_type="application/json",
                     description="An example rules.json with one rule of each type.")
    def rules_example() -> str:
        return json.dumps(tools.EXAMPLE_RULES, indent=2)

    @server.prompt(name="connect", description="Connect to Databricks and make test data, one simple step at a time.")
    def connect() -> str:
        return connect_prompt()

    @server.prompt(name="create_test_data", description="Create test data from a schema and a plain-language request.")
    def create_test_data(request: str = "", schema: str = "") -> str:
        return create_test_data_prompt(request, schema)

    @server.tool(annotations=READ_ONLY)
    def preview_rows(output: str, table: str, n: int = tools.PREVIEW_MAX) -> dict[str, Any]:
        """Show up to 5 generated rows of one table. Only call this when the user asks to see data: the values
        are sent to the model provider. Other tools return only summaries, counts, and file paths."""
        return tools.preview_rows(state, output, table, n)

    return server
