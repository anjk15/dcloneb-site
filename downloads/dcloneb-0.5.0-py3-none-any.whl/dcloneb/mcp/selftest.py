"""`dcloneb mcp test` (plan4 M12): check the Claude Desktop (or Claude Code) setup end to end.

It reads the dcloneb entry from the app's config and starts *exactly that command*, as the app
does, but with a temporary workspace, so the user's own workspace is never written. Then it lists the tools
and runs a tiny analyze -> preflight -> generate. The test client answers the approval itself, as a user
would in a client that shows approval forms; there is no server-side backdoor.
"""

import asyncio
import os
import tempfile
from pathlib import Path
from typing import Callable

from dcloneb.generate.errors import GenerationError
from dcloneb.mcp.claude_desktop import SERVER_NAME, read_config

TOOLS = {"get_capabilities", "get_rules_contract", "analyze_schema", "preflight_rules", "generate_data", "preview_rows"}
DDL = "CREATE TABLE t (id INT PRIMARY KEY, status TEXT NOT NULL, amount NUMERIC(8, 2));"
RULES = {"rules_version": 1, "rules": [
    {"id": "status", "type": "allowed_values", "table": "t", "column": "status", "values": ["ok"], "null_policy": "forbid"},
    {"id": "positive", "type": "range", "table": "t", "column": "amount", "min": "0", "min_inclusive": False,
     "null_policy": "allow"},
]}


class Failed(Exception):
    pass


CLIENTS = {"claude-desktop": ("Claude Desktop", "dcloneb mcp install --workspace PATH"),
           "claude-code": ("Claude Code", "dcloneb mcp install --client claude-code --workspace PATH")}


def _entry(config: Path, app: str, fix: str) -> dict:
    if not config.exists():
        raise Failed(f"{app}'s config {config} doesn't exist; run `{fix}`")
    try:
        servers = read_config(config).get("mcpServers", {})
    except GenerationError as e:
        raise Failed(e.problems[0].message) from None
    if SERVER_NAME not in servers:
        raise Failed(f"dcloneb isn't in {app}'s config {config}; run `{fix}`")
    return servers[SERVER_NAME]


def _with_workspace(args: list, workspace: str) -> list:
    out = list(args)
    out[out.index("--workspace") + 1] = workspace
    return out


async def _flow(command: str, args: list, say: Callable[[str], None]) -> None:
    import mcp.types as t
    from mcp import Client, StdioServerParameters

    async def user_approves(context, params):
        return t.ElicitResult(action="accept", content={"approve": True})

    with tempfile.TemporaryDirectory(prefix="dcloneb-selftest-") as workspace:
        params = StdioServerParameters(command=command, args=_with_workspace(args, workspace), env=dict(os.environ))
        async with Client(params, elicitation_callback=user_approves) as client:
            info = client.server_info
            if info.name != "dcloneb":
                raise Failed(f"the configured command started {info.name!r}, not dcloneb")
            say(f"PASS server started over stdio (dcloneb {info.version})")
            missing = TOOLS - {tool.name for tool in (await client.list_tools()).tools}
            if missing:
                raise Failed(f"tools missing: {', '.join(sorted(missing))}")
            say(f"PASS {len(TOOLS)} tools available")
            analyzed = (await client.call_tool("analyze_schema", {"ddl": DDL})).structured_content
            if not analyzed.get("ok"):
                raise Failed(f"analyze_schema: {analyzed}")
            say("PASS analyze_schema")
            request = {"plan_id": analyzed["plan_id"], "rules": RULES, "rows": 5}
            checked = (await client.call_tool("preflight_rules", request)).structured_content
            if not checked.get("ok"):
                raise Failed(f"preflight_rules: {checked}")
            say("PASS preflight_rules")
            generated = (await client.call_tool("generate_data", {**request, "output": "selftest"})).structured_content
            if not generated.get("ok") or not generated["validation"]["passed"]:
                raise Failed(f"generate_data: {generated}")
            files_exist = all(Path(f).is_file() for f in generated["files"].values())
            if not files_exist:
                raise Failed("generate_data reported files that don't exist")
            say("PASS generate_data (approved by this test, as a user would), files written and validated")


def run_selftest(config: Path, say: Callable[[str], None] = print, client: str = "claude-desktop") -> bool:
    app, fix = CLIENTS[client]
    try:
        entry = _entry(config, app, fix)
        say(f"PASS {app} config has the dcloneb entry ({config})")
        command, args = entry.get("command", ""), list(entry.get("args", []))
        if not (Path(command).is_absolute() and Path(command).is_file() and os.access(command, os.X_OK)):
            raise Failed(f"the configured command {command} isn't an executable file; reinstall dcloneb, then run "
                         f"`{fix}` again")
        say(f"PASS command exists ({command})")
        if "--workspace" not in args or not Path(args[args.index("--workspace") + 1]).is_dir():
            raise Failed(f"the configured workspace folder is missing; run `{fix}` again")
        say(f"PASS workspace exists ({args[args.index('--workspace') + 1]})")
        asyncio.run(_flow(command, args, say))
    except Failed as e:
        say(f"FAIL {e}")
        return False
    except Exception as e:  # a server that won't start or talk: report it, don't crash
        say(f"FAIL the server didn't respond as expected: {type(e).__name__}: {e}")
        return False
    return True
