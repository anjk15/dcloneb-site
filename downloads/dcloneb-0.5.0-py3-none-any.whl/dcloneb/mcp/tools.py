"""The plain functions behind each MCP tool (plan4 M2-M4). They call `dcloneb.generate.api` and return
plain JSON. Errors come back as {"ok": false, "problems": [...]}, never as tracebacks. No MCP import here.
"""

import hashlib
import json
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Callable, Optional

import polars as pl

from dcloneb.generate.api import generate as generate_bundle
from dcloneb.generate.api import preflight_rules as api_preflight
from dcloneb.generate.api import preflight_scenario as api_preflight_scenario
from dcloneb.generate.config import parse_config, resolve_rows
from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.plan_input import LoadedPlan, parse_plan
from dcloneb.generate.rules.contract import SCHEMA
from dcloneb.generate.rules.registry import COMBINING, NULL_BEHAVIOR, REGISTRY
from dcloneb.generate.scenario import SCHEMA as SCENARIO_SCHEMA
from dcloneb.generate.support import FEATURES, SUPPORTED_TYPES, check_support
from dcloneb.generate.types import type_spec
from dcloneb.mcp.approval import Approval, request_sha256
from dcloneb.mcp.hints import hint_for
from dcloneb.mcp.limits import Limits
from dcloneb.mcp.summary import REVISION_NOTE, change_lines, request_details, request_summary, rule_lines, rule_sentence
from dcloneb.mcp.workspace import Workspace
from dcloneb import profile as observed, schema_doc
from dcloneb.plan import analyze
from dcloneb.plan import analyze_schema as analyze_discovered
from dcloneb.sources import databricks as db
from dcloneb.sources import databricks_write as dbw

PRIVACY = ("Generation runs locally and files stay in the workspace. What tools return (schema details, rules, "
           "summaries, errors, file paths) becomes part of the conversation and reaches the agent's model provider. "
           "Generated values are returned only by preview_rows, and only when called.")

EXAMPLE_RULES = {"rules_version": 2, "rules": [
    {"id": "positive_amount", "type": "range", "table": "orders", "column": "amount",
     "min": "0", "min_inclusive": False, "null_policy": "forbid"},
    {"id": "order_status", "type": "allowed_values", "table": "orders", "column": "status",
     "values": ["pending", "paid", "cancelled"], "null_policy": "forbid"},
    {"id": "contact_email", "type": "format", "table": "customers", "column": "contact_detail",
     "format": "email", "null_policy": "allow"},
    {"id": "customer_names", "type": "value_kind", "table": "customers", "column": "full_name",
     "kind": "person_name", "null_policy": "forbid"},
    {"id": "customer_numbers", "type": "id_format", "table": "customers", "column": "customer_code",
     "prefix": "CUS-", "digits": 6, "null_policy": "forbid"},
    {"id": "some_missing_notes", "type": "null_rate", "table": "orders", "column": "note", "rate": 0.05, "origin": "observed"},
    {"id": "cancelled_has_no_amount", "type": "conditional", "table": "orders",
     "when": {"column": "status", "equals": "cancelled"}, "then": {"column": "amount", "equals": "0"}},
]}


EXAMPLE_SCENARIO = {  # "20 customers, each with one account, plus one CLOSED account with balance 500 as a negative test"
    "scenario_version": 1,
    "entities": [{"alias": "owner", "table": "customers", "values": {}},
                 {"alias": "closed_with_balance", "table": "accounts", "values": {"status": "CLOSED", "balance": "500"}}],
    "links": [{"from": "closed_with_balance", "to": "owner"}],
    "background": [{"table": "customers", "count": 20, "children": [{"table": "accounts", "per_parent": 1}]}],
    "violations": [{"alias": "closed_with_balance", "rule": "closed_zero_balance"}],
}


@dataclass(frozen=True)
class Source:
    """A live Databricks connection (plan6 G1): read-only queries through the runner's time limits."""
    runner: object
    catalog: str
    schema: str


@dataclass
class State:
    workspace: Workspace
    limits: Limits
    plans: dict = field(default_factory=dict)  # plan_id -> analyzed plan, kept in memory only
    asked: set = field(default_factory=set)  # request hashes the user has been shown an approval form for
    completed: dict = field(default_factory=dict)  # Prepared.key -> the result of generating it (plan7: retries)
    connect: Optional[Callable] = None  # (profile, warehouse_id) -> DB-API connection; tests pass a fake
    source: Optional[Source] = None
    profiles: Optional[Callable] = None  # () -> [{name, host}] (plan8); tests pass a fake
    warehouses: Optional[Callable] = None  # profile -> [{id, name, state, size}] (plan8); tests pass a fake
    link: Optional[tuple] = None  # (profile, warehouse_id, Runner): one connection, so one query budget, across steps
    files: Optional[Callable] = None  # profile -> the SDK's Files API, for pushing (plan9); tests pass a fake


def _rule_types() -> dict:
    return {name: {"column_kinds": list(t.kinds), "meaning": t.meaning, "generation": t.generation}
            for name, t in REGISTRY.items()}


def get_capabilities(state: State) -> dict:
    return {
        "column_types": dict(SUPPORTED_TYPES),
        "features": [{"feature": f, "status": s, "notes": n} for f, s, n in FEATURES],
        "rule_types": _rule_types(),
        "limits": {"max_rows_per_table": state.limits.per_table, "max_rows_total": state.limits.total},
        "workspace": str(state.workspace.root),
        "privacy": PRIVACY,
    }


def get_rules_contract(state: State) -> dict:
    semantics = f"{NULL_BEHAVIOR} null_policy is required on every rule. {COMBINING}"
    return {"schema": SCHEMA, "rule_types": _rule_types(), "semantics": semantics, "example": EXAMPLE_RULES,
            "scenario_schema": SCENARIO_SCHEMA, "scenario_example": EXAMPLE_SCENARIO}


@dataclass(frozen=True)
class AnalyzedPlan:
    loaded: LoadedPlan
    plan_text: str  # plan.json, kept for the bundle
    ddl: str
    source_schema: object = None  # the discovered Schema (plan6), which profiling reads
    files: dict = field(default_factory=dict)  # schema.json / profile.json, kept for the bundle


def problems_result(error: GenerationError) -> dict:
    return {"ok": False, "problems": [{"kind": p.kind, "code": p.code, "message": p.message, "rule_ids": list(p.rule_ids),
                                       "hint": hint_for(p)} for p in error.problems]}


def _fail(code: str, message: str) -> GenerationError:
    return GenerationError([Problem("input", code, message)])


def _table_summary(table) -> dict:
    return {
        "columns": [{"name": c.name, "type": c.type, "nullable": c.nullable, "identity": c.identity} for c in table.columns],
        "primary_key": list(table.primary_key) if table.primary_key else None,
        "unique": [list(k.columns) for k in table.unique_keys],
        "foreign_keys": [{"columns": list(fk.columns), "references": {"table": fk.ref_table, "columns": list(fk.ref_columns)},
                          "source": fk.source} for fk in table.foreign_keys],
    }


def analyze_schema(state: State, ddl: Optional[str] = None, path: Optional[str] = None) -> dict:
    """Analyze PostgreSQL DDL (text, or a .sql file inside the workspace). Nothing is written; the plan is
    kept in memory under its `plan_id` for the other tools."""
    try:
        if (ddl is None) == (path is None):
            raise _fail("schema_input_invalid", "pass exactly one of `ddl` (the SQL text) or `path` (a file in the workspace)")
        if path is not None:
            ddl = state.workspace.resolve(path, must_exist=True).read_text(encoding="utf-8")
        plan = analyze(ddl, "postgres")
        plan_text = plan.to_json()
        if plan.status == "error":
            raise GenerationError([Problem("input", d.code, d.message) for d in plan.diagnostics if d.severity == "error"])
        loaded = parse_plan(json.loads(plan_text), hashlib.sha256(plan_text.encode("utf-8")).hexdigest())
    except GenerationError as e:
        return problems_result(e)
    except UnicodeDecodeError:
        return problems_result(_fail("schema_unreadable", f"{path!r} is not UTF-8 text"))
    return _registered(state, AnalyzedPlan(loaded, plan_text, ddl))


def _registered(state: State, analyzed: AnalyzedPlan) -> dict:
    """Keep the plan under its plan_id and describe it for the agent."""
    loaded = analyzed.loaded
    plan_id = loaded.sha256[:16]
    state.plans[plan_id] = analyzed
    try:
        check_support(loaded)
        unsupported = []
    except GenerationError as e:
        unsupported = problems_result(e)["problems"]
    return {
        "ok": True, "plan_id": plan_id, "generation_supported": not unsupported, "unsupported": unsupported,
        "execution_order": loaded.order,
        "tables": {t.name: _table_summary(t) for t in (analyzed.source_schema or loaded.schema).tables},
        "backfills": [{"table": b.table, "columns": list(b.fk.columns), "references": b.fk.ref_table} for b in loaded.backfills],
        "notes": [{"severity": d["severity"], "code": d["code"], "message": d["message"]} for d in loaded.diagnostics],
    }


# --- Databricks (plan6 G1): connect, discover, profile -------------------------------------------------

READ_ONLY_NOTE = ("dcloneb sends only its own fixed, read-only SELECT templates (metadata, then profiling aggregates), never "
                  "SQL from the agent. Your account's permissions aren't reduced; sign-in is handled by the Databricks CLI "
                  "profile, and no token passes through dcloneb's results or files.")


def _ask(step: str, question: str, options: list, chosen: dict, auto: list, multiple: bool = False) -> dict:
    """One question for the user, with numbered choices and the exact call to make with the answer."""
    placeholder = "<the chosen values>" if multiple else "<the chosen value>"
    tool, arguments = ("discover_schema", {"tables": placeholder}) if step == "tables" else \
        ("databricks_connect", {**chosen, STEP_ARGUMENT[step]: placeholder})
    return {"ok": True, "step": step, "chosen": dict(chosen), "auto_chosen": list(auto), "question": question,
            "options": options, "multiple": multiple, "next_call": {"tool": tool, "arguments": arguments}}


STEP_ARGUMENT = {"profile": "profile", "warehouse": "warehouse_id", "catalog": "catalog", "schema": "schema",
                 "target": "schema"}


def _pick(step: str, value: Optional[str], options: list, chosen: dict, auto: list, empty: GenerationError):
    """The value given, the only option (chosen automatically), or None when the user has to be asked."""
    if value is not None:
        chosen[STEP_ARGUMENT[step]] = value
        return value
    if not options:
        raise empty
    if len(options) == 1:
        chosen[STEP_ARGUMENT[step]] = options[0]["value"]
        auto.append(f"{step} {options[0]['name']} (the only one)")
        return options[0]["value"]
    return None


def _runner(state: State, profile: str, warehouse_id: str):
    if state.link and state.link[:2] == (profile, warehouse_id):
        return state.link[2]
    runner = db.Runner((state.connect or db.connect)(profile, warehouse_id))
    state.link = (profile, warehouse_id, runner)
    return runner


LABEL_DETAIL = 60  # characters of a comment shown in an option's label


def _labelled(name: str, detail) -> str:
    """`name: comment`, with only the comment's first line, shortened: a choice list stays readable."""
    first = (detail or "").strip().splitlines()[0] if (detail or "").strip() else ""
    if len(first) > LABEL_DETAIL:
        first = first[:LABEL_DETAIL - 1].rstrip() + "…"
    return f"{name}: {first}" if first else name


def databricks_connect(state: State, profile: Optional[str] = None, warehouse_id: Optional[str] = None,
                       catalog: Optional[str] = None, schema: Optional[str] = None) -> dict:
    """Connect one step at a time (plan8): each missing argument comes back as a question with numbered options
    (a single option is chosen automatically), until the tables of catalog.schema are listed."""
    chosen, auto = {}, []
    try:
        options = [] if profile else [{"value": p["name"], "name": p["name"], "label": f"{p['name']} ({p['host']})"}
                                      for p in (state.profiles or db.list_profiles)()]
        no_profiles = _fail("connection_no_profiles", "no Databricks CLI profile found in ~/.databrickscfg; run "
                                                      "`databricks auth login --host <workspace URL> --profile NAME` first")
        profile = _pick("profile", profile, options, chosen, auto, no_profiles)
        if profile is None:
            return _ask("profile", "Which Databricks profile (workspace) should dcloneb use?", options, chosen, auto)
        options = [] if warehouse_id else [{"value": w["id"], "name": w["name"],
                                            "label": f"{w['name']} ({w['state']}, {w['size']})"}
                                           for w in (state.warehouses or db.list_warehouses)(profile)]
        no_warehouses = _fail("connection_no_warehouses", f"profile '{profile}' sees no SQL warehouses; create or "
                                                          "get access to one in the Databricks workspace")
        warehouse_id = _pick("warehouse", warehouse_id, options, chosen, auto, no_warehouses)
        if warehouse_id is None:
            return _ask("warehouse", "Which SQL warehouse should run dcloneb's read-only queries?", options, chosen, auto)
        runner = _runner(state, profile, warehouse_id)
        options = [] if catalog else [{"value": c["name"], "name": c["name"], "label": _labelled(c["name"], c["comment"])}
                                      for c in db.catalogs(runner)]
        catalog = _pick("catalog", catalog, options, chosen, auto,
                        _fail("source_empty", "this account sees no catalogs on that warehouse"))
        if catalog is None:
            return _ask("catalog", "Which catalog?", options, chosen, auto)
        options = [] if schema else [{"value": c["name"], "name": c["name"], "label": _labelled(c["name"], c["comment"])}
                                     for c in db.schemas(runner, catalog)]
        schema = _pick("schema", schema, options, chosen, auto,
                       _fail("source_empty", f"this account sees no schemas in catalog {catalog}"))
        if schema is None:
            return _ask("schema", "Which schema?", options, chosen, auto)
        tables = sorted(runner.run(db.list_tables(catalog, schema)), key=lambda t: t["table_name"])
    except GenerationError as e:
        return problems_result(e)
    state.source = Source(runner, catalog, schema)
    listed = [{"name": t["table_name"], "comment": t.get("comment")} for t in tables]
    options = [{"value": t["name"], "name": t["name"], "label": _labelled(t["name"], t["comment"])} for t in listed]
    question = ("Which tables should get test data? Pick all you need; a table's parent tables (its foreign keys) "
                "must be picked too.")
    return {**_ask("tables", question, options, chosen, auto, multiple=True),
            "source": f"{catalog}.{schema}", "tables": listed, "read_only": READ_ONLY_NOTE}


def _source(state: State) -> Source:
    if state.source is None:
        raise _fail("databricks_not_connected", "no Databricks connection; call databricks_connect first")
    return state.source


def discover_schema(state: State, tables: list, relationships: Optional[list] = None,
                    unique_keys: Optional[list] = None, profile: str = "sample", sample_rows: int = db.SAMPLE_ROWS) -> dict:
    """Read the selected tables' columns and declared keys, add the relationships and unique keys the user
    confirmed, and plan them. Every parent table of a foreign key must be selected. Then profile them right away
    (plan8; `profile`: "sample", "full", or "none"), without reading any category values."""
    try:
        source = _source(state)
        available = sorted(t["table_name"] for t in source.runner.run(db.list_tables(source.catalog, source.schema)))
        schema = db.discover(source.runner, source.catalog, source.schema, list(tables))
        if relationships or unique_keys:
            schema = schema_doc.confirm(schema, relationships or (), unique_keys or ())
        plan = analyze_discovered(schema, "databricks")
        if plan.status == "error":
            raise GenerationError([Problem("input", d.code, d.message) for d in plan.diagnostics if d.severity == "error"])
        plan_text = plan.to_json()
        loaded = parse_plan(json.loads(plan_text), hashlib.sha256(plan_text.encode("utf-8")).hexdigest())
    except GenerationError as e:
        return problems_result(e)
    result = {**_registered(state, AnalyzedPlan(loaded, plan_text, "", schema, {"schema.json": schema_doc.dump(schema)})),
              "available_tables": available}
    if profile != "none":
        result["profile"] = profile_tables(state, result["plan_id"], None, profile, sample_rows)
    return result


def profile_tables(state: State, plan_id: str, categorical_columns: Optional[dict] = None, mode: str = "sample",
                   sample_rows: int = db.SAMPLE_ROWS) -> dict:
    """Measure the discovered tables (sampled by default) and suggest settings for the user to confirm. Category
    values are collected only for `categorical_columns` ({table: [column]}) the user approved."""
    try:
        analyzed = _plan(state, plan_id)
        if analyzed.source_schema is None:
            raise _fail("profile_needs_discovery", "profiling reads live tables: use a plan_id from discover_schema")
        source = _source(state)
        found = db.profile(source.runner, analyzed.source_schema, source.catalog, source.schema, categorical_columns,
                           mode, sample_rows)
    except GenerationError as e:
        return problems_result(e)
    state.plans[plan_id] = replace(analyzed, files={**analyzed.files, "profile.json": observed.dump(found)})
    kinds_for = _kinds(analyzed)
    suggestions = [{"number": n, **s, "line": f"{rule_sentence(s['rule'], kinds_for(s['rule']['table']))} "
                                              f"(measured: {s['basis']})"}
                   for n, s in enumerate(observed.suggest(found, analyzed.source_schema), 1)]
    return {"ok": True, "method": found["method"], "sample_rows_requested": found["sample_rows_requested"],
            "notes": found["notes"], "tables": found["tables"],
            "suggestions": suggestions,
            "categorical_candidates": observed.categorical_candidates(found, analyzed.source_schema)}


DEFAULT_ROWS, DEFAULT_SEED, DEFAULT_NULL_PROBABILITY = 100, 42, 0.1


@dataclass(frozen=True)
class Request:
    """One fully checked generation request: what preflight accepted and what approval will cover."""
    plan: AnalyzedPlan
    config: dict  # generation.json content
    rows: dict  # table -> rows, resolved
    rules: object  # NormalizedRules, or None without rules
    scenario: object = None  # ResolvedScenario, or None without a scenario (plan6 G1)


def _plan(state: State, plan_id: str) -> AnalyzedPlan:
    if plan_id not in state.plans:
        raise _fail("unknown_plan_id", f"no analyzed schema with plan_id {plan_id!r}; call analyze_schema first")
    return state.plans[plan_id]


def check_request(state: State, plan_id: str, rules: Optional[dict], rows: int = DEFAULT_ROWS,
                  table_rows: Optional[dict] = None, seed: int = DEFAULT_SEED,
                  null_probability: float = DEFAULT_NULL_PROBABILITY, scenario: Optional[dict] = None) -> Request:
    """Everything generation needs, checked: supported schema, valid config, limits, rules preflight, and the
    scenario (whose exact row counts replace `rows`/`table_rows`; the tables it doesn't mention get `rows`/`table_rows`)."""
    analyzed = _plan(state, plan_id)
    check_support(analyzed.loaded)
    config = {"seed": seed, "default_rows": rows, "table_rows": dict(table_rows or {}), "null_probability": null_probability}
    resolved_scenario = (api_preflight_scenario(analyzed.loaded, rules, scenario, config=config)
                         if scenario is not None else None)
    if resolved_scenario is not None:
        config["table_rows"] = dict(resolved_scenario.rows)
    resolved = resolve_rows(parse_config(config), [t.name for t in analyzed.loaded.schema.tables])
    state.limits.check(resolved)
    normalized = api_preflight(analyzed.loaded, rules, config) if rules is not None else None
    return Request(analyzed, config, resolved, normalized, resolved_scenario)


def _kinds(analyzed: AnalyzedPlan):
    """table -> (column -> its kind: text, int, decimal, ...), for plain-English rule lines."""
    schema = analyzed.loaded.schema
    return lambda table: lambda column: type_spec(schema.table(table).column(column)).kind


def preflight_rules(state: State, plan_id: str, rules: Optional[dict], rows: int = DEFAULT_ROWS,
                    table_rows: Optional[dict] = None, seed: int = DEFAULT_SEED,
                    null_probability: float = DEFAULT_NULL_PROBABILITY, scenario: Optional[dict] = None) -> dict:
    """Check rules, row counts, settings, and a scenario against an analyzed schema. Read-only: nothing is generated."""
    try:
        request = check_request(state, plan_id, rules, rows, table_rows, seed, null_probability, scenario)
    except GenerationError as e:
        return problems_result(e)
    extra = {} if request.scenario is None else {"scenario": {"aliases": {
        alias: {"table": table, "row_index": row} for alias, (table, row) in sorted(request.scenario.aliases.items())}}}
    return extra | {
        "ok": True,
        "rules": request.rules.to_dict()["rules"] if request.rules else [],
        "rule_lines": rule_lines(rules["rules"], _kinds(request.plan)) if request.rules else [],
        "always_null": sorted(f"{t}.{c}" for t, c in request.rules.always_null) if request.rules else [],
        "rows": request.rows, "total_rows": sum(request.rows.values()),
        "settings": {"seed": seed, "null_probability": null_probability},
    }


# --- generation (plan4 M3): prepare -> the user approves -> run ---------------------------------------

@dataclass(frozen=True)
class Prepared:
    request: Request
    output: Path
    summary: str
    sha: str  # request_sha256: what an approval is bound to
    details: Optional[dict] = None  # the same request laid out for the approval page
    key: str = ""  # the request with the output *name* asked for: the same on a retry, after the folder exists
    revises: Optional[str] = None  # the earlier run's folder name, for a revision (plan8)


def _previous_run(state: State, revises: str) -> tuple[str, dict]:
    """An earlier run's saved inputs (plan8): its folder name, and its row counts, generation.json, rules, scenario."""
    folder = state.workspace.resolve(revises, must_exist=True)
    manifest = folder / "manifest.json"
    if not (manifest.is_file() and str(json.loads(manifest.read_text()).get("generator", "")).startswith("dcloneb")):
        raise _fail("revises_not_found", f"{revises!r} isn't a dcloneb output folder; pass the folder generate_data reported")
    read = lambda name: json.loads((folder / name).read_text()) if (folder / name).is_file() else None
    tables = json.loads(manifest.read_text())["tables"]
    return folder.name, {"rows": {t: info["rows"] for t, info in tables.items()}, "config": read("generation.json") or {},
                         "rules": (read("rules.json") or {}).get("rules", []), "scenario": read("scenario.json")}


def prepare_generation(state: State, plan_id: str, rules: Optional[dict] = None, rows: int = DEFAULT_ROWS,
                       table_rows: Optional[dict] = None, seed: int = DEFAULT_SEED,
                       null_probability: float = DEFAULT_NULL_PROBABILITY, output: str = "generated",
                       scenario: Optional[dict] = None, revises: Optional[str] = None):
    """Check a request fully and describe it, without writing anything. Returns Prepared, or a problems
    result. Side-effect free, so it can run while asking for approval (resolvers may re-run). With `revises` (an
    earlier run's folder), the summary starts with what changed since that run."""
    try:
        request = check_request(state, plan_id, rules, rows, table_rows, seed, null_probability, scenario)
        out = state.workspace.free_output(output)
        since, previous = _previous_run(state, revises) if revises is not None else (None, None)
    except GenerationError as e:
        return problems_result(e)
    summary, details = request_summary(request, out), request_details(request, out)
    if since is not None:
        changes = change_lines(previous, request, _kinds(request.plan))
        summary = "\n".join([f"Changes since {since}:", *changes, REVISION_NOTE, "", summary])
        details = {**details, "changes": {"since": since, "lines": [line[2:] for line in changes], "note": REVISION_NOTE}}
    return Prepared(request, out, summary, request_sha256(request, out, since), details,
                    request_sha256(request, Path(output), since), since)


def finished(state: State, prepared: Prepared) -> Optional[dict]:
    """The result of an earlier run of exactly this request, if its folder is still there: a retry returns it
    instead of generating (and asking) again."""
    result = state.completed.get(prepared.key)
    if result is None or not Path(result["output"]).is_dir():
        return None
    return {**result, "status": "already_generated",
            "message": "this exact request was already approved and generated; nothing new was written"}


def run_generation(state: State, prepared: Prepared, approval: Approval, approved_sha: str) -> dict:
    """Generate only if the user approved this exact request; return paths and check results, never values."""
    if not approval.approved:
        return {"ok": False, "status": "not_approved", "message": f"nothing was generated: {approval.reason or 'not approved'}"}
    if approved_sha != prepared.sha:
        return {"ok": False, "status": "request_changed",
                "message": "the request changed after it was approved; nothing was generated. Ask again."}
    r = prepared.request
    try:
        result = generate_bundle(r.plan.loaded, r.config, prepared.output, rules=r.rules.to_dict() if r.rules else None,
                                 extra_files={"plan.json": r.plan.plan_text, **r.plan.files},
                                 manifest_extra={"approval": {"method": approval.method, "request_sha256": prepared.sha}}
                                 | ({"revises": prepared.revises} if prepared.revises else {}),
                                 scenario=r.scenario.raw if r.scenario else None)
    except GenerationError as e:
        return problems_result(e)
    report = json.loads((prepared.output / "validation_report.json").read_text())["serialized"]
    m = result.manifest
    state.completed[prepared.key] = out = {
        "ok": True, "status": "generated", "output": str(prepared.output),
        "files": {t: str(prepared.output / info["file"]) for t, info in m["tables"].items()},
        "rows": {t: info["rows"] for t, info in m["tables"].items()},
        "validation": {"passed": report["passed"], "verdict": report["verdict"], "checks": len(report["checks"]),
                       "rules": [{k: rule[k] for k in ("rule_id", "table", "column", "rows_evaluated", "violations")}
                                 for rule in report["rules"]]} | ({"scenario": report["scenario"]} if "scenario" in report else {}),
        "approval": {"method": approval.method, "request_sha256": prepared.sha},
    } | ({"revises": prepared.revises} if prepared.revises else {})
    return out


# --- preview (plan4 M4): the only tool that returns data values --------------------------------------

PREVIEW_MAX = 5
PREVIEW_NOTE = "These values are now part of the conversation and reach the agent's model provider."


def preview_rows(state: State, output: str, table: str, n: int = PREVIEW_MAX) -> dict:
    """Up to 5 rows of one table from a dcloneb bundle in the workspace. NULL is None; "" is an empty string."""
    try:
        if n < 1:
            raise _fail("preview_invalid", "n must be at least 1")
        folder = state.workspace.resolve(output, must_exist=True)
        manifest_path = folder / "manifest.json"
        manifest = json.loads(manifest_path.read_text()) if manifest_path.is_file() else {}
        if not str(manifest.get("generator", "")).startswith("dcloneb"):
            raise GenerationError([Problem("input", "not_a_bundle", f"{output!r} is not a dcloneb output folder")])
        if table not in manifest.get("tables", {}):
            raise _fail("unknown_table", f"{table!r} is not in {output!r}; its tables: {', '.join(sorted(manifest['tables']))}")
        csv = state.workspace.resolve(str(folder / manifest["tables"][table]["file"]), must_exist=True)
        frame = pl.read_csv(csv, infer_schema=False, n_rows=min(n, PREVIEW_MAX))  # strings; NULL stays None
    except GenerationError as e:
        return problems_result(e)
    return {"ok": True, "table": table, "columns": frame.columns, "rows": [list(r) for r in frame.rows()], "note": PREVIEW_NOTE}


# --- push a run into Databricks (plan9): where -> the user approves -> load and check ----------------------

PUSH_NOTE = "Nothing was deleted. What was created is listed under created; remove it in Databricks if you don't want it."


@dataclass(frozen=True)
class PreparedPush:
    folder: Path
    target: object  # databricks_write.Target
    new_schema: bool
    tables: tuple  # (Table, rows, csv path), parents first
    run: str  # the landing folder's name
    principal: str
    profile: str
    summary: str
    sha: str


def _run_folder(state: State, output: str) -> tuple[Path, dict]:
    folder = state.workspace.resolve(output, must_exist=True)
    manifest = folder / "manifest.json"
    if not (manifest.is_file() and str(json.loads(manifest.read_text()).get("generator", "")).startswith("dcloneb")):
        raise _fail("revises_not_found", f"{output!r} isn't a dcloneb output folder; pass the folder generate_data reported")
    if not (folder / "schema.json").is_file():
        raise _fail("push_needs_databricks_run", f"{output!r} wasn't made from Databricks tables, so dcloneb doesn't know "
                                                 "their Databricks types; only runs made after discover_schema can be pushed")
    return folder, json.loads(manifest.read_text())


def _source_location(state: State, folder: Path) -> Optional[tuple]:
    if state.source is not None:
        return state.source.catalog, state.source.schema
    profile = folder / "profile.json"
    found = json.loads(profile.read_text()).get("source") if profile.is_file() else None
    return (found["catalog"], found["schema"]) if found else None


def _load_order(folder: Path, schema) -> list:
    plan = folder / "plan.json"
    order = (json.loads(plan.read_text()).get("execution_order") if plan.is_file() else None) or []
    return sorted(schema.tables, key=lambda t: order.index(t.name) if t.name in order else len(order))


def push_to_databricks(state: State, output: str, catalog: Optional[str] = None, schema: Optional[str] = None):
    """Where to load a run (step by step, like databricks_connect): the source's catalog, then a schema from numbered
    options (a new one first; never the source, never one already holding these tables). With both given, a checked
    PreparedPush to approve. Sends only read-only lookups."""
    chosen, auto = {}, []
    try:
        folder, manifest = _run_folder(state, output)
        if state.link is None:
            raise _fail("databricks_not_connected", "no Databricks connection; call databricks_connect first (a profile "
                                                    "and a warehouse are enough)")
        profile, runner = state.link[0], state.link[2]
        source = _source_location(state, folder)
        if catalog is None and source:
            catalog = source[0]
            auto.append(f"catalog {catalog} (where the source tables are)")
        if catalog is None:
            options = [{"value": c["name"], "name": c["name"], "label": _labelled(c["name"], c["comment"])}
                       for c in db.catalogs(runner)]
            catalog = _pick("catalog", None, options, chosen, auto, _fail("source_empty", "this account sees no catalogs"))
            if catalog is None:
                return {**_ask("catalog", "Which catalog should the test tables go to?", options, chosen, auto),
                        "next_call": {"tool": "push_to_databricks", "arguments": {"output": output,
                                                                                  "catalog": "<the chosen value>"}}}
        chosen["catalog"] = catalog
        run_schema = schema_doc.load((folder / "schema.json").read_text())
        names = [t.name for t in run_schema.tables]
        holding: dict[str, list] = {}
        for row in runner.run(dbw.tables_named(catalog, names)):
            holding.setdefault(row["table_schema"], []).append(row["table_name"])
        existing = {s["name"]: s for s in db.schemas(runner, catalog)}
        principal = runner.run(dbw.current_user())[0]["principal"]
        is_source = lambda name: source is not None and (catalog, name) == source
        if schema is None:
            base = f"{source[1]}_test" if source and source[0] == catalog else "dcloneb_test"
            new, n = base, 1
            while new in existing:
                n += 1
                new = f"{base}_{n}"
            options = [{"value": new, "name": new, "label": f"{new} (new schema; recommended: keeps test data apart)",
                        "new": True}]
            options += [{"value": name, "name": name, "label": _labelled(name, s["comment"]), "new": False}
                        for name, s in sorted(existing.items()) if not is_source(name) and name not in holding]
            sample = dbw.target(catalog, new)
            return {**_ask("target", "Where should the test tables go? A new schema keeps them apart from everything else.",
                           options, chosen, auto),
                    "next_call": {"tool": "push_to_databricks",
                                  "arguments": {"output": output, "catalog": catalog, "schema": "<the chosen value>"}},
                    "not_offered": [f"{name} (already has {', '.join(sorted(holding[name]))})" for name in sorted(holding)
                                    if name in existing and not is_source(name)],
                    "permissions": {"principal": principal,
                                    "new schema": dbw.grants(principal, sample, True)["push"],
                                    "existing schema": [line.replace(db.quote(new), "<schema>") for line in
                                                        dbw.grants(principal, sample, False)["push"]],
                                    "warehouse": dbw.WAREHOUSE_GRANT}}
        t = dbw.target(catalog, schema)
        if is_source(schema):
            raise _fail("push_target_is_source", f"{t} holds the source tables; test data never goes there. Pick another schema")
        if schema in holding:
            raise _fail("push_table_exists", f"{schema} already has {', '.join(sorted(holding[schema]))}; dcloneb never "
                                             "replaces tables. Pick another schema, or a new one")
        sha_files = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode("utf-8")).hexdigest()
        run = f"{folder.name}-{sha_files[:8]}"
        tables = tuple((table, manifest["tables"][table.name]["rows"], folder / manifest["tables"][table.name]["file"])
                       for table in _load_order(folder, run_schema))
        for table, _, _ in tables:  # every statement is built now, so a bad name or type stops before approval
            dbw.create_table(t, table, run)
            dbw.copy_into(t, table.name, f"{dbw.landing(t, run)}/{table.name}.csv")
    except GenerationError as e:
        return problems_result(e)
    new_schema = schema not in existing
    lines = [f"Load test data into Databricks, from {folder.name}:",
             f"- Target: {t} ({'a new schema dcloneb creates' if new_schema else 'an existing schema'})",
             *[f"- {table.name}: {rows} rows (new table)" for table, rows, _ in tables],
             f"- Files: uploaded to {dbw.landing(t, run)}/",
             "- Then dcloneb checks each table's row count and that every foreign key matches.",
             "Nothing is deleted or replaced" + (f", and {source[0]}.{source[1]} (the source tables) isn't touched." if source
                                                 else "."),
             f"Signed in with Databricks profile {profile}."]
    sha = hashlib.sha256(json.dumps({"folder": str(folder), "files": sha_files, "target": str(t), "new": new_schema,
                                     "profile": profile}, sort_keys=True).encode("utf-8")).hexdigest()
    return PreparedPush(folder, t, new_schema, tables, run, principal, profile, "\n".join(lines), sha)


def run_push(state: State, prepared: PreparedPush, approval: Approval, approved_sha: str) -> dict:
    """Load only if the user approved this exact push: create, upload, load, then check counts and foreign keys."""
    if not approval.approved:
        return {"ok": False, "status": "not_approved", "message": f"nothing was sent: {approval.reason or 'not approved'}"}
    if approved_sha != prepared.sha:
        return {"ok": False, "status": "request_changed",
                "message": "the push changed after it was approved; nothing was sent. Ask again."}
    t, created = prepared.target, []
    landing = dbw.landing(t, prepared.run)
    writer = dbw.writer(state.link[2].connection, t)
    try:
        if prepared.new_schema:
            writer.run(dbw.create_schema(t))
            created.append(f"schema {t}")
        writer.run(dbw.create_volume(t))
        created.append(f"volume {t}.{dbw.VOLUME}")
        files_api = (state.files or dbw.files_api)(prepared.profile)
        for table, _, csv in prepared.tables:
            dbw.upload(files_api, csv, f"{landing}/{table.name}.csv")
            created.append(f"file {landing}/{table.name}.csv")
        for table, _, _ in prepared.tables:
            writer.run(dbw.create_table(t, table, prepared.run))
            created.append(f"table {t}.{table.name}")
        fks = [(table, fk, n) for table, _, _ in prepared.tables for n, fk in enumerate(table.foreign_keys, 1)]
        for table, fk, n in fks:
            writer.run(dbw.add_foreign_key(t, table, fk, n))
        for table, _, _ in prepared.tables:
            writer.run(dbw.copy_into(t, table.name, f"{landing}/{table.name}.csv"))
        loaded = {table.name: {"rows": rows, "loaded": writer.run(dbw.count_rows(t, table.name))[0]["n"]}
                  for table, rows, _ in prepared.tables}
        selection = db.Selection((t.catalog, t.schema, table.name) for table, _, _ in prepared.tables)
        unmatched = {f"{table.name}({', '.join(fk.columns)})": writer.run(
            db.unmatched_fk(selection, t.catalog, t.schema, table.name, fk, None))[0]["unmatched"] for table, fk, _ in fks}
    except GenerationError as e:
        problem = e.problems[0]
        if problem.code == "query_failed" and dbw.DENIED.search(problem.message):
            e = GenerationError([replace(problem, code="push_permission_denied")])
        out = {**problems_result(e), "created": created, "note": PUSH_NOTE}
        if e.problems[0].code == "push_permission_denied":
            out["grants"] = dbw.grants(prepared.principal, t, prepared.new_schema)["push"]
        return out
    wrong = [f"{name}: {v['loaded']} rows loaded, {v['rows']} expected" for name, v in loaded.items() if v["loaded"] != v["rows"]]
    wrong += [f"{fk}: {n} rows with no matching parent" for fk, n in unmatched.items() if n]
    if wrong:
        return {**problems_result(_fail("push_check_failed", "the loaded tables don't match the run: " + "; ".join(wrong))),
                "created": created, "note": PUSH_NOTE}
    return {"ok": True, "status": "pushed", "target": str(t), "new_schema": prepared.new_schema, "tables": loaded,
            "foreign_keys_checked": len(unmatched), "files": landing,
            "approval": {"method": approval.method, "request_sha256": prepared.sha}}
