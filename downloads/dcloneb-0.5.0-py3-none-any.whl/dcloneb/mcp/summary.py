"""The plain-English summary of a generation request (plan4 M5). The same text goes to the agent and into
the user's approval form, so the user approves exactly what the agent was told.

Built from the *normalized* rules (canonical values, sorted), so rule order never changes it. Each ruled
column is one line; whether it may be empty uses the combined NULL acceptability (schema NOT NULL wins).
"""

from collections import defaultdict

from dcloneb.generate.rules.contract import ID_CHARACTERS
from dcloneb.generate.rules.providers import id_text
from dcloneb.generate.types import type_spec

MAX_LISTED = 10
FILLED_NOTE = "not in your scenario, filled as usual"
EMPTY_NOTE = "left empty, as you asked"
KIND_WORDS = {"person_name": "people's full names", "first_name": "first names", "last_name": "last names",
              "company_name": "company names", "product_name": "product names", "category_name": "category names",
              "city": "city names", "state": "state names", "country": "country names",
              "street_address": "street addresses", "postal_code": "postal codes", "phone_number": "phone numbers",
              "url": "web addresses", "username": "usernames", "job_title": "job titles", "word": "single words",
              "sentence": "short sentences", "code": "codes like AB-1234",
              "date": "dates like 2026-10-17"}


ID_WORDS = {"digits": "digits", "upper": "uppercase letters", "upper_digits": "uppercase letters or digits"}


def _value(value, kind: str) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return f'"{value}"' if kind == "text" else str(value)


def _rule_phrase(rule: dict, kind: str, kinds=None) -> str:
    if rule["type"] == "conditional":
        when = rule["when"]
        return f"{_value(rule['then']['equals'], kind)} when {when['column']} is {_value(when['equals'], kinds(when['column']))}"
    if rule["type"] == "range":
        parts = []
        if "min" in rule:
            parts.append(f"{'at least' if rule['min_inclusive'] else 'greater than'} {rule['min']}")
        if "max" in rule:
            parts.append(f"{'at most' if rule['max_inclusive'] else 'less than'} {rule['max']}")
        return " and ".join(parts)
    if rule["type"] == "allowed_values":
        values = [_value(v, kind) for v in rule["values"]]
        weighted = f", weighted {':'.join(f'{w:g}' for w in rule['weights'])}" if rule.get("weights") else ""
        if len(values) == 1:
            return values[0]
        shown = ", ".join(values[:MAX_LISTED])
        return (f"one of {shown}" + (f" and {len(values) - MAX_LISTED} more" if len(values) > MAX_LISTED else "")
                + weighted)
    if rule["type"] == "value_kind":
        return KIND_WORDS[rule["kind"]]
    if rule["type"] == "id_format":
        characters = rule.get("characters", "digits")
        alphabet = ID_CHARACTERS[characters]
        example = rule["prefix"] + id_text(42 % len(alphabet) ** rule["digits"], rule["digits"], alphabet)
        what = f'{rule["digits"]} {ID_WORDS[characters]}'
        return f'IDs like "{example}" ("{rule["prefix"]}" then {what})' if rule["prefix"] else f'IDs like "{example}" ({what})'
    return "an email address"


def _reading_order(rule: dict) -> tuple:
    """Lower bounds read before upper bounds ("greater than 0 and at most 500"); then lists, then formats."""
    rank = {"range": 0 if "min" in rule else 1, "allowed_values": 2, "format": 3, "id_format": 3, "value_kind": 4, "null_rate": 5,
            "conditional": 6}[rule["type"]]
    return rank, rule["id"]


def _column_details(table: str, column: str, rules: list[dict], domain, always_null: bool,
                    sql_nullable: bool, kinds) -> dict:
    kind = kinds(column)
    meaning = " and ".join(_rule_phrase(r, kind, kinds) for r in sorted(rules, key=_reading_order) if r["type"] != "null_rate")
    rate = next((r["rate"] for r in rules if r["type"] == "null_rate"), None)
    if always_null:
        empty = "always empty"
    elif rate is not None:
        empty = f"empty in exactly {rate * 100:g}% of rows"
    elif domain is None:
        empty = None  # only conditional rules: they don't change whether the column may be empty
    elif domain.nulls_ok:
        empty = "may be empty"
    elif not sql_nullable:
        empty = "never empty, because the schema requires a value"
    else:
        empty = "never empty"
    origin = "observed" if all(r.get("origin") == "observed" for r in rules) else "business"
    return {"table": table, "column": column, "meaning": meaning, "empty": empty,
            "rule_ids": sorted(r["id"] for r in rules), "always_empty": always_null, "origin": origin}


def _article(word: str) -> str:
    return "an" if word[:1].lower() in "aeiou" else "a"


def _scenario_details(scenario, schema) -> dict:
    """The scenario in plain words: each entity's fixed values, links and negative tests; background groups."""
    raw = scenario.raw
    links, breaks = {}, {}
    for link in raw.get("links", []):
        links.setdefault(link["from"], []).append(link["to"])
    for violation in raw.get("violations", []):
        breaks.setdefault(violation["alias"], []).append(violation["rule"])
    def values(item: dict) -> list[str]:
        table = schema.table(item["table"])
        return [f"{c} {'empty' if v is None else _value(v, type_spec(table.column(c)).kind)}"
                for c, v in item.get("values", {}).items()]

    entities = [{"alias": entity["alias"], "table": entity["table"], "values": values(entity),
                 "linked_to": links.get(entity["alias"], []), "breaks": breaks.get(entity["alias"], [])}
                for entity in raw["entities"]]
    background = [{"table": g["table"], "count": g["count"], "values": values(g),
                   "children": [{"table": c["table"], "per_parent": c["per_parent"]} for c in g.get("children", [])]}
                  for g in raw.get("background", [])]
    return {"entities": entities, "background": background, "expected_outcome": raw.get("expected_outcome")}


def _background_text(g: dict) -> str:
    children = ", ".join(f"{c['per_parent']} {c['table']} row{'s' if c['per_parent'] > 1 else ''}" for c in g["children"])
    return (f"{g['count']} {g['table']} rows" + (f"; {', '.join(g['values'])}" if g["values"] else "")
            + (f", each with {children}" if children else ""))


def _scenario_lines(s: dict) -> list[str]:
    lines = ["Scenario:"]
    for e in s["entities"]:
        parts = [f"{_article(e['table'])} {e['table']} row"]
        if e["values"]:
            parts.append(", ".join(e["values"]))
        if e["linked_to"]:
            parts.append(f"linked to {', '.join(e['linked_to'])}")
        if e["breaks"]:
            parts.append(f"breaks {', '.join(e['breaks'])} on purpose (negative test)")
        lines.append(f"- {e['alias']}: {'; '.join(parts)}")
    lines += [f"- background: {_background_text(g)}" for g in s["background"]]
    if s["expected_outcome"]:
        lines.append(f"Expected outcome (recorded, never checked by dcloneb): {s['expected_outcome']}")
    return lines


def request_details(request, output) -> dict:
    """The request as data: what the approval page lays out. `request_summary` is the same content as text."""
    rules = []
    normalized = request.rules
    if normalized and normalized.rules:
        by_column: dict[tuple[str, str], list[dict]] = defaultdict(list)
        for rule in normalized.to_dict()["rules"]:
            by_column[(rule["table"], rule.get("column") or rule["then"]["column"])].append(rule)
        schema = request.plan.loaded.schema
        rules = [_column_details(table, column, column_rules, normalized.domains.get((table, column)),
                                 (table, column) in normalized.always_null, schema.table(table).column(column).nullable,
                                 lambda name, t=table: type_spec(schema.table(t).column(name)).kind)
                 for (table, column), column_rules in sorted(by_column.items())]
    scenario = getattr(request, "scenario", None)
    filled = getattr(scenario, "filled", None) or {}
    left_empty = set(scenario.raw.get("empty", [])) if scenario is not None else set()
    def note(table: str) -> dict:
        return ({"note": FILLED_NOTE} if table in filled else {"note": EMPTY_NOTE} if table in left_empty else {})

    return {"total_rows": sum(request.rows.values()),
            "tables": [{"name": table, "rows": n, **note(table)} for table, n in sorted(request.rows.items())],
            "rules": rules, "rule_count": len(normalized.rules) if normalized else 0,
            "scenario": None if scenario is None else _scenario_details(scenario, request.plan.loaded.schema),
            "seed": request.config["seed"], "empty_percent": round(request.config["null_probability"] * 100),
            "output": str(output)}


def _rule_line(rule: dict) -> str:
    ids = rule["rule_ids"]
    label = f"rule{'s' if len(ids) > 1 else ''} {', '.join(ids)}"
    if rule["always_empty"]:
        return f"- {rule['table']}.{rule['column']}: {rule['meaning']}, so no value fits; it will always be empty ({label})"
    if rule["empty"] is None:
        return f"- {rule['table']}.{rule['column']}: {rule['meaning']} ({label})"
    return f"- {rule['table']}.{rule['column']}: {rule['meaning']}; {rule['empty']} ({label})"


def rule_sentence(rule: dict, kinds) -> str:
    """One rule in plain words (plan8), for numbered lists the user edits by number. `kinds(column)` gives the kind of
    a column of the rule's table."""
    column = rule.get("column") or rule["then"]["column"]
    where = f"{rule['table']}.{column}"
    if rule["type"] == "null_rate":
        return f"{where}: empty in exactly {rule['rate'] * 100:g}% of rows"
    phrase = _rule_phrase(rule, kinds(column), kinds)
    if "null_policy" not in rule:
        return f"{where}: {phrase}"
    return f"{where}: {phrase}; {'may be empty' if rule['null_policy'] == 'allow' else 'never empty'}"


def rule_lines(rules: list[dict], kinds_for) -> list[str]:
    """`rules` numbered from 1 in the order given, each with who it comes from. `kinds_for(table)` -> kinds."""
    return [f"{n}. {rule_sentence(rule, kinds_for(rule['table']))} "
            f"({'measured' if rule.get('origin') == 'observed' else 'your rule'}, {rule['id']})"
            for n, rule in enumerate(rules, 1)]


def change_lines(previous: dict, request, kinds_for) -> list[str]:
    """What a revision changes since an earlier run (plan8), from that run's saved inputs: `previous` holds its
    `rows` (table -> count), `config` (generation.json), `rules` (normalized, or []) and `scenario` (raw, or None)."""
    lines = []
    for table in request.plan.loaded.order:
        old, new = previous["rows"].get(table, 0), request.rows.get(table, 0)
        if old != new:
            lines.append(f"- {table}: {old} → {new} rows")
    for key, word in (("seed", "seed"), ("null_probability", "share of empty values")):
        if previous["config"].get(key) != request.config[key]:
            lines.append(f"- {word}: {previous['config'].get(key)} → {request.config[key]}")
    old_rules = {r["id"]: r for r in previous["rules"]}
    new_rules = {r["id"]: r for r in (request.rules.to_dict()["rules"] if request.rules else [])}
    for rule_id, rule in new_rules.items():
        if rule_id not in old_rules or old_rules[rule_id] != rule:
            verb = "added" if rule_id not in old_rules else "changed"
            lines.append(f"- {verb} rule {rule_id}: {rule_sentence(rule, kinds_for(rule['table']))}")
    lines += [f"- removed rule {rule_id}" for rule_id in old_rules if rule_id not in new_rules]
    lines += _scenario_changes(previous["scenario"], request)
    return lines or ["- nothing changed"]


def _scenario_changes(old_raw, request) -> list[str]:
    schema, new = request.plan.loaded.schema, getattr(request, "scenario", None)
    empty = {"entities": [], "background": [], "expected_outcome": None}
    old = _comparable(_scenario_details(_Raw(old_raw), schema)) if old_raw else empty
    new = _comparable(_scenario_details(new, schema)) if new is not None else empty
    lines, before = [], {e["alias"]: e for e in old["entities"]}
    after = {e["alias"]: e for e in new["entities"]}
    for alias, entity in after.items():
        if alias not in before:
            lines.append(f"- added scenario row {alias} ({entity['table']})")
        elif before[alias] != entity:
            lines.append(f"- changed scenario row {alias} ({entity['table']})")
    lines += [f"- removed scenario row {alias} ({e['table']})" for alias, e in before.items() if alias not in after]
    for i in range(max(len(old["background"]), len(new["background"]))):
        was = old["background"][i] if i < len(old["background"]) else None
        now = new["background"][i] if i < len(new["background"]) else None
        if was == now:
            continue
        if was is None:
            lines.append(f"- added background: {_background_text(now)}")
        elif now is None:
            lines.append(f"- removed background: {_background_text(was)}")
        elif {**was, "count": now["count"]} == now:
            lines.append(f"- changed background: {_background_text(now)} (was {was['count']})")
        else:
            lines.append(f"- changed background: {_background_text(now)} (was {_background_text(was)})")
    return lines


def _comparable(details: dict) -> dict:
    """Fixed values sorted by column: a saved scenario.json has its keys sorted."""
    sort = lambda items: [{**item, "values": sorted(item["values"])} for item in items]
    return {**details, "entities": sort(details["entities"]), "background": sort(details["background"])}


class _Raw:
    def __init__(self, raw: dict):
        self.raw = raw


REVISION_NOTE = "Other rows can change too: the whole dataset is generated again."


def request_summary(request, output) -> str:
    d = request_details(request, output)
    lines = [f"Generate {d['total_rows']} rows on this computer, into {d['output']}:"]
    lines += [f"- {t['name']}: {t['rows']} rows" + (f" ({t['note']})" if t.get("note") else "") for t in d["tables"]]
    lines.append("")
    groups = [("Business rules", [r for r in d["rules"] if r["origin"] == "business"]),
              ("Settings measured from your data", [r for r in d["rules"] if r["origin"] == "observed"])]
    for title, group in groups:
        if group:
            lines.append(f"{title} ({sum(len(r['rule_ids']) for r in group)}):")
            lines += [_rule_line(r) for r in group]
            lines.append("")
    if not d["rules"]:
        lines += ["No business rules: values follow the schema only.", ""]
    if d["scenario"]:
        lines += _scenario_lines(d["scenario"]) + [""]
    empties = ("no values are left empty" if d["empty_percent"] == 0
               else f"where a column may be empty, about {d['empty_percent']}% of its values are empty")
    lines.append(f"Settings: seed {d['seed']}; {empties}.")
    lines.append("Keys, relationships, and the schema's constraints are always kept. "
                 "Files stay in your workspace; nothing is overwritten.")
    return "\n".join(lines)
