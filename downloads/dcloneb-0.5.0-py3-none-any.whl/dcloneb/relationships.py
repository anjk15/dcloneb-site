"""Uniqueness and relationship map (plan Phase 9). Works on a resolved schema."""

from dataclasses import dataclass
from itertools import combinations
from typing import Optional

from dcloneb.model import Diagnostic, Schema, Table


@dataclass(frozen=True)
class Relationship:
    kind: str  # one_to_one | many_to_one
    from_table: str  # the child (holds the FK)
    from_columns: tuple[str, ...]
    to_table: str  # the parent (referenced)
    to_columns: tuple[str, ...]
    optional: bool  # the FK can be NULL (MATCH SIMPLE: any column nullable; MATCH FULL: all)
    foreign_key: Optional[str]  # constraint name, if any


@dataclass(frozen=True)
class ManyToMany:
    junction: str
    tables: tuple[str, str]  # the two parents, in the junction's FK order (may be the same table)
    via: tuple[tuple[tuple[str, ...], str], tuple[tuple[str, ...], str]]  # ((junction FK columns), parent) per side


def unique_columns(table: Table) -> list[str]:
    """Columns that are unique by themselves (single-column PK, UNIQUE, or unique index), sorted."""
    return sorted({key[0] for key in table.keys() if len(key) == 1})


def unique_combinations(table: Table) -> list[list[str]]:
    """Composite keys (2+ columns), declared column order kept. Duplicates (same column set) are
    removed, and so are keys that contain a column already unique on its own (they add nothing)."""
    singles = set(unique_columns(table))
    seen: set[frozenset[str]] = set()
    found = []
    for key in table.keys():
        if len(key) < 2 or frozenset(key) in seen or singles & set(key):
            continue
        seen.add(frozenset(key))
        found.append(list(key))
    return sorted(found)


def relationships(schema: Schema) -> list[Relationship]:
    """One per FK: one_to_one if the child's FK columns are unique by themselves, else many_to_one."""
    found = [
        Relationship(
            kind="one_to_one" if table.is_unique(fk.columns) else "many_to_one",
            from_table=table.name,
            from_columns=fk.columns,
            to_table=fk.ref_table,
            to_columns=fk.ref_columns,
            optional=fk.can_be_null(table),
            foreign_key=fk.name,
        )
        for table in schema.tables
        for fk in table.foreign_keys
    ]
    return sorted(found, key=lambda r: (r.from_table, r.from_columns, r.to_table, r.to_columns))


def many_to_many(schema: Schema) -> tuple[list[ManyToMany], list[Diagnostic]]:
    """Junction-table rule: two FKs whose combined columns are unique while neither FK's columns are
    unique on their own. Each junction FK is still a many_to_one in `relationships()`.

    Links among 3+ tables (FKs only unique all together) aren't classified; they get an info.
    """
    found, diagnostics = [], []
    for table in schema.tables:
        fks = [fk for fk in table.foreign_keys if not table.is_unique(fk.columns)]
        pairs = [(a, b) for a, b in combinations(fks, 2) if table.is_unique(a.columns + b.columns)]
        for a, b in pairs:
            found.append(ManyToMany(table.name, (a.ref_table, b.ref_table), ((a.columns, a.ref_table), (b.columns, b.ref_table))))
        if not pairs and len(fks) >= 3 and table.is_unique(tuple(c for fk in fks for c in fk.columns)):
            diagnostics.append(Diagnostic(
                "info", "nary_link_not_classified",
                f"{table.name} links {len(fks)} tables ({', '.join(fk.ref_table for fk in fks)}); "
                "links among 3+ tables are not classified", table.statement, table.line))
    return sorted(found, key=lambda m: (m.junction, m.tables, m.via)), diagnostics
