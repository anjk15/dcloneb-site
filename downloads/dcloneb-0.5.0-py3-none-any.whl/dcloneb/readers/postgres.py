"""PostgreSQL DDL reader (plan Phase 3), also used for Databricks DDL (plan6 B4)."""

import logging
import re
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Optional

import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.tokens import Token, TokenType

from dcloneb.model import Column, Diagnostic, ForeignKey, Key, Schema, Table, short_names
from dcloneb.readers.split import Statement, split_statements

DIALECT = "postgres"

# Delta storage and layout properties: they don't constrain the data, so they don't block generation (plan6 B4).
_DATABRICKS_PROPERTIES = (exp.FileFormatProperty, exp.ClusterProperty, exp.Property, exp.LocationProperty,
                          exp.PartitionedByProperty)
_INFORMATIONAL = ("NOT ENFORCED", "RELY", "NORELY")  # Databricks: constraints are informational, never checked

# Statements that don't define tables or keys: noted as info, never errors.
_IGNORED_STATEMENTS = (exp.Comment, exp.Set, exp.Grant)


_FK_ACTION = re.compile(r"^ON (DELETE|UPDATE) (CASCADE|RESTRICT|NO ACTION|SET NULL|SET DEFAULT)( \(.+\))?$")


@dataclass
class FkOptions:
    match: str = "simple"  # Postgres default when MATCH is omitted
    deferrable: bool = False
    initially_deferred: bool = False
    actions: list[str] = field(default_factory=list)  # ON DELETE / ON UPDATE: not used for planning
    informational: list[str] = field(default_factory=list)  # NOT ENFORCED / RELY / NORELY
    unknown: list[str] = field(default_factory=list)


def parse_fk_options(options) -> FkOptions:
    """sqlglot gives FK options as plain strings in written order (spike finding). Anything not
    recognized is returned in `unknown`, never guessed (plan 3.10a)."""
    parsed = FkOptions()
    for option in options:
        text = " ".join(str(option).split())
        upper = text.upper()
        if upper in ("MATCH SIMPLE", "MATCH FULL", "MATCH PARTIAL"):
            parsed.match = upper.split()[1].lower()
        elif upper == "DEFERRABLE":
            parsed.deferrable = True
        elif upper == "INITIALLY DEFERRED":
            parsed.initially_deferred = True
        elif upper == "INITIALLY IMMEDIATE":
            parsed.initially_deferred = False
        elif _FK_ACTION.match(upper):
            parsed.actions.append(text)
        elif upper in _INFORMATIONAL:
            parsed.informational.append(text)
        else:
            parsed.unknown.append(text)
    return parsed


def _without_not_deferrable(statement: Statement) -> tuple[str, list[int]]:
    """Remove `NOT DEFERRABLE` (and a directly following `INITIALLY IMMEDIATE`) at the token level.

    sqlglot 30.x raises ParseError on NOT DEFERRABLE (spike finding). Both phrases only restate
    Postgres's defaults, so removing them doesn't change the meaning (decision A). Works on tokens,
    so the same words inside a string literal are untouched. Returns the new text and the lines
    where something was removed.
    """
    tokens, words = statement.tokens, [t.text.upper() for t in statement.tokens]
    drop: set[int] = set()
    lines = []
    i = 0
    while i < len(tokens) - 1:
        if words[i] == "NOT" and words[i + 1] == "DEFERRABLE" and tokens[i].token_type != TokenType.STRING:
            drop |= {i, i + 1}
            lines.append(tokens[i].line)
            if words[i + 2 : i + 4] == ["INITIALLY", "IMMEDIATE"]:
                drop |= {i + 2, i + 3}
            i += 2
        else:
            i += 1
    if not drop:
        return statement.text, []
    base = tokens[0].start
    pieces, cursor = [], 0
    for index in sorted(drop):
        pieces.append(statement.text[cursor : tokens[index].start - base])
        cursor = tokens[index].end + 1 - base
    pieces.append(statement.text[cursor:])
    return "".join(pieces), lines  # whitespace and newlines around removed tokens are kept


@contextmanager
def _quiet_sqlglot():
    """Keep sqlglot's "Falling back to parsing as a 'Command'" warnings out of the user's stderr;
    the fallback itself is reported as a diagnostic instead (plan 3.0b)."""
    logger = logging.getLogger("sqlglot")
    old_propagate, old_handlers = logger.propagate, logger.handlers[:]
    logger.propagate, logger.handlers = False, [logging.NullHandler()]
    try:
        yield
    finally:
        logger.propagate, logger.handlers = old_propagate, old_handlers


_NAME_TOKENS = (TokenType.VAR, TokenType.IDENTIFIER)


def _skip_name(tokens: tuple[Token, ...], i: int) -> int:
    """Index after a dotted name (`a`, `a.b`, `a.b.c`) starting at i, or -1 if there isn't one."""
    if i >= len(tokens) or tokens[i].token_type not in _NAME_TOKENS:
        return -1
    i += 1
    while i + 1 < len(tokens) and tokens[i].token_type == TokenType.DOT and tokens[i + 1].token_type in _NAME_TOKENS:
        i += 2
    return i


def _is_allowlisted_command(tokens: tuple[Token, ...]) -> bool:
    """Opaque `Command` statements known not to define tables or keys (decisions B and D)."""
    words = [t.text.upper() for t in tokens]
    if _is_alter_owner_to(tokens):
        return True
    # CREATE [OR REPLACE] FUNCTION|PROCEDURE ...: the body (e.g. plpgsql) is opaque and irrelevant
    i = 3 if words[1:3] == ["OR", "REPLACE"] else 1
    if words[0] == "CREATE" and words[i : i + 1] in (["FUNCTION"], ["PROCEDURE"]):
        return True
    # CREATE EXTENSION [IF NOT EXISTS] name [WITH SCHEMA ... | VERSION ... | CASCADE]
    if words[:2] == ["CREATE", "EXTENSION"]:
        i = 5 if words[2:5] == ["IF", "NOT", "EXISTS"] else 2
        return _skip_name(tokens, i) != -1
    # ALTER SEQUENCE [IF EXISTS] name OWNED BY {name | NONE}: and nothing else
    if words[:2] == ["ALTER", "SEQUENCE"]:
        i = _skip_name(tokens, 4 if words[2:4] == ["IF", "EXISTS"] else 2)
        if i == -1 or words[i : i + 2] != ["OWNED", "BY"]:
            return False
        end = i + 3 if words[i + 2 : i + 3] == ["NONE"] else _skip_name(tokens, i + 2)
        return end == len(tokens)
    return False


def _is_alter_owner_to(tokens: tuple[Token, ...]) -> bool:
    """Exactly `ALTER TABLE [IF EXISTS] [ONLY] name OWNER TO role` and nothing else (decision B).
    Anything more (e.g. another action before OWNER TO) is not allowlisted."""
    words = [t.text.upper() for t in tokens]
    if words[:2] != ["ALTER", "TABLE"]:
        return False
    i = 2
    while words[i : i + 2] == ["IF", "EXISTS"] or words[i : i + 1] == ["ONLY"]:
        i += 2 if words[i] == "IF" else 1
    i = _skip_name(tokens, i)
    return i != -1 and words[i : i + 2] == ["OWNER", "TO"] and len(tokens) == i + 3


def _table_name(table: exp.Table) -> str:
    """`catalog.schema.table` from an already-normalized sqlglot Table."""
    return ".".join(part.name for part in table.parts)


_SERIAL_TYPES = ("SMALLSERIAL", "SERIAL", "BIGSERIAL")  # Postgres: an integer with a sequence default, NOT NULL


@dataclass
class _ColumnBuilder:
    name: str
    type: str
    nullable: bool = True
    generated: bool = False
    type_name: str = ""
    type_params: tuple = ()
    identity: Optional[str] = None
    has_default: bool = False
    collation: Optional[str] = None
    comment: Optional[str] = None


def _type_info(kind: Optional[exp.DataType], dialect: str = DIALECT) -> tuple[str, tuple]:
    """sqlglot's type name and parameters, e.g. ("DECIMAL", (10, 2)); ints where numeric (plan2 G1)."""
    if kind is None:
        return "", ()
    params = []
    for param in kind.expressions:
        inner = param.this if isinstance(param, exp.DataTypeParam) else param
        if isinstance(inner, exp.Literal) and not inner.is_string and inner.this.isdigit():
            params.append(int(inner.this))
        else:
            params.append(inner.sql(dialect=dialect))
    return kind.this.name, tuple(params)


def column_type(kind: exp.DataType, dialect: str) -> tuple[str, str, tuple]:
    """(declared type text, type name, params) the same way for DDL and live discovery (plan6 B1)."""
    return (kind.sql(dialect=dialect), *_type_info(kind, dialect))


@dataclass
class _TableBuilder:
    name: str
    statement: Optional[int] = None
    line: Optional[int] = None
    columns: list[_ColumnBuilder] = field(default_factory=list)
    primary_key: Optional[tuple[str, ...]] = None
    unique_keys: list[Key] = field(default_factory=list)
    foreign_keys: list[ForeignKey] = field(default_factory=list)
    check_columns: set[str] = field(default_factory=set)
    checks: list[str] = field(default_factory=list)
    comment: Optional[str] = None

    def column(self, name: str) -> Optional[_ColumnBuilder]:
        return next((c for c in self.columns if c.name == name), None)

    def build(self) -> Table:
        pk = set(self.primary_key or ())
        return Table(
            name=self.name,
            # PK columns are NOT NULL; applied here because a table-level PK may come before its columns.
            columns=tuple(Column(c.name, c.type, c.nullable and c.name not in pk, c.generated, c.type_name, c.type_params,
                                 c.identity, c.has_default, c.collation, c.comment) for c in self.columns),
            primary_key=self.primary_key,
            unique_keys=tuple(self.unique_keys),
            foreign_keys=tuple(self.foreign_keys),
            check_columns=frozenset(self.check_columns),
            checks=tuple(self.checks),
            comment=self.comment,
            statement=self.statement,
            line=self.line,
        )


class _Reader:
    def __init__(self, dialect: str = DIALECT):
        self.dialect = dialect
        self.diagnostics: list[Diagnostic] = []
        self.tables: dict[str, _TableBuilder] = {}

    def diag(self, severity: str, code: str, message: str, statement: Statement, line: Optional[int] = None) -> None:
        self.diagnostics.append(Diagnostic(severity, code, message, statement.number, line or statement.line))

    # --- statements ---------------------------------------------------------------------------

    def read(self, sql: str) -> Schema:
        for statement in split_statements(sql, self.dialect):
            tree = self.parse(statement)
            if tree is not None:
                self.statement(normalize_identifiers(tree, dialect=self.dialect), statement)
        return Schema(tables=tuple(t.build() for t in self.tables.values()), diagnostics=tuple(self.diagnostics))

    def parse(self, statement: Statement) -> Optional[exp.Expression]:
        text, removed_at = _without_not_deferrable(statement)
        for line in removed_at:
            self.diag("info", "not_deferrable_normalized",
                      "NOT DEFERRABLE (the default) was removed before parsing; meaning unchanged", statement, line)
        try:
            with _quiet_sqlglot():
                return sqlglot.parse_one(text, read=self.dialect)
        except ParseError as e:
            first = e.errors[0] if e.errors else {}
            line = statement.line + (first.get("line") or 1) - 1
            description = first.get("description") or str(e).splitlines()[0]
            self.diag("error", "parse_error", f"statement {statement.number} could not be parsed: {description}", statement, line)
            return None

    def statement(self, tree: exp.Expression, statement: Statement) -> None:
        kind = tree.args.get("kind")
        if isinstance(tree, exp.Command):
            if _is_allowlisted_command(statement.tokens):
                self.ignored(statement)
            else:
                self.unrecognized(statement)
        elif isinstance(tree, exp.Create) and kind == "TABLE":
            self.create_table(tree, statement)
        elif isinstance(tree, exp.Create) and kind == "INDEX":
            self.create_index(tree, statement)
        elif isinstance(tree, exp.Create):
            self.ignored(statement)
        elif isinstance(tree, exp.Alter) and kind == "TABLE":
            self.alter_table(tree, statement)
        elif isinstance(tree, _IGNORED_STATEMENTS):
            self.ignored(statement)
        else:
            self.unrecognized(statement)

    def ignored(self, statement: Statement) -> None:
        self.diag("info", "statement_ignored", f"statement {statement.number} doesn't define tables or keys; ignored: {statement.text}", statement)

    def unrecognized(self, statement: Statement) -> None:
        self.diag("error", "unrecognized_statement",
                  f"statement {statement.number} isn't a statement dcloneb understands, so it can't be checked: {statement.text}",
                  statement)

    def create_index(self, tree: exp.Create, statement: Statement) -> None:
        index = tree.this
        target = _table_name(index.args["table"])
        label = f"index on {target}"
        if not tree.args.get("unique"):
            self.diag("info", "index_not_used", f"{label}: non-unique indexes don't affect load planning", statement)
            return
        table = self.tables.get(target)
        if table is None:
            self.diag("error", "index_unknown_table", f"unique {label}: table is not defined earlier in the DDL", statement)
            return
        params = index.args["params"]
        if params.args.get("where") is not None:
            self.diag("warning", "partial_unique_index_not_modeled",
                      f"unique {label} has a WHERE clause; it is not modeled as a key", statement)
            return
        ordered = params.args.get("columns") or []
        if not all(isinstance(o.this, exp.Column) for o in ordered):
            self.diag("warning", "expression_unique_index_not_modeled",
                      f"unique {label} uses an expression; it is not modeled as a key", statement)
            return
        table.unique_keys.append(Key(tuple(o.this.name for o in ordered), True, statement.number, statement.line))

    def alter_table(self, tree: exp.Alter, statement: Statement) -> None:
        name = _table_name(tree.this)
        table = self.tables.get(name)
        if table is None:
            self.diag("error", "alter_unknown_table", f"ALTER TABLE {name}: table is not defined earlier in the DDL", statement)
            return
        if tree.args.get("not_valid"):
            self.diag("info", "constraint_not_valid",
                      f"ALTER TABLE {name}: NOT VALID only skips checking existing rows; planned as a normal constraint", statement)
        for action in tree.args.get("actions") or []:
            if isinstance(action, exp.AddConstraint):
                for element in action.expressions:
                    self.table_element(table, element, statement)
            elif isinstance(action, exp.ColumnDef):  # ADD COLUMN (decision C)
                self.column_def(table, action, statement)
            else:  # DROP / RENAME / ALTER COLUMN ...: would change the schema, so never skipped
                self.diag("error", "unsupported_alter",
                          f"ALTER TABLE {name}: `{action.sql(dialect=self.dialect)}` changes the schema and is not supported", statement)

    # --- CREATE TABLE ---------------------------------------------------------------------------

    def create_table(self, tree: exp.Create, statement: Statement) -> None:
        schema = tree.this
        name = _table_name(schema.this if isinstance(schema, exp.Schema) else schema)
        properties = tree.args["properties"].expressions if tree.args.get("properties") else []
        unsupported = (
            "CREATE TABLE ... AS" if tree.args.get("expression") is not None
            else "PARTITION OF" if any(isinstance(p, exp.PartitionedOfProperty) for p in properties)
            else "INHERITS" if any(isinstance(p, exp.InheritsProperty) for p in properties)
            else "LIKE" if isinstance(schema, exp.Schema) and any(isinstance(e, exp.LikeProperty) for e in schema.expressions)
            else "a definition without a column list" if not isinstance(schema, exp.Schema)
            else None
        )
        if unsupported:
            self.diag("error", "unsupported_table_definition",
                      f"table {name}: {unsupported} is not supported (its columns and keys can't be known); not modeled", statement)
            return
        if name in self.tables:
            self.diag("error", "duplicate_table", f"table {name} is defined twice; the first definition is kept", statement)
            return
        table = _TableBuilder(name, statement.number, statement.line)
        if self.dialect == "databricks":
            table.comment = next((p.this.name for p in properties if isinstance(p, exp.SchemaCommentProperty)), None)
            storage = [p for p in properties if isinstance(p, _DATABRICKS_PROPERTIES)]
            properties = [p for p in properties if not isinstance(p, (*_DATABRICKS_PROPERTIES, exp.SchemaCommentProperty))]
            if storage:
                listed = ", ".join(p.sql(dialect=self.dialect) for p in storage)
                self.diag("info", "databricks_property_not_used", f"table {name}: {listed} doesn't constrain the data", statement)
        if properties:
            listed = ", ".join(p.sql(dialect=self.dialect) for p in properties)
            self.diag("info", "table_property_not_used", f"table {name}: {listed} doesn't affect load planning", statement)
        for element in schema.expressions:
            self.table_element(table, element, statement)
        self.tables[table.name] = table

    def table_element(self, table: _TableBuilder, element: exp.Expression, statement: Statement,
                      name: Optional[str] = None) -> None:
        """One element of CREATE TABLE (...) or ALTER TABLE ADD CONSTRAINT. `name` is a CONSTRAINT name."""
        if isinstance(element, exp.ColumnDef):
            self.column_def(table, element, statement)
        elif isinstance(element, exp.Constraint):
            for inner in element.expressions:
                self.table_element(table, inner, statement, name=element.this.name)
        elif isinstance(element, exp.PrimaryKey):
            self.set_primary_key(table, tuple(i.name for i in element.expressions), statement)
        elif isinstance(element, exp.UniqueColumnConstraint):
            columns = tuple(i.name for i in element.this.expressions)
            table.unique_keys.append(Key(columns, not element.args.get("nulls"), statement.number, statement.line))
        elif isinstance(element, exp.ForeignKey):
            columns = tuple(i.name for i in element.expressions)
            self.foreign_key(table, columns, element.args["reference"], statement, name)
        elif isinstance(element, exp.CheckColumnConstraint):
            self.check(table, element, statement)
        elif isinstance(element, exp.Identifier):
            self.diag("error", "malformed_table_element",
                      f"table {table.name}: '{element.name}' is not a column definition (missing type, or a stray comma?)", statement)
        else:
            self.diag("error", "unsupported_table_element",
                      f"table {table.name}: unsupported element `{element.sql(dialect=self.dialect)}`", statement)

    def column_def(self, table: _TableBuilder, column_def: exp.ColumnDef, statement: Statement) -> None:
        if table.column(column_def.name) is not None:
            self.diag("error", "duplicate_column", f"{table.name}: column '{column_def.name}' is defined twice", statement)
            return
        kind = column_def.args.get("kind")
        column = _ColumnBuilder(column_def.name, kind.sql(dialect=self.dialect) if kind else "")
        column.type_name, column.type_params = _type_info(kind, self.dialect)
        table.columns.append(column)
        identity = column.type_name in _SERIAL_TYPES
        if identity:
            column.identity = "serial"
        for constraint in column_def.args.get("constraints") or []:  # in source order
            c = constraint.args.get("kind")
            if isinstance(c, exp.NotNullColumnConstraint):
                # Explicit `NULL` parses as NotNullColumnConstraint(allow_null=True): it means nullable.
                column.nullable = bool(c.args.get("allow_null"))
            elif isinstance(c, exp.PrimaryKeyColumnConstraint):
                self.set_primary_key(table, (column.name,), statement)
            elif isinstance(c, exp.UniqueColumnConstraint):
                table.unique_keys.append(Key((column.name,), not c.args.get("nulls"), statement.number, statement.line))
            elif isinstance(c, exp.Reference):
                name = constraint.this.name if constraint.this else None
                self.foreign_key(table, (column.name,), c, statement, name)
            elif isinstance(c, exp.CheckColumnConstraint):
                self.check(table, c, statement)
            elif isinstance(c, exp.ComputedColumnConstraint):
                column.generated = True
                self.diag("info", "generated_column", f"{table.name}.{column.name} is a generated column", statement)
            elif isinstance(c, exp.GeneratedAsIdentityColumnConstraint):
                identity = True
                column.identity = "always" if c.this else "by_default"
                self.diag("info", "identity_column", f"{table.name}.{column.name} is an identity column (NOT NULL)", statement)
            elif isinstance(c, exp.DefaultColumnConstraint):
                column.has_default = True
                self.diag("info", "default_not_used", f"{table.name}.{column.name}: DEFAULT doesn't affect load planning", statement)
            elif isinstance(c, exp.CommentColumnConstraint):
                column.comment = c.this.name
            elif isinstance(c, exp.CollateColumnConstraint):
                column.collation = c.this.name
                self.diag("info", "collate_not_used", f"{table.name}.{column.name}: COLLATE doesn't affect load planning", statement)
            else:  # could change nullability or keys, so never skipped
                self.diag("error", "unsupported_column_constraint",
                          f"{table.name}.{column.name}: unsupported column constraint `{constraint.sql(dialect=self.dialect)}`", statement)
        if identity:
            column.nullable = False  # Postgres identity and serial columns are NOT NULL, whatever else is declared

    def check(self, table: _TableBuilder, check: exp.CheckColumnConstraint, statement: Statement) -> None:
        """CHECK expressions aren't evaluated; their columns are recorded so backfill never nulls them."""
        table.check_columns |= {col.name for col in check.find_all(exp.Column)}
        table.checks.append(check.this.sql(dialect=self.dialect))
        self.diag("info", "check_not_evaluated", f"{table.name}: CHECK `{check.this.sql(dialect=self.dialect)}` is not evaluated",
                  statement)

    def foreign_key(self, table: _TableBuilder, columns: tuple[str, ...], reference: exp.Reference,
                    statement: Statement, name: Optional[str]) -> None:
        target = reference.this
        if isinstance(target, exp.Schema):  # REFERENCES t (cols)
            ref_table, ref_columns = _table_name(target.this), tuple(i.name for i in target.expressions)
        else:  # REFERENCES t: resolved to t's PK in Phase 4
            ref_table, ref_columns = _table_name(target), None
        label = f"foreign key {table.name}({', '.join(columns)}) -> {ref_table}"
        options = parse_fk_options(reference.args.get("options") or [])

        if options.unknown:
            self.diag("error", "fk_unknown_option", f"{label}: unrecognized option(s) {options.unknown}", statement)
            return
        if options.match == "partial":
            self.diag("error", "fk_match_partial_unsupported",
                      f"{label}: MATCH PARTIAL is not supported (PostgreSQL doesn't implement it either)", statement)
            return
        if options.actions:
            self.diag("info", "fk_action_not_used", f"{label}: {', '.join(options.actions)} doesn't affect load planning", statement)
        if options.informational:
            self.diag("info", "constraint_not_enforced",
                      f"{label}: {', '.join(options.informational)}: the database doesn't check it; the data satisfies it anyway",
                      statement)
        if options.deferrable:
            self.diag("warning", "fk_deferrable_not_used",
                      f"{label} is DEFERRABLE: planned as immediately checked; deferred-constraint loading is not supported yet",
                      statement)
        table.foreign_keys.append(ForeignKey(name, columns, ref_table, ref_columns, options.match, options.deferrable,
                                             options.initially_deferred, statement.number, statement.line))

    def set_primary_key(self, table: _TableBuilder, columns: tuple[str, ...], statement: Statement) -> None:
        if table.primary_key is not None:
            self.diag("error", "duplicate_primary_key",
                      f"{table.name}: a second PRIMARY KEY ({', '.join(columns)}); the first ({', '.join(table.primary_key)}) is kept",
                      statement)
            return
        table.primary_key = columns


def read_postgres(sql: str) -> Schema:
    return _Reader().read(sql)


def read_databricks(sql: str) -> Schema:
    return short_names(_Reader("databricks").read(sql))
