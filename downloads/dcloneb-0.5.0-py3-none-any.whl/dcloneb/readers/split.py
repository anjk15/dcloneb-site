"""Split a DDL file into statements with sqlglot's tokenizer (plan 3.0a).

`sqlglot.parse` fails the whole file on one bad statement, so each statement is parsed on its own.
The tokenizer knows strings and comments, so a `;` inside them doesn't split.
"""

from dataclasses import dataclass

import sqlglot
from sqlglot.tokens import Token, TokenType


@dataclass(frozen=True)
class Statement:
    number: int  # 1-based, in file order
    line: int  # 1-based line of the statement's first token
    text: str  # source text from the first to the last token (comments in between kept)
    tokens: tuple[Token, ...]


def split_statements(sql: str, dialect: str) -> list[Statement]:
    groups: list[list[Token]] = [[]]
    for token in sqlglot.Dialect.get_or_raise(dialect).tokenize(sql):
        if token.token_type == TokenType.SEMICOLON:
            groups.append([])
        else:
            groups[-1].append(token)
    statements = []
    for tokens in (g for g in groups if g):
        statements.append(
            Statement(
                number=len(statements) + 1,
                line=tokens[0].line,
                text=sql[tokens[0].start : tokens[-1].end + 1],
                tokens=tuple(tokens),
            )
        )
    return statements
