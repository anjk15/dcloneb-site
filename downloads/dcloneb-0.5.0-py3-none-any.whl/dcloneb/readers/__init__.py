"""One reader per SQL dialect. Every reader returns the same dialect-free `Schema`."""
