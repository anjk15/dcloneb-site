"""Independent validator (plan2 G10): checks generated tables against the plan's declared constraints.

It never imports the generator's value, key, engine, or backfill code, so a bug there can't hide
itself here. Limits are the **SQL** limits from the plan, not the generator's own ranges.
"""

import datetime as dt
import math
import re
from dataclasses import asdict, dataclass, field
from decimal import ROUND_HALF_UP, Decimal
from fractions import Fraction
from typing import Iterable, Optional

import polars as pl

from dcloneb.generate.plan_input import LoadedPlan
from dcloneb.generate.rules.registry import check as rule_check, equals_value, naive_utc, same_value
from dcloneb.generate.types import type_spec
from dcloneb.model import Column, ForeignKey, Table

SAMPLES = 5
ROW = "__dcloneb_row"
UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
PIPELINE_OUTCOME = "not verified by dcloneb"  # dcloneb never runs or checks the user's pipeline
ANY = "any"  # a scenario FK pick the generator chooses: any ordinary (non-pinned) parent row


@dataclass(frozen=True)
class Check:
    check: str  # row_count | columns | type_limits | not_null | primary_key | unique | foreign_key | backfill
    table: str
    constraint: str
    rows_checked: int
    violations: int
    samples: tuple[int, ...] = ()  # up to 5 offending row indices


@dataclass(frozen=True)
class RuleResult:
    """One business rule checked against the actual values (plan3 R9)."""
    rule_id: str
    table: str
    column: str
    rows_evaluated: int
    null_count: int
    violations: int
    samples: tuple[int, ...] = ()
    coverage: str = "rows"  # rows | empty table | column missing
    expected: tuple[int, ...] = ()  # rows a scenario declares as negative tests of this rule that break it (plan6 E2)


@dataclass(frozen=True)
class Distribution:
    """A generation setting's target vs what was generated (plan6 D3). Approved rules take priority over percentages,
    so a difference beyond the tolerance names the rules on the column that explain it; it never fails the report."""
    rule_id: str
    table: str
    column: str
    target: dict
    actual: dict
    within_tolerance: bool
    tolerance: int = 1
    explained_by: tuple[str, ...] = ()


@dataclass
class Report:
    checks: list[Check]
    rules: list[RuleResult] = field(default_factory=list)
    distributions: list[Distribution] = field(default_factory=list)
    scenario: Optional[dict] = None  # plan6 F2: ordinary vs negative-test records; the pipeline is never claimed

    @property
    def passed(self) -> bool:
        """Every check and rule holds, and every distribution is within tolerance or explained by a named rule."""
        return (not any(c.violations for c in self.checks) and not any(r.violations for r in self.rules)
                and all(d.within_tolerance or d.explained_by for d in self.distributions))

    @property
    def verdict(self) -> dict:
        """plan7: the schema and relationships (structural), the rows that break a rule on purpose (declared negative
        tests), and everything else that fails (unexpected). Data holding an intentional exception is never just
        "passed"."""
        structural = [c for c in self.checks if c.violations and not c.check.startswith("scenario_")]
        unexpected = (sum(c.violations for c in self.checks if c.violations) + sum(r.violations for r in self.rules)
                      + sum(1 for d in self.distributions if not (d.within_tolerance or d.explained_by)))
        intentional = [{k: t[k] for k in ("alias", "table", "row_index", "rule")}
                       for t in (self.scenario or {}).get("negative_tests", []) if t["breaks_rule"]]
        status = "failed" if unexpected else "passed_with_intentional_exceptions" if intentional else "passed"
        return {"status": status, "structural": "failed" if structural else "passed",
                "intentional_exceptions": intentional, "unexpected_failures": unexpected}

    def to_dict(self) -> dict:
        return {"passed": self.passed, "verdict": self.verdict, "checks": [{**asdict(c), "samples": list(c.samples)} for c in self.checks],
                "rules": [{**asdict(r), "samples": list(r.samples), "expected": list(r.expected)} for r in self.rules],
                "distributions": [{**asdict(d), "explained_by": list(d.explained_by)} for d in self.distributions]} \
            | ({} if self.scenario is None else {"scenario": self.scenario})


def _check(check: str, table: str, constraint: str, rows_checked: int, bad: list[int]) -> Check:
    return Check(check, table, constraint, rows_checked, len(bad), tuple(sorted(bad)[:SAMPLES]))


def _value_ok(column: Column, value) -> bool:
    spec = type_spec(column)
    if spec.kind == "int":
        return spec.min_value <= value <= spec.max_value
    if spec.kind == "decimal":
        if not isinstance(value, Decimal) or not value.is_finite():
            return False
        if not column.type_params:  # unparameterized NUMERIC: any finite value
            return True
        # exact: no context rounding (as_tuple, copy_abs and comparisons never round)
        return value.as_tuple().exponent >= -spec.scale and value.copy_abs() <= spec.max_value
    if spec.kind == "float":
        return math.isfinite(value)
    if spec.kind == "text":
        return "\x00" not in value and (spec.max_length is None or len(value) <= spec.max_length)
    if spec.kind == "uuid":
        return bool(UUID.match(value))
    return True  # bool, date, timestamp: the frame's dtype already guarantees the type


def _type_limits(table: Table, frame: pl.DataFrame) -> list[Check]:
    checks = []
    for column in table.columns:
        if column.name in frame.columns:
            values = frame[column.name].to_list()
            bad = [i for i, v in enumerate(values) if v is not None and not _value_ok(column, v)]
            checks.append(_check("type_limits", table.name, f"{column.name} {column.type}", len(values), bad))
    return checks


def _dtype_ok(column: Column, dtype) -> bool:
    expected = type_spec(column).dtype
    if column.type_name == "DECIMAL" and not column.type_params:
        return isinstance(dtype, pl.Decimal)  # an unparameterized NUMERIC has no scale: any exact decimal is right
    return dtype == expected


def _columns(table: Table, frame: pl.DataFrame) -> Check:
    expected = [(c.name, type_spec(c).dtype) for c in table.columns]
    actual = list(frame.schema.items())
    bad = [i for i in range(max(len(expected), len(actual)))
           if i >= len(expected) or i >= len(actual) or expected[i][0] != actual[i][0]
           or not _dtype_ok(table.columns[i], actual[i][1])]
    return _check("columns", table.name, ", ".join(f"{n} {d}" for n, d in expected), len(actual), bad)


def _duplicates(frame: pl.DataFrame, columns: tuple[str, ...], nulls_distinct: bool) -> list[int]:
    """Rows repeating an earlier row's key. Nulls distinct: rows with any NULL never collide."""
    rows = frame.select(*columns).with_row_index(ROW)
    if nulls_distinct:
        rows = rows.drop_nulls(list(columns))
    groups = rows.group_by(list(columns), maintain_order=True).agg(pl.col(ROW)).filter(pl.col(ROW).list.len() > 1)
    return [r for group in groups[ROW].to_list() for r in sorted(group)[1:]]


def _fk_label(fk: ForeignKey) -> str:
    return f"FOREIGN KEY ({', '.join(fk.columns)}) -> {fk.ref_table} ({', '.join(fk.ref_columns)}) MATCH {fk.match.upper()}"


def _foreign_key(table: Table, fk: ForeignKey, frame: pl.DataFrame, parent: pl.DataFrame) -> Check:
    cols = list(fk.columns)
    rows = frame.select(*cols).with_row_index(ROW)
    nulls = pl.sum_horizontal(*(pl.col(c).is_null().cast(pl.Int32) for c in cols))
    partial = rows.filter((nulls > 0) & (nulls < len(cols)))[ROW].to_list() if fk.match == "full" else []
    complete = rows.filter(nulls == 0)
    keys = parent.select(*fk.ref_columns).drop_nulls().unique().rename(dict(zip(fk.ref_columns, cols)))
    missing = complete.join(keys, on=cols, how="anti")[ROW].to_list()
    return _check("foreign_key", table.name, _fk_label(fk), frame.height, partial + missing)


def _table_checks(plan: LoadedPlan, table: Table, frames: dict[str, pl.DataFrame], rows: int) -> list[Check]:
    frame = frames[table.name]
    checks = [_check("row_count", table.name, f"{rows} rows", frame.height, [0] * abs(frame.height - rows)),
              _columns(table, frame)]
    checks += _type_limits(table, frame)
    present = set(frame.columns)
    for column in table.columns:
        if not column.nullable and column.name in present:
            nulls = frame.with_row_index(ROW).filter(pl.col(column.name).is_null())[ROW].to_list()
            checks.append(_check("not_null", table.name, f"{column.name} NOT NULL", frame.height, nulls))
    if table.primary_key and set(table.primary_key) <= present:
        checks.append(_check("primary_key", table.name, f"PRIMARY KEY ({', '.join(table.primary_key)})", frame.height,
                             _duplicates(frame, table.primary_key, True)))
    for key in table.unique_keys:
        if set(key.columns) <= present:
            label = f"UNIQUE{'' if key.nulls_distinct else ' NULLS NOT DISTINCT'} ({', '.join(key.columns)})"
            checks.append(_check("unique", table.name, label, frame.height, _duplicates(frame, key.columns, key.nulls_distinct)))
    for fk in table.foreign_keys:
        parent = frames.get(fk.ref_table)
        if parent is not None and set(fk.columns) <= present and set(fk.ref_columns) <= set(parent.columns):
            checks.append(_foreign_key(table, fk, frame, parent))
    return checks


def _backfill_checks(plan: LoadedPlan, frames: dict[str, pl.DataFrame], filled: Iterable, pending: int) -> list[Check]:
    """Every backfilled row must now hold a complete FK tuple (the FK check proves it exists)."""
    by_table: dict[tuple[str, int], list[int]] = {}
    for entry in filled:
        by_table.setdefault((entry.table, entry.fk_index), []).append(entry.row)
    checks = []
    for (name, index), rows in sorted(by_table.items()):
        fk = plan.schema.table(name).foreign_keys[index]
        frame = frames[name]
        bad = [r for r in rows if r >= frame.height or any(frame[c][r] is None for c in fk.columns)]
        checks.append(_check("backfill", name, f"backfilled {_fk_label(fk)}", len(rows), bad))
    checks.append(Check("backfill", "", "no pending backfill rows", pending, pending))
    return checks


def _conditional_result(rule, frame: pl.DataFrame, exempt: set) -> RuleResult:
    """Rows that meet the condition must hold the required value (a NULL never meets it, and never satisfies it)."""
    when, then = frame[rule.when_column].to_list(), frame[rule.column].to_list()
    hits = [i for i, v in enumerate(when) if v is not None and equals_value(rule.when_equals, v)]
    bad = [i for i in hits if then[i] is None or not rule_check(rule, then[i])]
    expected, bad = [i for i in bad if i in exempt], [i for i in bad if i not in exempt]
    return RuleResult(rule.id, rule.table, rule.column, len(hits), sum(then[i] is None for i in hits), len(bad),
                      tuple(bad[:SAMPLES]), "rows", tuple(expected))


def _rule_result(rule, frames: dict[str, pl.DataFrame], exempt: set = frozenset()) -> RuleResult:
    """Evaluate one rule on the actual values: NULL passes under `allow` and fails under `forbid`; every
    non-NULL value must satisfy the rule's registry check."""
    frame = frames.get(rule.table)
    needed = [rule.column] + ([rule.when_column] if rule.type == "conditional" else [])
    if frame is None or any(c not in frame.columns for c in needed):
        return RuleResult(rule.id, rule.table, rule.column, 0, 0, 1, (), "column missing")
    if rule.type == "conditional":
        return _conditional_result(rule, frame, exempt)
    values = frame[rule.column].to_list()
    nulls = sum(v is None for v in values)
    if rule.type == "null_rate":  # a setting, not a constraint: reported under distributions
        return RuleResult(rule.id, rule.table, rule.column, len(values), nulls, 0, (), "setting")
    bad = [i for i, v in enumerate(values)
           if (v is None and rule.null_policy == "forbid") or (v is not None and not rule_check(rule, v))]
    expected, bad = [i for i in bad if i in exempt], [i for i in bad if i not in exempt]
    return RuleResult(rule.id, rule.table, rule.column, len(values), nulls, len(bad), tuple(bad[:SAMPLES]),
                      "rows" if values else "empty table", tuple(expected))


def _label(value) -> str:
    return "NULL" if value is None else str(value)


def _shares(weights, n: int) -> list[Fraction]:
    """Exact (fractional) row counts in proportion to `weights`: worked out here, independently of the generator."""
    total = sum(Fraction(str(w)) for w in weights)
    return [Fraction(str(w)) * n / total for w in weights]


def _rounded(share: Fraction) -> int:
    return int(Decimal(share.numerator / share.denominator).quantize(Decimal(1), ROUND_HALF_UP))


def _distribution(rule, frames: dict[str, pl.DataFrame], rules, pinned: int = 0) -> Optional[Distribution]:
    """Over ordinary rows: a scenario's pinned rows (the first `pinned`) are exact, so they don't count."""
    frame = frames.get(rule.table)
    if frame is None or rule.column not in frame.columns:
        return None
    values = frame[rule.column].to_list()[pinned:]
    if rule.type == "null_rate":
        labels, shares = ["NULL"], _shares([rule.rate, 1 - rule.rate], len(values))[:1]
        actual = {"NULL": sum(v is None for v in values)}
    else:
        present = [v for v in values if v is not None]
        labels, shares = list(map(_label, rule.values)), _shares(rule.weights, len(present))
        actual = {_label(listed): sum(same_value(listed, v) for v in present) for listed in rule.values}
    target = {k: _rounded(s) for k, s in zip(labels, shares)}
    within = all(abs(actual[k] - s) <= 1 for k, s in zip(labels, shares))
    others = () if within else tuple(sorted(r.id for r in rules if r.id != rule.id and r.type != "null_rate"
                                            and (r.table, r.column) == (rule.table, rule.column)))
    return Distribution(rule.id, rule.table, rule.column, target, actual, within, explained_by=others)


def _same(fixed, value) -> bool:
    if isinstance(value, dt.datetime) and value.tzinfo:
        value = naive_utc(value)  # fixed timestamps are held in UTC
    return type(fixed) is type(value) and fixed == value


def _scenario_checks(plan: LoadedPlan, frames: dict[str, pl.DataFrame], scenario) -> list[Check]:
    """Fixed values as given; links and group children on exactly the parent rows the scenario names; other rows
    never on a pinned parent; unlinked optional FKs skipped."""
    checks = []
    for table in sorted(plan.schema.tables, key=lambda t: t.name):
        frame = frames.get(table.name)
        if frame is None or frame.height != scenario.rows[table.name]:
            continue  # the row_count check already fails
        fixed = scenario.fixed[table.name]
        cells = [(r, c, v) for r, values in sorted(fixed.items()) for c, v in sorted(values.items())]
        if cells:
            bad = sorted({r for r, c, v in cells if not (v is None and frame[c][r] is None)
                          and (v is None or not _same(v, frame[c][r]))})
            checks.append(_check("scenario_values", table.name, "fixed values as given", len(cells), bad))
        for index, fk in enumerate(table.foreign_keys):
            parent = frames.get(fk.ref_table)
            picks = scenario.picks[table.name][index]
            if parent is None or not picks:
                continue
            child_keys = list(zip(*(frame[c].to_list() for c in fk.columns)))
            parent_keys = list(zip(*(parent[c].to_list() for c in fk.ref_columns)))
            pinned_keys = set(parent_keys[:scenario.pinned[fk.ref_table]])
            bad = []
            for r, pick in enumerate(picks):
                key = child_keys[r]
                if pick is None:
                    wrong = None not in key  # an unlinked optional FK is skipped
                elif pick == ANY:
                    wrong = None not in key and key in pinned_keys
                else:
                    wrong = pick >= len(parent_keys) or key != parent_keys[pick]
                if wrong:
                    bad.append(r)
            checks.append(_check("scenario_links", table.name, f"{_fk_label(fk)} as the scenario links it", len(picks), bad))
    return checks


def _negative_tests(scenario, results: list[RuleResult]) -> tuple[Check, list[dict]]:
    expected = {(r.rule_id, row) for r in results for row in r.expected}
    by_row = {where: alias for alias, where in scenario.aliases.items()}
    tests, bad = [], []
    for rule_id, rows in sorted(scenario.exceptions.items()):
        for table, row in sorted(rows):
            breaks = (rule_id, row) in expected
            tests.append({"alias": by_row[(table, row)], "table": table, "row_index": row, "rule": rule_id,
                          "breaks_rule": breaks})
            if not breaks:
                bad.append(row)
    tables = sorted({t["table"] for t in tests})
    return _check("scenario_violations", ", ".join(tables), "declared negative tests break their rule", len(tests), bad), tests


def validate(plan: LoadedPlan, frames: dict[str, pl.DataFrame], rows: dict[str, int], filled: Iterable = (),
             pending: int = 0, rules: Iterable = (), scenario=None) -> Report:
    """Check every table against the plan, and every accepted business rule against the values.
    `filled` lists backfilled rows (table, fk_index, row); `pending` counts ledger rows never backfilled.
    `scenario` (a resolved scenario: aliases, fixed values, FK picks, pinned rows, declared exceptions) adds its
    checks; its declared negative tests are reported as expected, and must break exactly their rule."""
    exceptions = {} if scenario is None else {rule: {row for _, row in where} for rule, where in scenario.exceptions.items()}
    checks = []
    for table in sorted(plan.schema.tables, key=lambda t: t.name):
        if table.name not in frames:
            checks.append(_check("columns", table.name, "table present", 0, [0]))
            continue
        checks += _table_checks(plan, table, frames, rows[table.name])
    checks += _backfill_checks(plan, frames, filled, pending)
    ordered = sorted(rules, key=lambda r: (r.table, r.column, r.type, r.id))
    settings = [r for r in ordered if r.type == "null_rate" or getattr(r, "weights", None)]
    pinned = {} if scenario is None else scenario.pinned
    distributions = [d for d in (_distribution(r, frames, ordered, pinned.get(r.table, 0)) for r in settings) if d is not None]
    results = [_rule_result(r, frames, set(exceptions.get(r.id, ()))) for r in ordered]
    if scenario is None:
        return Report(checks, results, distributions)
    checks += _scenario_checks(plan, frames, scenario)
    check, tests = _negative_tests(scenario, results)
    if tests:
        checks.append(check)
    negative = {(t["table"], t["row_index"]) for t in tests}
    section = {"ordinary_records": {name: n - sum(1 for t, _ in negative if t == name) for name, n in sorted(rows.items())},
               "negative_tests": tests, "unexpected_violations": sum(r.violations for r in results),
               "expected_outcome": scenario.raw.get("expected_outcome"), "pipeline_outcome": PIPELINE_OUTCOME}
    return Report(checks, results, distributions, section)
