"""SQL type specs for supported column types (plan2 G4.1).

`domain_size` is the number of distinct values **SQL** allows (None = more than any row count we'd
generate). It's used to prove impossibility; what the generator itself can produce is
`providers.Provider.capacity`.
"""

from dataclasses import dataclass
from decimal import Context, Decimal
from typing import Optional

import polars as pl

from dcloneb.model import Column

UNICODE_CHARS = 1_112_063  # Unicode scalar values, minus NUL (Postgres text can't hold NUL)
DEFAULT_DECIMAL = (12, 2)  # values written for an unparameterized NUMERIC (any value is valid there)
# Python's default decimal context keeps 28 digits and would round NUMERIC(38, s) values; every decimal
# operation in the generator and validator passes this one explicitly.
EXACT = Context(prec=80)

_INTS = {
    "SMALLINT": (16, pl.Int16), "SMALLSERIAL": (16, pl.Int16),
    "INT": (32, pl.Int32), "SERIAL": (32, pl.Int32),
    "BIGINT": (64, pl.Int64), "BIGSERIAL": (64, pl.Int64),
    "TINYINT": (8, pl.Int8),
}
FLOAT_RANGE = 1_000_000  # FLOAT/DOUBLE values: two decimals within +-FLOAT_RANGE (plan6 B2)
_FLOATS = {"FLOAT": (pl.Float32, 2 ** 32), "DOUBLE": (pl.Float64, 2 ** 64)}


@dataclass(frozen=True)
class TypeSpec:
    sql: str  # the declared type, e.g. "DECIMAL(10, 2)"
    kind: str  # int | decimal | float | bool | text | date | timestamp | uuid
    dtype: pl.DataType
    csv_format: str
    domain_size: Optional[int] = None
    min_value: object = None  # int or Decimal bounds
    max_value: object = None
    precision: Optional[int] = None
    scale: Optional[int] = None
    max_length: Optional[int] = None  # characters; None = unbounded
    fixed_length: bool = False  # CHAR(n)


def _varchar_domain(n: int) -> int:
    return sum(UNICODE_CHARS ** length for length in range(n + 1))


def _char_domain(n: int) -> int:
    # CHAR(n) compares with trailing spaces ignored, so count strings of length <= n not ending in a space:
    # the empty string, plus (any prefix of length < n) + one non-space character
    return 1 + (UNICODE_CHARS - 1) * sum(UNICODE_CHARS ** length for length in range(n))


def type_spec(column: Column) -> TypeSpec:
    """The spec for a column whose type passed `support.check_support`."""
    name, params = column.type_name, column.type_params
    if name in _INTS:
        bits, dtype = _INTS[name]
        return TypeSpec(column.type, "int", dtype, "integer digits", 2 ** bits, -2 ** (bits - 1), 2 ** (bits - 1) - 1)
    if name == "DECIMAL":
        if params:
            precision, scale = params[0], (params[1] if len(params) > 1 else 0)
            dtype, domain = pl.Decimal(precision, scale), 2 * 10 ** precision - 1
        else:
            (precision, scale), domain = DEFAULT_DECIMAL, None
            dtype = pl.Decimal(38, scale)
        bound = Decimal(10 ** precision - 1).scaleb(-scale, context=EXACT)
        return TypeSpec(column.type, "decimal", dtype, f"plain decimal, exactly {scale} fraction digits", domain,
                        -bound, bound, precision, scale)
    if name == "BOOLEAN":
        return TypeSpec(column.type, "bool", pl.Boolean, "true/false", 2)
    if name in ("VARCHAR", "TEXT"):
        n = params[0] if params else None
        return TypeSpec(column.type, "text", pl.String, "UTF-8 text", None if n is None else _varchar_domain(n), max_length=n)
    if name == "CHAR":
        n = params[0] if params else 1  # Postgres: CHAR means CHAR(1)
        return TypeSpec(column.type, "text", pl.String, "UTF-8 text", _char_domain(n), max_length=n, fixed_length=True)
    if name == "DATE":
        return TypeSpec(column.type, "date", pl.Date, "YYYY-MM-DD", 2 ** 31)  # an overestimate is safe for proofs
    if name in _FLOATS:
        dtype, domain = _FLOATS[name]
        return TypeSpec(column.type, "float", dtype, "shortest decimal that reads back as the same value", domain,
                        -FLOAT_RANGE, FLOAT_RANGE)
    if name in ("TIMESTAMP", "TIMESTAMPNTZ"):
        return TypeSpec(column.type, "timestamp", pl.Datetime("us"), "YYYY-MM-DD HH:MM:SS")
    if name == "TIMESTAMPTZ":  # an instant: written in UTC with its offset
        return TypeSpec(column.type, "timestamp", pl.Datetime("us", "UTC"), "YYYY-MM-DD HH:MM:SS+00:00")
    if name == "UUID":
        return TypeSpec(column.type, "uuid", pl.String, "lowercase hyphenated UUID")
    raise ValueError(f"no type spec for {column.type!r}; support.check_support should have rejected it")
