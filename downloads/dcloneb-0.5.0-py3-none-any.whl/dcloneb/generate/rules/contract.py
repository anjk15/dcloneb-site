"""The rules.json contract (plan3 R2): validate the shape against the published JSON Schema and build
typed rules. Meaning (types, bounds, conflicts) is checked later, against the plan, by preflight."""

import datetime as dt
import hashlib
import json
import re
from dataclasses import dataclass, replace
from importlib.resources import files
from pathlib import Path
from typing import Optional, Union

import jsonschema

from dcloneb.generate.errors import GenerationError, Problem

DECIMAL_STRING = re.compile(r"-?(0|[1-9][0-9]*)(\.[0-9]+)?")  # the schema's bound pattern, also for listed decimals
DATE_STRING = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
TIME_STRING = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}( [0-9]{2}:[0-9]{2}:[0-9]{2}(\+00:00)?)?")  # the schema's time bounds


def parse_time(value: str, kind: str):
    """A date/timestamp bound as the generator holds it: a date, or a naive datetime in UTC (a date alone is midnight).
    ValueError if it isn't a real date or time."""
    if kind == "date":
        return dt.date.fromisoformat(value)
    text = value.removesuffix("+00:00")
    return dt.datetime.fromisoformat(text) if " " in text else dt.datetime.combine(dt.date.fromisoformat(text), dt.time())


SCHEMA = json.loads(files("dcloneb.generate.rules").joinpath("rules.schema.json").read_text(encoding="utf-8"))
_VALIDATOR = jsonschema.Draft202012Validator(SCHEMA)


@dataclass(frozen=True)
class RangeRule:
    id: str
    table: str
    column: str
    null_policy: str
    min: Union[int, str, None] = None  # int for integer columns; decimal, date or timestamp string otherwise
    min_inclusive: Optional[bool] = None
    max: Union[int, str, None] = None
    max_inclusive: Optional[bool] = None
    type: str = "range"
    origin: str = "business"  # rules_version 2: business | observed (plan6 D1)


@dataclass(frozen=True)
class AllowedValuesRule:
    id: str
    table: str
    column: str
    null_policy: str
    values: tuple
    type: str = "allowed_values"
    origin: str = "business"  # rules_version 2: business | observed (plan6 D1)
    weights: Optional[tuple] = None  # version 2: one positive weight per value, in the same order (plan6 D3)


@dataclass(frozen=True)
class FormatRule:
    id: str
    table: str
    column: str
    null_policy: str
    format: str
    type: str = "format"
    origin: str = "business"  # rules_version 2: business | observed (plan6 D1)


ID_CHARACTERS = {"digits": "0123456789", "upper": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                 "upper_digits": "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"}  # plan7: what an id_format may be made of


@dataclass(frozen=True)
class IdFormatRule:
    """Version 2: text IDs like ACC-00042, a fixed prefix then exactly `digits` characters from `characters`
    (digits by default, zero-padded)."""
    id: str
    table: str
    column: str
    null_policy: str
    prefix: str
    digits: int
    type: str = "id_format"
    origin: str = "business"
    characters: str = "digits"

    @property
    def alphabet(self) -> str:
        return ID_CHARACTERS[self.characters]


@dataclass(frozen=True)
class ValueKindRule:
    """A generation guide: what the column's values are (plan5). Not a provable constraint."""
    id: str
    table: str
    column: str
    null_policy: str
    kind: str
    type: str = "value_kind"
    origin: str = "business"  # rules_version 2: business | observed (plan6 D1)


@dataclass(frozen=True)
class NullRateRule:
    """A generation setting (plan6 D3): the share of rows left NULL, allocated exactly. Not a constraint."""
    id: str
    table: str
    column: str
    rate: float
    type: str = "null_rate"
    origin: str = "business"


@dataclass(frozen=True)
class ConditionalRule:
    """Version 2 (plan6 D4): when `when_column` equals `when_equals`, `column` must equal `equals` (same table)."""
    id: str
    table: str
    column: str  # the column the rule sets ("then")
    equals: object
    when_column: str
    when_equals: object
    type: str = "conditional"
    origin: str = "business"


KINDS = tuple(next(branch for branch in SCHEMA["properties"]["rules"]["items"]["allOf"]
                   if branch["if"]["properties"]["type"]["const"] == "value_kind")["then"]["properties"]["kind"]["enum"])

Rule = Union[RangeRule, AllowedValuesRule, FormatRule, IdFormatRule, ValueKindRule, NullRateRule, ConditionalRule]


@dataclass(frozen=True)
class RuleSet:
    version: int
    rules: tuple
    source_sha256: Optional[str] = None


def _rule(data: dict) -> Rule:
    origin = data.get("origin", "business")
    if data["type"] == "null_rate":
        return NullRateRule(data["id"], data["table"], data["column"], data["rate"], origin=origin)
    if data["type"] == "conditional":
        return ConditionalRule(data["id"], data["table"], data["then"]["column"], data["then"]["equals"],
                               data["when"]["column"], data["when"]["equals"], origin=origin)
    head = (data["id"], data["table"], data["column"], data["null_policy"])
    if data["type"] == "range":
        return RangeRule(*head, data.get("min"), data.get("min_inclusive"), data.get("max"), data.get("max_inclusive"),
                         origin=origin)
    if data["type"] == "allowed_values":
        weights = tuple(data["weights"]) if "weights" in data else None
        return AllowedValuesRule(*head, tuple(data["values"]), origin=origin, weights=weights)
    if data["type"] == "value_kind":
        return ValueKindRule(*head, data["kind"], origin=origin)
    if data["type"] == "id_format":
        return IdFormatRule(*head, data["prefix"], data["digits"], origin=origin,
                            characters=data.get("characters", "digits"))
    return FormatRule(*head, data["format"], origin=origin)


V2_FIELDS = ("origin", "weights")
V2_TYPES = ("null_rate", "conditional", "id_format")


def _version_problems(data) -> list[Problem]:
    """rules_version 1 files keep their exact meaning: version 2 fields and rule types need version 2."""
    if not isinstance(data, dict) or data.get("rules_version") != 1 or not isinstance(data.get("rules"), list):
        return []
    problems = []
    for i, rule in enumerate(data["rules"]):
        if isinstance(rule, dict):
            used = [f for f in V2_FIELDS if f in rule] + ([f"type {rule['type']}"] if rule.get("type") in V2_TYPES else [])
            if used:
                problems.append(Problem("input", "rules_malformed",
                                        f"{_where(data, ['rules', i])}: {', '.join(used)} needs rules_version 2",
                                        _rule_id(data, ["rules", i])))
    return problems


def _where(data, path: list) -> str:
    if len(path) >= 2 and path[0] == "rules" and isinstance(path[1], int):
        item = data["rules"][path[1]]
        rule_id = item.get("id") if isinstance(item, dict) else None
        return f"rules[{path[1]}]" + (f" (id {rule_id!r})" if isinstance(rule_id, str) and rule_id else "")
    return "rules.json"


def _rule_id(data, path: list) -> tuple[str, ...]:
    if len(path) >= 2 and path[0] == "rules" and isinstance(path[1], int):
        item = data["rules"][path[1]]
        if isinstance(item, dict) and isinstance(item.get("id"), str) and item["id"]:
            return (item["id"],)
    return ()


def _problem(data, error: jsonschema.ValidationError) -> Problem:
    return replace(_shape_problem(data, error), rule_ids=_rule_id(data, list(error.absolute_path)))


CONDITIONAL_LIMITS = ("conditional rules compare one column of the rule's table with one value, using equality only "
                      "(when column equals value, then column equals value); inequalities, OR, and other tables aren't supported")


def _shape_problem(data, error: jsonschema.ValidationError) -> Problem:
    path = list(error.absolute_path)
    where = _where(data, path)
    if len(path) >= 3 and path[2] in ("when", "then") and isinstance(data["rules"][path[1]], dict) \
            and data["rules"][path[1]].get("type") == "conditional":
        return Problem("unsupported", "rule_type_unsupported", f"{where}: {CONDITIONAL_LIMITS}")
    if path == ["rules_version"]:
        return Problem("input", "rules_unsupported_version",
                       f"{where}: rules_version {error.instance!r} is not supported; expected 1 or 2")
    if error.validator == "enum" and path[-1:] == ["type"]:
        return Problem("unsupported", "rule_type_unsupported",
                       f"{where}: rule type {error.instance!r} is not supported; supported: {', '.join(error.validator_value)}")
    if error.validator == "enum" and path[-1:] == ["format"]:
        return Problem("unsupported", "rule_format_unsupported",
                       f"{where}: format {error.instance!r} is not supported; supported: {', '.join(error.validator_value)}")
    if error.validator == "enum" and path[-1:] == ["kind"]:
        return Problem("unsupported", "rule_kind_unsupported",
                       f"{where}: kind {error.instance!r} isn't one of the supported kinds: {', '.join(error.validator_value)}")
    field = ".".join(str(p) for p in path[2:]) if where != "rules.json" else ".".join(str(p) for p in path)
    return Problem("input", "rules_malformed", f"{where}{': ' + field if field else ''}: {error.message}")


def _duplicate_ids(data) -> list[Problem]:
    rules = data.get("rules") if isinstance(data, dict) else None
    if not isinstance(rules, list):
        return []
    seen: dict[str, int] = {}
    problems = []
    for i, rule in enumerate(rules):
        rule_id = rule.get("id") if isinstance(rule, dict) else None
        if isinstance(rule_id, str) and rule_id:
            if rule_id in seen:
                problems.append(Problem("input", "rule_duplicate_id",
                                        f"rules[{i}]: id {rule_id!r} is already used by rules[{seen[rule_id]}]", (rule_id,)))
            else:
                seen[rule_id] = i
    return problems


def parse_rules(data, source_sha256: Optional[str] = None) -> RuleSet:
    """Validate rules.json's shape (every problem at once) and build typed rules, in file order."""
    problems = [_problem(data, e) for e in sorted(_VALIDATOR.iter_errors(data), key=lambda e: list(map(str, e.absolute_path)))]
    problems = list(dict.fromkeys(problems))  # one bad conditional shape can fail several schema checks the same way
    problems += _duplicate_ids(data) + (_version_problems(data) if not problems else [])
    if problems:
        raise GenerationError(problems)
    return RuleSet(data["rules_version"], tuple(_rule(r) for r in data["rules"]), source_sha256)


def load_rules(path: Path) -> RuleSet:
    try:
        raw = Path(path).read_bytes()
    except OSError as e:
        raise GenerationError([Problem("input", "rules_unreadable", f"cannot read rules {path}: {e.strerror or e}")]) from None
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise GenerationError([Problem("input", "rules_invalid_json", f"rules {path} is not valid JSON: {e}")]) from None
    return parse_rules(data, hashlib.sha256(raw).hexdigest())
