"""The email syntax for `format: "email"` (plan3 "Email syntax"), shared by generation and validation.

A strict ASCII subset: `local@domain`, at most 254 characters. The local part (1-64 characters) is
dot-separated runs of letters, digits and `_ + -`. The domain is one or more labels (1-63 letters, digits
or hyphens, not starting or ending with a hyphen) and a final TLD of 2-63 letters. Any letter case is
accepted. It guarantees syntax only, not that an address exists or can receive mail.
"""

import re

MAX_LENGTH = 254
MAX_LOCAL = 64
SHORTEST = "a@b.co"
MIN_LENGTH = len(SHORTEST)

_LOCAL = r"[A-Za-z0-9_+-]+(?:\.[A-Za-z0-9_+-]+)*"
_LABEL = r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
_EMAIL = re.compile(rf"({_LOCAL})@((?:{_LABEL}\.)+[A-Za-z]{{2,63}})", re.ASCII)


def is_email(value) -> bool:
    if not isinstance(value, str) or len(value) > MAX_LENGTH:
        return False
    match = _EMAIL.fullmatch(value)
    return match is not None and len(match.group(1)) <= MAX_LOCAL
