"""Rule-aware value providers (plan3 R7). Same interface as generate.providers (`name`, `capacity`,
`values(n)`, `unique(n)`), but every value satisfies the column's rules by construction. Distributions
are uniform. The validator still checks every value independently.
"""

import datetime as dt
import random
from decimal import Decimal
from typing import Optional

from dcloneb.generate.providers import ALPHABET, FAKER_ATTEMPTS, MAX_ROUNDS, _base36, allocate, generator_capacity
from dcloneb.generate.rules.emails import MAX_LENGTH, MAX_LOCAL, is_email
from dcloneb.generate.types import EXACT

ONE_SIDED_SPAN = 10 ** 12  # units added to the open side of a one-sided range (unparameterized NUMERIC)
TIME_SPAN = {"date": 3650, "timestamp": 3650 * 86400}  # ... of a one-sided date (days) or timestamp (seconds) range
EPOCH_DATE, EPOCH = dt.date(1970, 1, 1), dt.datetime(1970, 1, 1)


class RangeProvider:
    """Uniform integers, decimals at `scale`, dates, or whole-second timestamps in the inclusive interval [low, high]."""

    name = "rule.range"

    def __init__(self, kind: str, low, high, scale: Optional[int], seed: int, label: str = "column"):
        self.kind, self.scale, self.label = kind, scale, label
        self.rng = random.Random(seed)
        self.bounded = low is not None and high is not None
        lo, hi = self._units(low), self._units(high)
        span = TIME_SPAN.get(kind, ONE_SIDED_SPAN)
        if lo is None:
            lo = hi - span
        if hi is None:
            hi = lo + span
        self.lo, self.hi = lo, hi

    def _units(self, value) -> Optional[int]:
        if value is None:
            return None
        if self.kind == "date":
            return (value - EPOCH_DATE).days
        if self.kind == "timestamp":
            return int((value - EPOCH).total_seconds())
        return value if self.kind == "int" else int(value.scaleb(self.scale, context=EXACT))

    def _value(self, units: int):
        if self.kind == "date":
            return EPOCH_DATE + dt.timedelta(days=units)
        if self.kind == "timestamp":
            return EPOCH + dt.timedelta(seconds=units)
        return units if self.kind == "int" else Decimal(units).scaleb(-self.scale, context=EXACT)

    @property
    def capacity(self) -> Optional[int]:
        return self.hi - self.lo + 1 if self.bounded else None

    def values(self, n: int) -> list:
        return [self._value(self.rng.randint(self.lo, self.hi)) for _ in range(n)]

    def unique(self, n: int) -> list:
        size = self.hi - self.lo + 1
        if n > size:
            raise generator_capacity(self.label, n, size, "its range rules")
        return [self._value(u) for u in self.rng.sample(range(self.lo, self.hi + 1), n)]


def id_text(n: int, width: int, alphabet: str = "0123456789") -> str:
    """`n` written in `alphabet` (its first character is zero), padded to `width` characters."""
    out = ""
    for _ in range(width):
        n, r = divmod(n, len(alphabet))
        out = alphabet[r] + out
    return out


class IdFormatProvider:
    """Text IDs like ACC-00042: random numbers below len(alphabet)^digits (distinct for unique columns), written in the
    alphabet and padded after the prefix."""

    name = "rule.id_format"

    def __init__(self, prefix: str, digits: int, seed: int, label: str = "column", alphabet: str = "0123456789"):
        self.prefix, self.digits, self.alphabet = prefix, digits, alphabet
        self.numbers = RangeProvider("int", 0, len(alphabet) ** digits - 1, None, seed, label)

    @property
    def capacity(self) -> int:
        return self.numbers.capacity

    def _text(self, numbers: list) -> list[str]:
        return [self.prefix + id_text(n, self.digits, self.alphabet) for n in numbers]

    def values(self, n: int) -> list[str]:
        return self._text(self.numbers.values(n))

    def unique(self, n: int) -> list[str]:
        return self._text(self.numbers.unique(n))


class ChoiceProvider:
    """Uniform over an allowed set (already intersected with every other rule on the column), or with `weights`, values
    in exact proportion (plan6 D3), shuffled."""

    name = "rule.allowed_values"

    def __init__(self, allowed: tuple, seed: int, label: str = "column", weights: Optional[tuple] = None):
        self.allowed, self.label, self.weights = tuple(allowed), label, weights
        self.rng = random.Random(seed)

    @property
    def capacity(self) -> int:
        return len(self.allowed)

    def values(self, n: int) -> list:
        if self.weights:
            out = [v for v, count in zip(self.allowed, allocate(self.weights, n)) for _ in range(count)]
            self.rng.shuffle(out)
            return out
        return [self.rng.choice(self.allowed) for _ in range(n)]

    def unique(self, n: int) -> list:
        if n > len(self.allowed):
            raise generator_capacity(self.label, n, len(self.allowed), "its allowed values")
        return self.rng.sample(self.allowed, n)


# Generated addresses use reserved domains only (RFC 2606 / RFC 6761), longest-first preference.
FAKER_GIVE_UP = 50
RESERVED_DOMAINS = ("example.com", "example.org", "example.net") + tuple(f"{c}.test" for c in "abcdefghijklmnopqrstuvwxyz")


class EmailProvider:
    """Addresses that pass the email check and fit the column: Faker's (on example.* domains) when they
    fit, otherwise generated `<local>@<reserved domain>` forms. Never truncated, so a column too short for
    the shortest reserved form (`a@b.test`, 8 characters) is a generator limit, not a cut-off address."""

    name = "rule.format.email"

    def __init__(self, max_length: Optional[int], seed: int, locale: str, label: str = "column"):
        from faker import Faker

        self.limit = min(max_length or MAX_LENGTH, MAX_LENGTH)
        self.label = label
        self.rng = random.Random(seed)
        self.fake = Faker(locale)
        self.fake.seed_instance(seed)
        self.domains = [d for d in RESERVED_DOMAINS if self._local_room(d) >= 1]
        self.misses = 0  # consecutive Faker addresses that didn't fit; past FAKER_GIVE_UP Faker isn't asked again

    def _local_room(self, domain: str) -> int:
        return min(MAX_LOCAL, self.limit - 1 - len(domain))

    @property
    def capacity(self) -> int:
        """Distinct generated addresses that fit: base36 local parts up to the room each domain leaves."""
        return sum(36 ** self._local_room(d) for d in self.domains)

    def _limit_error(self, n: int):
        return generator_capacity(self.label, n, self.capacity,
                                  f"emails of at most {self.limit} characters on reserved domains (shortest: a@b.test)")

    def _faker(self) -> Optional[str]:
        for _ in range(FAKER_ATTEMPTS):
            if self.misses >= FAKER_GIVE_UP:
                return None  # Faker's addresses don't fit this column; stop paying for them
            value = self.fake.email().lower()
            if len(value) <= self.limit and is_email(value):
                self.misses = 0
                return value
            self.misses += 1
        return None

    def values(self, n: int) -> list[str]:
        if n and not self.domains:
            raise self._limit_error(n)
        out = []
        for _ in range(n):
            value = self._faker()
            if value is None:
                domain = self.rng.choice(self.domains)
                local = "".join(self.rng.choice(ALPHABET) for _ in range(self.rng.randint(1, min(8, self._local_room(domain)))))
                value = f"{local}@{domain}"
            out.append(value)
        return out

    def _generated(self):
        """Every fitting generated address, in a fixed order: local index m with each domain that has room."""
        m = 0
        while True:
            local = _base36(m)
            fitting = [d for d in self.domains if len(local) <= self._local_room(d)]
            if not fitting:
                return
            for d in fitting:
                yield f"{local}@{d}"
            m += 1

    def unique(self, n: int) -> list[str]:
        if n > self.capacity and n:
            raise self._limit_error(n)
        seen: dict[str, None] = {}
        for _ in range(MAX_ROUNDS):
            missing, before = n - len(seen), len(seen)
            if missing <= 0:
                break
            for _ in range(missing):
                value = self._faker()
                if value is not None:
                    seen.setdefault(value)
            if len(seen) == before:
                break  # a round that adds nothing won't be followed by one that does
        for value in self._generated():
            if len(seen) >= n:
                break
            seen.setdefault(value)
        if len(seen) < n:
            raise self._limit_error(n)
        return list(seen)[:n]
