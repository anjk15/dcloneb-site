"""Business-rules engine: rules.json in, rule-guided generation and independent rule checks (plan3.md)."""
