"""Preflight (plan3 R4-R6): check rules against the analyzed schema and against each other, before any
value is generated. Read-only. It reports proven problems only; it doesn't claim to find every conflict
(the validator still checks every rule twice before anything is published).
"""

import hashlib
import json
from dataclasses import dataclass, field, replace
from decimal import Decimal
from typing import Optional

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.plan_input import LoadedPlan
from dcloneb.generate.rules.domain import ColumnDomain, build_domain, canonical
from dcloneb.generate.rules.emails import SHORTEST
from dcloneb.generate.rules.contract import (DATE_STRING, DECIMAL_STRING, TIME_STRING, AllowedValuesRule,
                                             ConditionalRule, FormatRule, IdFormatRule, NullRateRule, RangeRule, RuleSet,
                                             ValueKindRule,
                                             parse_time)
from dcloneb.generate.rules.registry import REGISTRY, check, equals_value
from dcloneb.generate.types import EXACT, TypeSpec, type_spec
from dcloneb.model import Column, Table

DEFERRED_KINDS = ("date", "timestamp", "uuid")  # ranges / allowed lists here are planned, not invalid
BARE_NUMERIC_MAX_SCALE = 6  # unparameterized NUMERIC: generated at max(2, decimals in the rules), at most this
REPRESENTATION = {"int": "JSON integers", "decimal": 'decimal strings (e.g. "19.99")', "text": "JSON strings",
                  "bool": "JSON booleans", "date": 'ISO date strings (e.g. "2024-12-31")',
                  "timestamp": 'ISO timestamp strings in UTC (e.g. "2024-12-31 17:30:00")'}


@dataclass(frozen=True)
class NormalizedRules:
    rules: tuple  # sorted by (table, column, type, id)
    domains: dict  # (table, column) -> ColumnDomain, the AND of that column's rules
    always_null: set = field(default_factory=set)  # (table, column): no non-NULL value passes, but NULL does
    source_sha256: Optional[str] = None  # of the rules file as given
    version: int = 1  # rules_version of the input; the canonical output keeps it
    null_rates: dict = field(default_factory=dict)  # (table, column) -> NullRateRule (plan6 D3)
    conditionals: tuple = ()  # (ConditionalRule, typed when value, typed then value) (plan6 D4)
    warnings: tuple = ()  # Problems that don't stop generation, e.g. rule_never_applies

    def to_dict(self) -> dict:
        """Canonical rules.json: sorted rules, sorted values, decimals in plain notation (listed values at the
        column's scale). Equivalent inputs give identical output."""
        rules = [_canonical_rule(r, self.domains.get((r.table, r.column))) for r in self.rules]
        if self.version >= 2:
            rules = [{**out, "origin": r.origin} for out, r in zip(rules, self.rules)]
        return {"rules_version": self.version, "rules": rules}

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, indent=2, ensure_ascii=False) + "\n"

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.to_json().encode("utf-8")).hexdigest()


def _plain(value: Decimal) -> str:
    return f"{value:f}"


def _canonical_rule(rule, d: Optional[ColumnDomain]) -> dict:
    if isinstance(rule, ConditionalRule):
        return {"id": rule.id, "type": rule.type, "table": rule.table, "when": {"column": rule.when_column, "equals": rule.when_equals},
                "then": {"column": rule.column, "equals": rule.equals}}
    if isinstance(rule, NullRateRule):
        return {"id": rule.id, "type": rule.type, "table": rule.table, "column": rule.column, "rate": rule.rate}
    out = {"id": rule.id, "type": rule.type, "table": rule.table, "column": rule.column, "null_policy": rule.null_policy}
    if isinstance(rule, ValueKindRule):
        out["kind"] = rule.kind
    elif isinstance(rule, IdFormatRule):
        out["prefix"], out["digits"] = rule.prefix, rule.digits
        if rule.characters != "digits":  # the default stays out, so existing rules keep their hash
            out["characters"] = rule.characters
    elif isinstance(rule, RangeRule):
        for side in ("min", "max"):
            value = getattr(rule, side)
            if value is not None:
                out[side] = _plain(Decimal(value).normalize(EXACT)) if d.kind == "decimal" else value
                out[f"{side}_inclusive"] = getattr(rule, f"{side}_inclusive")
    elif isinstance(rule, AllowedValuesRule):
        pairs = sorted({canonical(d.kind, d.scale, v): w for v, w in zip(rule.values, rule.weights or [None] * len(rule.values))}.items())
        values = [v for v, _ in pairs]
        out["values"] = [_plain(v) for v in values] if d.kind == "decimal" else values
        if rule.weights:
            out["weights"] = [w for _, w in pairs]
    else:
        out["format"] = rule.format
    return out


def _label(rule) -> str:
    return f"rule {rule.id!r} ({rule.table}.{rule.column})"


def _bind(plan: LoadedPlan, rule) -> tuple[Optional[tuple[Table, Column]], list[Problem]]:
    table = plan.schema.table(rule.table)
    if table is None:
        names = ", ".join(sorted(t.name for t in plan.schema.tables))
        return None, [Problem("input", "rule_unknown_table",
                              f"{_label(rule)}: table {rule.table!r} is not in the plan; plan tables: {names}")]
    column = table.column(rule.column)
    if column is None:
        names = ", ".join(c.name for c in table.columns)
        return None, [Problem("input", "rule_unknown_column",
                              f"{_label(rule)}: {rule.table} has no column {rule.column!r}; its columns: {names}")]
    return (table, column), []


KEY_RULES = ("range", "id_format")  # what the generator's own key values may look like; foreign keys copy them


def _target_problems(plan: LoadedPlan, rule, table: Table, column: Column, spec: TypeSpec) -> list[Problem]:
    """v1 limits (plan3 R6): no rules on key columns, whose values come from or feed relationships, except a range or
    id_format on keys the generator makes (not identity, not foreign key); no allowed_values/format on CHAR(n), whose
    blank-padding changes what counts as equal, and an id_format there must fill the column exactly."""
    name = column.name
    referencing = sorted(f"{t.name}({', '.join(fk.columns)})" for t in plan.schema.tables for fk in t.foreign_keys
                         if fk.ref_table == table.name and name in fk.ref_columns)
    made = rule.type in KEY_RULES
    reason = ("it is an identity/serial column" if column.identity
              else "it is a foreign key column, which copies its parent's values"
              if any(name in fk.columns for fk in table.foreign_keys)
              else "it is part of the primary key" if name in (table.primary_key or ()) and not made
              else f"it is referenced by {', '.join(referencing)}" if referencing and not made
              else None)
    if reason:
        return [Problem("unsupported", "rule_target_unsupported",
                        f"{_label(rule)}: rules on key columns aren't supported in this version: {reason}. "
                        "Rules on the table's other columns are.")]
    if spec.fixed_length and rule.type in ("allowed_values", "format", "value_kind", "conditional"):
        return [Problem("unsupported", "rule_target_unsupported",
                        f"{_label(rule)}: {rule.type} rules on {spec.sql} (CHAR) columns aren't supported in this "
                        "version, because CHAR pads values with spaces; use VARCHAR or TEXT")]
    if spec.fixed_length and isinstance(rule, IdFormatRule) and len(rule.prefix) + rule.digits != spec.max_length:
        return [Problem("unsupported", "rule_target_unsupported",
                        f"{_label(rule)}: on {spec.sql} the prefix and digits must fill all {spec.max_length} characters "
                        f"(CHAR pads shorter values with spaces); these give {len(rule.prefix) + rule.digits}")]
    return []


def _type_problems(rule, spec: TypeSpec, version: int) -> list[Problem]:
    if spec.kind in ("date", "timestamp") and rule.type == "range" and version < 2:
        return [Problem("unsupported", "rule_type_unsupported",
                        f"{_label(rule)}: range rules on {spec.sql} columns need rules_version 2")]
    if spec.kind in REGISTRY[rule.type].kinds:
        return []
    if spec.kind in DEFERRED_KINDS and rule.type in ("range", "allowed_values"):
        return [Problem("unsupported", "rule_type_unsupported",
                        f"{_label(rule)}: {rule.type} rules on {spec.sql} columns are not supported yet")]
    return [Problem("input", "rule_type_mismatch",
                    f"{_label(rule)}: a {rule.type} rule doesn't apply to a {spec.sql} column; "
                    f"it applies to: {', '.join(REGISTRY[rule.type].kinds)}")]


def _represents(kind: str, value) -> bool:
    """Is `value` written the way rules.json requires for this column kind?"""
    if kind == "int":
        return isinstance(value, int) and not isinstance(value, bool)
    if kind == "decimal":
        return isinstance(value, str) and DECIMAL_STRING.fullmatch(value) is not None
    if kind == "text":
        return isinstance(value, str)
    if kind == "bool":
        return isinstance(value, bool)
    if kind in ("date", "timestamp"):
        return isinstance(value, str) and (DATE_STRING if kind == "date" else TIME_STRING).fullmatch(value) is not None
    return False


def _values(rule) -> list[tuple[str, object]]:
    if isinstance(rule, RangeRule):
        return [(name, getattr(rule, name)) for name in ("min", "max") if getattr(rule, name) is not None]
    if isinstance(rule, AllowedValuesRule):
        return [(f"values[{i}]", v) for i, v in enumerate(rule.values)]
    return []


def _representation_problems(rule, spec: TypeSpec) -> list[Problem]:
    return [Problem("input", "rule_value_invalid",
                    f"{_label(rule)}: {where} = {value!r}; {spec.sql} columns take {REPRESENTATION[spec.kind]}")
            for where, value in _values(rule) if not _represents(spec.kind, value)]


def decimals(value: str) -> int:
    """Fraction digits a decimal string needs (trailing zeros don't count)."""
    exponent = Decimal(value).normalize(EXACT).as_tuple().exponent
    return max(0, -exponent)


def _fit_problem(spec: TypeSpec, column: Column, value) -> Optional[str]:
    """Why a listed value can't be stored in the column, or None."""
    if spec.kind == "int" and not spec.min_value <= value <= spec.max_value:
        return f"outside {spec.sql}'s range {spec.min_value}..{spec.max_value}"
    if spec.kind == "text":
        if "\x00" in value:
            return "contains a NUL character, which PostgreSQL text can't store"
        if spec.max_length is not None and len(value) > spec.max_length:
            return f"is {len(value)} characters; {spec.sql} holds at most {spec.max_length}"
    if spec.kind == "decimal" and column.type_params:
        number = Decimal(value)
        if decimals(value) > spec.scale or number.copy_abs() > spec.max_value:
            return f"needs more than {spec.sql}'s precision {spec.precision}, scale {spec.scale}"
    return None


def _fit_problems(rule, spec: TypeSpec, column: Column) -> list[Problem]:
    problems = []
    if spec.kind in ("date", "timestamp"):
        for where, value in _values(rule):
            try:
                parse_time(value, spec.kind)
            except ValueError:
                problems.append(Problem("input", "rule_value_invalid", f"{_label(rule)}: {where} = {value!r} isn't a real date or time"))
    if isinstance(rule, AllowedValuesRule):
        for i, value in enumerate(rule.values):
            why = _fit_problem(spec, column, value)
            if why:
                problems.append(Problem("input", "rule_value_invalid", f"{_label(rule)}: values[{i}] = {value!r} doesn't fit: {why}"))
    if spec.kind == "decimal" and not column.type_params:
        too_precise = [(where, v) for where, v in _values(rule) if decimals(v) > BARE_NUMERIC_MAX_SCALE]
        problems += [Problem("unsupported", "rule_precision_unsupported",
                             f"{_label(rule)}: {where} = {v!r} has more than {BARE_NUMERIC_MAX_SCALE} decimals, "
                             f"the most supported on an unparameterized NUMERIC column") for where, v in too_precise]
    return problems


def _empty_problem(d: ColumnDomain, spec: TypeSpec) -> Problem:
    """No non-NULL value satisfies the column's rules, and NULL isn't acceptable either."""
    ids = ", ".join(repr(i) for i in d.rule_ids)
    where = f"{d.table}.{d.column}"
    forbidders = ", ".join(repr(i) for i in d.forbid_ids)
    why = f" (and NULL isn't acceptable: {'rule(s) ' + forbidders + ' forbid it' if d.forbid_ids else 'the column is NOT NULL'})"
    if len(d.rule_ids) == 1:
        hint = (f"; the shortest email, {SHORTEST!r}, needs {len(SHORTEST)} characters" if "email" in d.formats
                else f"; its IDs are {len(d.id_format.prefix) + d.id_format.digits} characters" if d.id_format else "")
        return Problem("impossible", "rule_unsatisfiable",
                       f"rule {ids} ({where}): no {spec.sql} value satisfies it{hint}{why}", d.rule_ids)
    return Problem("impossible", "rule_conflict", f"rules {ids} ({where}) together leave no {spec.sql} value{why}",
                   d.rule_ids)


def _key_bound(table: Table, columns: tuple, nulls_distinct: bool, domains: dict, rows: dict) -> Optional[int]:
    """Upper bound on distinct combinations the schema and rules allow for a key (None = unbounded).
    An overestimate is safe: it can only miss an impossibility, never claim a false one."""
    def null_ok(name):
        d = domains.get((table.name, name))
        return d.nulls_ok if d else table.column(name).nullable

    if nulls_distinct and any(null_ok(c) for c in columns):
        return None  # rows with a NULL never collide
    bound, covered = 1, set()
    if nulls_distinct:
        for fk in table.foreign_keys:  # rules never target FK columns, so their values are parent tuples
            group = set(fk.columns) & set(columns)
            if group:
                bound *= rows.get(fk.ref_table, 0)
                covered |= group
    for name in columns:
        if name not in covered:
            d = domains.get((table.name, name))
            size = d.size if d else type_spec(table.column(name)).domain_size
            if size is None:
                return None
            bound *= size + (1 if null_ok(name) else 0)  # NULLS NOT DISTINCT: NULL counts as one more value
    return bound


def _capacity_problems(plan: LoadedPlan, domains: dict, rows: dict) -> list[Problem]:
    problems = []
    for table in plan.schema.tables:
        ruled = {c for (t, c) in domains if t == table.name}
        keys = ([(table.primary_key, True)] if table.primary_key else []) + [(k.columns, k.nulls_distinct) for k in table.unique_keys]
        for columns, nulls_distinct in keys:
            if not ruled & set(columns) or table.name not in rows:
                continue
            limit = _key_bound(table, tuple(columns), nulls_distinct, domains, rows)
            if limit is not None and rows[table.name] > limit:
                ids = sorted({i for c in columns if (table.name, c) in domains for i in domains[(table.name, c)].rule_ids})
                problems.append(Problem(
                    "impossible", "rule_domain_capacity",
                    f"{table.name} UNIQUE ({', '.join(columns)}): {rows[table.name]} rows need {rows[table.name]} distinct "
                    f"combinations, but rules {', '.join(repr(i) for i in ids)} leave at most {limit}", tuple(ids)))
    return problems


def _weights_problems(rule) -> list[Problem]:
    if isinstance(rule, AllowedValuesRule) and rule.weights and len(rule.weights) != len(rule.values):
        return [Problem("input", "rule_weights_invalid",
                        f"{_label(rule)}: {len(rule.weights)} weight(s) for {len(rule.values)} value(s); give one weight per value")]
    return []


def _weight_conflicts(by_column: dict) -> list[Problem]:
    problems = []
    for (table, column), rules in sorted(by_column.items()):
        weighted = sorted(r.id for r in rules if isinstance(r, AllowedValuesRule) and r.weights)
        if len(weighted) > 1:
            problems.append(Problem("input", "rule_weights_invalid",
                                    f"rules {', '.join(repr(i) for i in weighted)} ({table}.{column}) both give weights; keep one",
                                    tuple(weighted)))
    return problems


def _null_rate_problems(plan: LoadedPlan, null_rates: list, domains: dict) -> list[Problem]:
    """A null rate needs a column that may be NULL, and one rate per column."""
    problems, seen = [], {}
    for rule in null_rates:
        key = (rule.table, rule.column)
        column, d = plan.schema.table(rule.table).column(rule.column), domains.get(key)
        why = ("the column is NOT NULL" if not column.nullable
               else f"rule(s) {', '.join(repr(i) for i in d.forbid_ids)} forbid NULL" if d and not d.nulls_ok
               else f"rule {seen[key]!r} already sets its null rate" if key in seen else None)
        if why:
            problems.append(Problem("input", "rule_null_rate_invalid", f"{_label(rule)}: no NULL rate can apply: {why}", (rule.id,)))
        seen.setdefault(key, rule.id)
    return problems


def _conditional_problems(plan: LoadedPlan, rule: ConditionalRule, version: int) -> list[Problem]:
    """Both columns exist, aren't keys, and take the values as written; conflicts with other rules come later."""
    table = plan.schema.table(rule.table)
    if table is None:
        return _bind(plan, rule)[1]
    problems = []
    for name in (rule.when_column, rule.column):
        if table.column(name) is None:
            problems.append(Problem("input", "rule_unknown_column", f"{_label(rule)}: {rule.table} has no column {name!r}; "
                                                                   f"its columns: {', '.join(c.name for c in table.columns)}"))
    if problems:
        return problems
    if rule.when_column == rule.column:
        return [Problem("input", "rule_conditional_invalid", f"{_label(rule)}: the condition and the value it sets are the "
                                                             f"same column; use a range or allowed_values rule instead")]
    keys = {c for key in table.keys() for c in key}
    for name, value, where in ((rule.when_column, rule.when_equals, "when.equals"), (rule.column, rule.equals, "then.equals")):
        column = table.column(name)
        spec = type_spec(column)
        found = _target_problems(plan, rule, table, column, spec) or _type_problems(rule, spec, version)
        if not found and name in keys:
            found = [Problem("unsupported", "rule_target_unsupported",
                             f"{_label(rule)}: {name} is part of a UNIQUE key; conditional rules can't use key columns")]
        if not found and not _represents(spec.kind, value):
            found = [Problem("input", "rule_value_invalid", f"{_label(rule)}: {where} = {value!r}; {spec.sql} columns take "
                                                            f"{REPRESENTATION[spec.kind]}")]
        if not found:
            why = _fit_problem(spec, column, value) if spec.kind not in ("date", "timestamp") else None
            try:
                canonical(spec.kind, spec.scale, value)
            except ValueError:
                why = "isn't a real date or time"
            if why:
                found = [Problem("input", "rule_value_invalid", f"{_label(rule)}: {where} = {value!r} doesn't fit: {why}")]
        problems += found
    return problems


def _typed(plan: LoadedPlan, table: str, column: str, value, domains: dict):
    spec, d = type_spec(plan.schema.table(table).column(column)), domains.get((table, column))
    return canonical(spec.kind, d.scale if d and d.scale is not None else spec.scale, value)


def _conditional_conflicts(plan: LoadedPlan, conditionals: list, by_column: dict, domains: dict) -> tuple[list, list]:
    """(problems, warnings): a required value another rule rejects; two conditions that can hold together but require
    different values; chains (a set column is another rule's condition); conditions no allowed value can meet."""
    problems, warnings = [], []
    whens = {(r.table, r.when_column) for r in conditionals}
    for rule in conditionals:
        if (rule.table, rule.column) in whens:
            problems.append(Problem("unsupported", "rule_type_unsupported",
                                    f"{_label(rule)}: {rule.column} is also another conditional rule's condition; chained "
                                    "conditional rules aren't supported", (rule.id,)))
        then = _typed(plan, rule.table, rule.column, rule.equals, domains)
        for other in by_column.get((rule.table, rule.column), []):
            if not check(other, then):
                problems.append(Problem("impossible", "rule_conflict",
                                        f"rules {rule.id!r} and {other.id!r} ({rule.table}.{rule.column}): {rule.id!r} requires "
                                        f"{rule.equals!r}, which {other.id!r} doesn't allow", tuple(sorted((rule.id, other.id)))))
        when = _typed(plan, rule.table, rule.when_column, rule.when_equals, domains)
        others = by_column.get((rule.table, rule.when_column), [])
        if any(not check(other, when) for other in others):
            warnings.append(Problem("input", "rule_never_applies",
                                    f"{_label(rule)}: no value the other rules allow for {rule.when_column} equals "
                                    f"{rule.when_equals!r}, so it never applies", (rule.id,)))
    for i, a in enumerate(conditionals):
        for b in conditionals[i + 1:]:
            if (a.table, a.column) != (b.table, b.column):
                continue
            different = not equals_value(a.equals, _typed(plan, b.table, b.column, b.equals, domains))
            together = a.when_column != b.when_column or equals_value(a.when_equals, _typed(plan, b.table, b.when_column,
                                                                                            b.when_equals, domains))
            if different and together:
                problems.append(Problem("impossible", "rule_conflict",
                                        f"rules {a.id!r} and {b.id!r} ({a.table}.{a.column}): both can apply to one row but "
                                        f"require different values ({a.equals!r}, {b.equals!r})", tuple(sorted((a.id, b.id)))))
    return problems, warnings


def _kind_conflicts(by_column: dict) -> list[Problem]:
    """One column, one meaning: different value_kinds or id_formats, or a mix of them and format email, contradict each other."""
    problems = []
    for (table, column), rules in sorted(by_column.items()):
        guides = [r for r in rules if isinstance(r, (ValueKindRule, IdFormatRule)) or (isinstance(r, FormatRule) and r.format == "email")]
        meanings = {f"id {r.prefix}+{r.digits} {r.characters}" if isinstance(r, IdFormatRule) else getattr(r, "kind", "email")
                    for r in guides}
        if len(meanings) > 1:
            ids = tuple(sorted(r.id for r in guides))
            problems.append(Problem("input", "rule_kind_conflict",
                                    f"rules {', '.join(repr(i) for i in ids)} ({table}.{column}) give it different meanings "
                                    f"({', '.join(sorted(meanings))}); keep one", ids))
    return problems


def preflight(plan: LoadedPlan, rules: RuleSet, rows: Optional[dict[str, int]] = None) -> NormalizedRules:
    """Validate and normalize `rules` for `plan` (which passed `support.check_support`). `rows` (table ->
    row count) enables capacity checks. Raises GenerationError with every problem found."""
    problems = []
    by_column: dict[tuple[str, str], list] = {}
    null_rates, conditionals = [], []
    for rule in rules.rules:
        if isinstance(rule, ConditionalRule):
            found = _conditional_problems(plan, rule, rules.version)
            problems += [replace(p, rule_ids=(rule.id,)) for p in found]
            if not found:
                conditionals.append(rule)
            continue
        bound, found = _bind(plan, rule)
        if bound and isinstance(rule, NullRateRule):
            found = _target_problems(plan, rule, *bound, type_spec(bound[1]))
        elif bound:
            spec = type_spec(bound[1])
            found = (_target_problems(plan, rule, *bound, spec) or _type_problems(rule, spec, rules.version)
                     or _representation_problems(rule, spec) or _fit_problems(rule, spec, bound[1]) or _weights_problems(rule))
        problems += [replace(p, rule_ids=(rule.id,)) for p in found]
        if bound and not found:
            if isinstance(rule, NullRateRule):
                null_rates.append(rule)
            else:
                by_column.setdefault((rule.table, rule.column), []).append(rule)
    problems += _kind_conflicts(by_column) + _weight_conflicts(by_column)
    if problems:
        raise GenerationError(problems)
    ordered = tuple(sorted(rules.rules, key=lambda r: (r.table, r.column, r.type, r.id)))
    domains = {}
    for (table, column), column_rules in sorted(by_column.items()):
        col = plan.schema.table(table).column(column)
        domains[(table, column)] = build_domain(table, type_spec(col), col, sorted(column_rules, key=lambda r: (r.type, r.id)))
    always_null = set()
    for key, d in domains.items():
        if d.size == 0:
            if d.nulls_ok:
                always_null.add(key)  # every rule allows NULL and so does the schema: generate NULL, not an error
            else:
                problems.append(_empty_problem(d, type_spec(plan.schema.table(key[0]).column(key[1]))))
    problems += _null_rate_problems(plan, null_rates, domains)
    conflicts, warnings = _conditional_conflicts(plan, conditionals, by_column, domains) if not problems else ([], [])
    problems += conflicts
    if rows is not None and not problems:
        problems += _capacity_problems(plan, domains, rows)
    if problems:
        raise GenerationError(problems)
    typed = tuple((r, _typed(plan, r.table, r.when_column, r.when_equals, domains),
                   _typed(plan, r.table, r.column, r.equals, domains)) for r in conditionals)
    return NormalizedRules(ordered, domains, always_null, rules.source_sha256, rules.version,
                           {(r.table, r.column): r for r in null_rates}, typed, tuple(warnings))
