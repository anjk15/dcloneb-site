"""Generation errors (plan2 "Error kinds"). Every problem found in one pass is reported together."""

from dataclasses import dataclass

# input: bad config/plan; unsupported: outside the support matrix or the generator's strategies;
# impossible: provably no valid dataset; retry_exhausted: NOT proof of impossibility;
# validation_failed: generated data failed the independent validator (a dcloneb bug).
KINDS = ("input", "unsupported", "impossible", "retry_exhausted", "validation_failed")

# Said whenever a limit comes from the generator's strategies, not from SQL.
MAY_STILL_EXIST = "a valid dataset may still exist, outside the generator's supported strategies"


@dataclass(frozen=True)
class Problem:
    kind: str
    code: str  # stable identifier, e.g. "config_unknown_key"
    message: str
    rule_ids: tuple[str, ...] = ()  # business rules the problem is about (plan4 M8), for agents to act on

    def __post_init__(self):
        if self.kind not in KINDS:
            raise ValueError(f"kind must be one of {', '.join(KINDS)}, got {self.kind!r}")


class GenerationError(Exception):
    def __init__(self, problems: list[Problem]):
        if not problems:
            raise ValueError("GenerationError needs at least one problem")
        self.problems = list(problems)
        super().__init__("; ".join(f"{p.code}: {p.message}" for p in self.problems))

    @property
    def kind(self) -> str:
        return self.problems[0].kind
