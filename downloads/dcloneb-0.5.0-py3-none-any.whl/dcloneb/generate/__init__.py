"""Local baseline test-data generator: consumes plan.json, writes validated CSVs (plan2.md)."""
