"""Capacity checks before any value is generated (plan2 G6).

`impossible` means SQL itself rules the request out (from row counts and SQL type domains only).
`generator_capacity` means only the generator's own strategies fall short (identity 1..N, never-NULL
columns, a 36-character alphabet, 2000-2030 dates): a valid dataset may still exist.
"""

from math import prod
from typing import Optional

from dcloneb.generate.errors import MAY_STILL_EXIST, GenerationError, Problem
from dcloneb.generate.strategy import FkPlan, GenerationPlan, KeyPlan, TablePlan

def _fk_label(table: TablePlan, f: FkPlan) -> str:
    return f"{table.name}({', '.join(f.fk.columns)}) -> {f.fk.ref_table}"


def _impossible(code: str, message: str) -> Problem:
    return Problem("impossible", code, message)


def _generator(message: str) -> Problem:
    return Problem("unsupported", "generator_capacity", f"{message}; {MAY_STILL_EXIST}")


def _fk_problems(plan: GenerationPlan, table: TablePlan, f: FkPlan) -> tuple[list[Problem], int]:
    """Problems, and how many rows must skip the FK (NULL) because there aren't enough parents."""
    n, m = table.rows, plan.tables[f.fk.ref_table].rows
    label = _fk_label(table, f)
    if m == 0:
        if not f.can_be_null:
            return [_impossible("fk_parent_empty", f"{label}: {table.name} needs {n} rows, each referencing a parent, "
                                f"but {f.fk.ref_table} has 0 rows")], 0
        if not f.nullable:
            return [_generator(f"{label}: {f.fk.ref_table} has 0 rows and the generator never writes NULL into the "
                               f"columns that would skip this foreign key")], 0
        return [], n
    elif f.unique and n > m:
        if not f.can_be_null:
            return [_impossible("unique_fk_capacity", f"{label}: the foreign key is unique, so {n} rows need {n} distinct "
                                f"parents, but {f.fk.ref_table} has {m} rows")], 0
        if not f.nullable:
            return [_generator(f"{label}: unique foreign key with {n} rows but {m} parents, and the generator never "
                               "writes NULL into the columns that would skip it")], 0
        return [], n - m
    return [], 0


def _sql_domain(plan: GenerationPlan, table: TablePlan, key: KeyPlan) -> Optional[int]:
    """Upper bound on distinct combinations SQL allows for the key (None = unbounded). An overestimate
    is safe: it can only miss an impossibility, never claim a false one."""
    columns = [table.columns[c] for c in key.columns]
    if key.nulls_distinct and any(c.sql_nullable for c in columns):
        return None  # rows with a NULL never collide
    bound, covered = 1, set()
    if key.nulls_distinct:  # every column is NOT NULL, so each FK group holds real parent tuples
        for f in table.fks:
            group = set(f.fk.columns) & set(key.columns)
            if group:  # distinct projections of parent tuples can't outnumber the parent's rows
                bound *= plan.tables[f.fk.ref_table].rows
                covered |= group
    for c in columns:  # NULLS NOT DISTINCT: NULL counts as one more value per nullable column
        if c.name not in covered:
            if c.spec.domain_size is None:
                return None
            bound *= c.spec.domain_size + (1 if c.sql_nullable else 0)
    return bound


def _generator_capacity(plan: GenerationPlan, table: TablePlan, key: KeyPlan) -> Optional[int]:
    """Distinct combinations the generator can produce for the key, ignoring NULLs (None = unbounded)."""
    if key.nulls_distinct and any(table.columns[c].always_null for c in key.columns):
        return None  # every row has a NULL in the key, and NULLs never collide
    if key.strategy == "identity":
        identity = [table.columns[c] for c in key.columns if table.columns[c].role == "identity"]
        return min(c.spec.max_value for c in identity)  # 1..N
    factors = []
    covered: set[str] = set()
    for f in table.fks:
        group = set(f.fk.columns) & set(key.columns)
        if group:
            factors.append(plan.tables[f.fk.ref_table].rows)
            covered |= group
    for name in key.columns:
        if name not in covered:
            capacity = table.columns[name].provider.capacity
            if capacity is None:
                return None
            factors.append(capacity)
    return prod(factors)


def _key_problems(plan: GenerationPlan, table: TablePlan, key: KeyPlan) -> list[Problem]:
    if key.strategy == "fk_groups" and len(key.groups) == 1:
        return []  # a unique FK: `_fk_problems` covers it (and forced NULLs absorb the excess when allowed)
    n = table.rows
    label = f"{table.name} {'PRIMARY KEY' if key.primary else 'UNIQUE'} ({', '.join(key.columns)})"
    domain = _sql_domain(plan, table, key)
    if domain is not None and n > domain:
        return [_impossible("key_capacity", f"{label}: {n} rows need {n} distinct combinations, but at most {domain} exist")]
    capacity = _generator_capacity(plan, table, key)
    if capacity is not None and n > capacity:
        return [_generator(f"{label}: {n} rows need {n} distinct combinations, but the generator can produce at most {capacity}")]
    return []


def check_capacity(plan: GenerationPlan) -> None:
    """Raise GenerationError listing every capacity problem, `impossible` ones first. Otherwise record on
    `plan.forced_nulls` the rows that must skip an optional FK because there aren't enough parents."""
    problems = []
    for table in plan.tables.values():
        if table.rows == 0:
            continue
        for i, f in enumerate(table.fks):
            found, forced = _fk_problems(plan, table, f)
            problems += found
            if forced:
                plan.forced_nulls[(table.name, i)] = forced
        for key in table.keys:
            if key.strategy != "implied":
                problems += _key_problems(plan, table, key)
    if problems:
        raise GenerationError(sorted(problems, key=lambda p: p.kind != "impossible"))
