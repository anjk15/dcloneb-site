"""Run the plan's backfills in memory, after every table is generated (plan2 G9). No SQL is executed.

For each ledger entry, set the FK's `null_columns` from a parent row whose key agrees with the
row's retained columns, so the full FK tuple equals an existing parent key. Retained columns are
never changed. A successful run leaves no pending entry.
"""

import random
from collections import defaultdict

import polars as pl

from dcloneb.generate.engine import GeneratedData, PendingFill
from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.keys import enforce_unique, pick_distinct, pool_of
from dcloneb.generate.providers import subseed
from dcloneb.generate.strategy import GenerationPlan


def _columns(frame: pl.DataFrame) -> dict[str, list]:
    return {c: frame[c].to_list() for c in frame.columns}


class _Backfill:
    """One plan backfill: fill its pending rows, then recheck every key that contains a filled column."""

    def __init__(self, plan: GenerationPlan, tables: dict[str, dict[str, list]], table: str, i: int,
                 entries: list[PendingFill]):
        self.t, self.f = plan.tables[table], plan.tables[table].fks[i]
        self.values, self.entries = tables[table], entries
        self.pool = pool_of(tables[self.f.fk.ref_table], self.f.fk.ref_columns)
        self.rng = random.Random(subseed(plan.seed, table, "backfill", str(i)))
        b = self.f.backfill
        self.retained = [self.f.fk.columns.index(c) for c in b.retained_columns]
        self.compatible: dict[tuple, list[int]] = defaultdict(list)
        for index, key in enumerate(self.pool):
            self.compatible[tuple(key[k] for k in self.retained)].append(index)

    def options(self, row: int) -> list[int]:
        """Parent rows whose key agrees with this row's retained columns."""
        options = self.compatible.get(tuple(self.values[self.f.fk.columns[k]][row] for k in self.retained), [])
        if not options:
            raise GenerationError([Problem(
                "unsupported", "backfill_unresolved",
                f"{self.t.name} row {row}: no {self.f.fk.ref_table} row matches the retained columns "
                f"{', '.join(self.f.backfill.retained_columns)}")])
        return options

    def set_parent(self, row: int, index: int) -> None:
        key = self.pool[index]
        for child, parent_column in self.f.backfill.fill:  # only null_columns; retained ones never change
            self.values[child][row] = key[self.f.fk.ref_columns.index(parent_column)]

    def fill(self) -> None:
        if not self.f.unique:
            for entry in self.entries:
                self.set_parent(entry.row, self.rng.choice(self.options(entry.row)))
        elif self.f.reserved:  # distinct reserved tuples were chosen at generation time
            for entry in self.entries:
                self.set_parent(entry.row, entry.reserved)
        else:
            for entry, index in zip(self.entries, pick_distinct(len(self.pool), len(self.entries), self.rng)):
                self.set_parent(entry.row, index)
        self.recheck()

    def recheck(self) -> None:
        filled = set(self.f.backfill.null_columns)
        pending = {e.row for e in self.entries}
        for key in self.t.keys:
            if key.strategy == "implied" or not filled & set(key.columns):
                continue
            label = f"{self.t.name} ({', '.join(key.columns)}) after backfill"
            enforce_unique(lambda k=key: list(zip(*(self.values[c] for c in k.columns))),
                           lambda rows, k=key: self.regenerate(k, [r for r in rows if r in pending], rows),
                           key.nulls_distinct, label)

    def regenerate(self, key, backfilled: list[int], rows: list[int]) -> None:
        if not self.f.unique and backfilled:  # another compatible parent for the colliding rows
            for row in backfilled:
                self.set_parent(row, self.rng.choice(self.options(row)))
            return
        for name in key.columns:  # otherwise the key's free columns
            column = self.t.columns[name]
            if column.role in ("free_key", "value"):
                for row, value in zip(rows, column.provider.values(len(rows))):
                    if self.values[name][row] is not None:
                        self.values[name][row] = value


def _unresolved(entry: PendingFill, why: str) -> GenerationError:
    return GenerationError([Problem("unsupported", "backfill_unresolved",
                                    f"pending backfill {entry.table} FK #{entry.fk_index} row {entry.row}: {why}")])


def _check_entry(plan: GenerationPlan, entry: PendingFill) -> None:
    t = plan.tables.get(entry.table)
    if t is None:
        raise _unresolved(entry, "no such table")
    if not 0 <= entry.fk_index < len(t.fks) or t.fks[entry.fk_index].backfill is None:
        raise _unresolved(entry, "that foreign key is not a planned backfill")
    if not 0 <= entry.row < t.rows:
        raise _unresolved(entry, f"the table has {t.rows} rows")


def run_backfills(plan: GenerationPlan, data: GeneratedData) -> GeneratedData:
    """Fill every ledger entry; any entry that can't be resolved is an error, never a partial success."""
    for entry in data.ledger:
        _check_entry(plan, entry)
    tables = {name: _columns(frame) for name, frame in data.frames.items()}
    by_fk: dict[tuple[str, int], list[PendingFill]] = defaultdict(list)
    for entry in data.ledger:
        by_fk[(entry.table, entry.fk_index)].append(entry)
    filled: list[PendingFill] = []
    for (table, i), entries in by_fk.items():
        _Backfill(plan, tables, table, i, entries).fill()
        filled += entries
    frames = {name: pl.DataFrame([pl.Series(c, tables[name][c], dtype=frame[c].dtype, strict=True) for c in frame.columns])
              for name, frame in data.frames.items()}
    return GeneratedData(frames, ledger=[], filled=data.filled + filled, providers=data.providers)
