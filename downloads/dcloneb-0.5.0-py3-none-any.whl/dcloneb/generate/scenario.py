"""scenario.json (plan6 E1-E2): validate the contract, check it against the plan and the approved rules, and
resolve it to exact rows before any value exists.

Row layout per table (deterministic): pinned entities in file order, then background blocks in file order (a group's
parent rows, and its children's rows in the child tables). Tables the scenario doesn't mention are filled with the
usual row counts (`fill`), referencing ordinary parent rows only, unless listed under `empty`; without `fill`, they
get no rows.
Links are parent row indices; ANY means "an ordinary (background) parent row, chosen by the generator".
"""

import hashlib
import json
import re
from collections import Counter
from dataclasses import dataclass, field
from importlib.resources import files
from pathlib import Path
from typing import Optional

import jsonschema

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.plan_input import LoadedPlan
from dcloneb.generate.rules.domain import canonical
from dcloneb.generate.rules.preflight import REPRESENTATION, NormalizedRules, _fit_problem, _represents
from dcloneb.generate.rules.registry import check, equals_value
from dcloneb.generate.strategy import ANY, GenerationPlan, TableScenario, referenced_columns
from dcloneb.generate.types import type_spec
from dcloneb.model import ForeignKey, Table

SCHEMA = json.loads(files("dcloneb.generate").joinpath("scenario.schema.json").read_text(encoding="utf-8"))
_VALIDATOR = jsonschema.Draft202012Validator(SCHEMA)
VIOLABLE = ("range", "allowed_values", "format", "conditional")  # constraints; value_kind is a guide, null_rate a setting
UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")


@dataclass(frozen=True)
class ResolvedScenario:
    raw: dict
    rows: dict  # table -> exact row count
    aliases: dict  # alias -> (table, row index)
    exceptions: dict  # rule id -> {(table, row index)}: declared negative tests
    fixed: dict  # table -> row -> column -> typed value
    picks: dict  # table -> FK index -> per row: parent row index, None (NULL), or ANY
    pinned: dict  # table -> number of pinned rows (they come first)
    source_sha256: Optional[str] = None
    filled: dict = field(default_factory=dict)  # table -> rows: tables the scenario doesn't mention, filled as usual

    @property
    def expected_outcome(self) -> Optional[str]:
        return self.raw.get("expected_outcome")

    def to_json(self) -> str:
        return json.dumps(self.raw, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def _shape(data) -> list[Problem]:
    problems = []
    for e in sorted(_VALIDATOR.iter_errors(data), key=lambda e: list(map(str, e.absolute_path))):
        where = ".".join(map(str, e.absolute_path)) or "scenario.json"
        if list(e.absolute_path) == ["scenario_version"]:
            problems.append(Problem("input", "scenario_unsupported_version",
                                    f"scenario_version {e.instance!r} is not supported; expected 1"))
        else:
            problems.append(Problem("input", "scenario_malformed", f"{where}: {e.message}"))
    return problems


def _keys(plan: LoadedPlan, table: Table) -> set[str]:
    """Columns whose values come from or feed keys and relationships: never fixed by a scenario."""
    return ({c for key in table.keys() for c in key} | {c for fk in table.foreign_keys for c in fk.columns}
            | {c.name for c in table.columns if c.identity} | referenced_columns(plan.schema, table))


def _typed(table: Table, name: str, value, rules: Optional[NormalizedRules]):
    """(typed value, None) or (None, why it can't be stored). Written like rules.json values; null is NULL."""
    column = table.column(name)
    spec = type_spec(column)
    if value is None:
        return (None, None) if column.nullable else (None, f"{table.name}.{name} is NOT NULL")
    if spec.kind == "float":
        ok = isinstance(value, (int, float)) and not isinstance(value, bool)
        return (float(value), None) if ok else (None, f"{spec.sql} columns take JSON numbers")
    if spec.kind == "uuid":
        ok = isinstance(value, str) and UUID.fullmatch(value)
        return (value, None) if ok else (None, f"{spec.sql} columns take lowercase hyphenated UUID strings")
    if not _represents(spec.kind, value):
        return None, f"{spec.sql} columns take {REPRESENTATION[spec.kind]}"
    why = _fit_problem(spec, column, value) if spec.kind not in ("date", "timestamp") else None
    if why:
        return None, f"doesn't fit: {why}"
    d = rules.domains.get((table.name, name)) if rules else None
    try:
        return canonical(spec.kind, d.scale if d and d.scale is not None else spec.scale, value), None
    except (ArithmeticError, ValueError):
        return None, f"doesn't fit {spec.sql}"


def _fk_for(child: Table, parent: str, columns, what: str) -> tuple[Optional[int], Optional[Problem]]:
    """The child's FK to `parent` (named by its columns when there is more than one)."""
    found = [i for i, fk in enumerate(child.foreign_keys)
             if fk.ref_table == parent and (columns is None or tuple(columns) == fk.columns)]
    if len(found) == 1:
        return found[0], None
    options = [f"({', '.join(fk.columns)})" for fk in child.foreign_keys if fk.ref_table == parent]
    why = (f"{child.name} has no foreign key{' (' + ', '.join(columns) + ')' if columns else ''} to {parent}"
           + (f"; its foreign keys to {parent}: {', '.join(options)}" if options else "")
           if not found else f"{child.name} has several foreign keys to {parent}; name one with columns: {', '.join(options)}")
    return None, Problem("input", "scenario_link_invalid", f"{what}: {why}")


def _fixed_values(plan: LoadedPlan, rules: Optional[NormalizedRules], table: Table, values: dict, where: str,
                  problems: list) -> tuple[dict, bool]:
    """(typed fixed values, whether every value fits the schema), adding a problem for each value that can't be fixed."""
    fixed, valid, keys = {}, True, _keys(plan, table)
    for column, value in values.items():
        if table.column(column) is None:
            problems.append(Problem("input", "scenario_unknown_column",
                                    f"{where}: {table.name} has no column {column!r}; its columns: "
                                    f"{', '.join(c.name for c in table.columns)}"))
        elif column in keys:
            problems.append(Problem("input", "scenario_fixed_key",
                                    f"{where}: {table.name}.{column} is a key or relationship column; the generator sets "
                                    "keys, and links set foreign keys"))
        else:
            typed, why = _typed(table, column, value, rules)
            if why:
                problems.append(Problem("input", "scenario_value_invalid",
                                        f"{where}: {column} = {value!r}: {why}; a scenario never breaks the schema, "
                                        "only approved business rules"))
                valid = False
            else:
                fixed[column] = typed
    return fixed, valid


def _breaks(rule, row: dict) -> bool:
    """Do a pinned row's fixed values alone break the rule? (Values the generator fills always follow the rules.)"""
    if rule.type == "conditional":
        if rule.when_column not in row or rule.column not in row or row[rule.when_column] is None:
            return False
        if not equals_value(rule.when_equals, row[rule.when_column]):
            return False
        return row[rule.column] is None or not check(rule, row[rule.column])
    if rule.type == "null_rate" or rule.column not in row:
        return False
    value = row[rule.column]
    return rule.null_policy == "forbid" if value is None else not check(rule, value)


def _fk_label(table: Table, fk: ForeignKey) -> str:
    return f"{table.name} ({', '.join(fk.columns)}) -> {fk.ref_table}"


def _unsupported(plan: LoadedPlan, table: Table) -> Optional[str]:
    """Why rows of `table` can't be placed by a scenario, or None."""
    backfilled = {(b.table, b.fk) for b in plan.backfills}
    if any((table.name, fk) in backfilled for fk in table.foreign_keys):
        return f"{table.name} has a foreign key filled after loading (a cycle); scenarios don't support cycles yet"
    fk_columns = {c for fk in table.foreign_keys for c in fk.columns}
    if any(len([fk for fk in table.foreign_keys if set(fk.columns) & set(key)]) > 1
           or (set(key) & fk_columns and not any(set(fk.columns) == set(key) for fk in table.foreign_keys))
           for key in table.keys()):
        return f"{table.name} has a key made of foreign key and other columns; scenarios don't support such tables yet"
    return None


def preflight_scenario(plan: LoadedPlan, rules: Optional[NormalizedRules], data, source_sha256: Optional[str] = None,
                       fill: Optional[dict] = None) -> ResolvedScenario:
    """Check `data` (a parsed scenario.json) against the plan and the normalized rules, and resolve it to rows.
    `fill` (table -> the usual row count) fills the tables the scenario doesn't mention. Raises GenerationError with
    every problem found."""
    problems = _shape(data)
    if problems:
        raise GenerationError(problems)
    schema = plan.schema
    tables = {t.name: t for t in schema.tables}
    listed = ", ".join(sorted(tables))
    by_id = {r.id: r for r in rules.rules} if rules else {}

    # entities: aliases, tables, fixed values
    entities: dict[str, tuple[str, dict]] = {}  # alias -> (table, typed fixed values)
    skip_rules: set[str] = set()  # entities with a value the schema rejects: their rules aren't checked
    for i, entity in enumerate(data["entities"]):
        alias, name = entity["alias"], entity["table"]
        where = f"entities[{i}] ({alias})"
        if alias in entities:
            problems.append(Problem("input", "scenario_duplicate_alias", f"{where}: alias {alias!r} is already used"))
            continue
        table = tables.get(name)
        if table is None:
            problems.append(Problem("input", "scenario_unknown_table", f"{where}: table {name!r} is not in the plan; "
                                                                       f"plan tables: {listed}"))
            continue
        fixed, valid = _fixed_values(plan, rules, table, entity.get("values", {}), where, problems)
        if not valid:
            skip_rules.add(alias)
        entities[alias] = (name, fixed)

    # row layout: pinned entities first, then background blocks
    rows = {name: 0 for name in tables}
    aliases = {}
    for alias, (name, _) in entities.items():
        aliases[alias] = (name, rows[name])
        rows[name] += 1
    pinned = dict(rows)
    picks = {name: {i: [] for i in range(len(t.foreign_keys))} for name, t in tables.items()}

    # links between entities
    linked: dict[tuple[str, int], int] = {}  # (child alias, FK index) -> parent row
    for i, link in enumerate(data.get("links", [])):
        where = f"links[{i}] ({link['from']} -> {link['to']})"
        missing = [a for a in (link["from"], link["to"]) if a not in entities]
        if missing:
            problems += [Problem("input", "scenario_unknown_alias", f"{where}: no entity has alias {a!r}") for a in missing]
            continue
        (child, _), (parent, _) = entities[link["from"]], entities[link["to"]]
        index, problem = _fk_for(tables[child], parent, link.get("columns"), where)
        if problem is None and (link["from"], index) in linked:
            problem = Problem("input", "scenario_link_invalid", f"{where}: {link['from']} is already linked through "
                                                                f"{_fk_label(tables[child], tables[child].foreign_keys[index])}")
        if problem:
            problems.append(problem)
        else:
            linked[(link["from"], index)] = aliases[link["to"]][1]
    for alias, (name, _) in entities.items():
        table = tables[name]
        for index, fk in enumerate(table.foreign_keys):
            if (alias, index) in linked:
                picks[name][index].append(linked[(alias, index)])
            elif fk.can_be_null(table):
                picks[name][index].append(None)
            else:
                problems.append(Problem("input", "scenario_link_missing",
                                        f"entity {alias}: {_fk_label(table, fk)} is required; add a link to a {fk.ref_table} "
                                        "entity"))
                picks[name][index].append(None)

    # background groups: parent rows, and exactly per_parent children attached to their own parents
    ordinary_fixed: list[tuple[str, range, dict]] = []  # (table, rows, fixed values) of background groups
    for i, group in enumerate(data.get("background", [])):
        name = group["table"]
        if name not in tables:
            problems.append(Problem("input", "scenario_unknown_table", f"background[{i}]: table {name!r} is not in the "
                                                                       f"plan; plan tables: {listed}"))
            continue
        start, count = rows[name], group["count"]
        rows[name] += count
        values, valid = _fixed_values(plan, rules, tables[name], group.get("values", {}), f"background[{i}]", problems)
        if values:
            ordinary_fixed.append((name, range(start, start + count), values))
        if valid:
            # ordinary rows follow every approved rule: only a named entity can be a negative test
            for rule_id in sorted(r.id for r in by_id.values() if r.table == name and _breaks(r, values)):
                problems.append(Problem("input", "scenario_rule_conflict",
                                        f"background[{i}]: its fixed values break approved rule {rule_id!r}; background "
                                        "rows always follow the rules, so change the value (only a named entity can be "
                                        "a negative test)", (rule_id,)))
            for r in sorted((r for r in by_id.values() if r.table == name and (r.type == "null_rate" or getattr(
                    r, "weights", None)) and r.column in values), key=lambda r: r.id):
                problems.append(Problem("input", "scenario_value_conflicts_setting",
                                        f"background[{i}]: {name}.{r.column} is fixed, but rule {r.id!r} sets its "
                                        "distribution over the same rows; remove the fixed value or the distribution",
                                        (r.id,)))
        for index in picks[name]:
            picks[name][index] += [ANY] * count
        for j, child in enumerate(group.get("children", [])):
            where = f"background[{i}].children[{j}]"
            if child["table"] not in tables:
                problems.append(Problem("input", "scenario_unknown_table", f"{where}: table {child['table']!r} is not in "
                                                                           f"the plan; plan tables: {listed}"))
                continue
            index, problem = _fk_for(tables[child["table"]], name, child.get("columns"), where)
            if problem:
                problems.append(problem)
                continue
            n = count * child["per_parent"]
            rows[child["table"]] += n
            for other in picks[child["table"]]:
                picks[child["table"]][other] += ([start + r // child["per_parent"] for r in range(n)] if other == index
                                                 else [ANY] * n)

    # tables the scenario doesn't mention: the usual counts, ordinary rows only (parents first), unless left empty
    mentioned = ({t for t, _ in entities.values()} | {g["table"] for g in data.get("background", [])}
                 | {c["table"] for g in data.get("background", []) for c in g.get("children", [])})
    for name in data.get("empty", []):
        if name not in tables:
            problems.append(Problem("input", "scenario_unknown_table", f"empty: table {name!r} is not in the plan; "
                                                                       f"plan tables: {listed}"))
        elif name in mentioned:
            problems.append(Problem("input", "scenario_empty_conflict", f"empty: {name} has rows in the scenario; "
                                                                        "remove it from empty or from the scenario"))
    filled: dict[str, int] = {}
    for name in plan.order if fill else ():
        table = tables[name]
        if name in mentioned or name in data.get("empty", []) or _unsupported(plan, table):
            continue
        count = fill.get(name, 0)
        for fk in table.foreign_keys:
            if table.is_unique(fk.columns) and not fk.can_be_null(table):
                count = min(count, rows[fk.ref_table] - pinned[fk.ref_table])  # one row per ordinary parent at most
        if count > 0:
            rows[name] += count
            filled[name] = count
            for index in picks[name]:
                picks[name][index] += [ANY] * count

    # background rows' other foreign keys need ordinary parents; unique foreign keys need enough of them
    for name, table in tables.items():
        for index, fk in enumerate(table.foreign_keys):
            column = picks[name][index]
            if len(column) != rows[name]:
                continue  # an earlier problem left this table incomplete
            anys = column.count(ANY)
            ordinary = rows[fk.ref_table] - pinned[fk.ref_table]
            if anys and not ordinary and not fk.can_be_null(table) and name in filled:
                problems.append(Problem("input", "scenario_link_missing",
                                        f"{name} is not in the scenario, so it gets its usual {filled[name]} rows, but "
                                        f"they need ordinary {fk.ref_table} rows for {_fk_label(table, fk)}; add "
                                        f"{fk.ref_table} to a background group, or list {name} under empty"))
            elif anys and not ordinary and not fk.can_be_null(table):
                problems.append(Problem("input", "scenario_link_missing",
                                        f"background rows of {name} need an ordinary {fk.ref_table} row for "
                                        f"{_fk_label(table, fk)}; add {fk.ref_table} to a background group"))
            if table.is_unique(fk.columns):
                explicit = Counter(p for p in column if p not in (None, ANY))
                free = ordinary - sum(1 for p in explicit if p >= pinned[fk.ref_table])
                if any(n > 1 for n in explicit.values()) or (anys > free and not fk.can_be_null(table)):
                    problems.append(Problem("impossible", "scenario_unique_capacity",
                                            f"{_fk_label(table, fk)} is unique, so each {fk.ref_table} row can have at "
                                            f"most one {name} row; the scenario asks for more"))

    # declared negative tests, and fixed values that break approved rules
    declared: dict[str, set[str]] = {}  # alias -> rule ids named (valid or not)
    exceptions: dict[str, set] = {}
    for i, violation in enumerate(data.get("violations", [])):
        alias, rule_id = violation["alias"], violation["rule"]
        where = f"violations[{i}] ({alias}, {rule_id})"
        if alias not in entities:
            problems.append(Problem("input", "scenario_unknown_alias", f"{where}: no entity has alias {alias!r}"))
            continue
        rule = by_id.get(rule_id)
        if rule is None:
            known = ", ".join(sorted(by_id)) or "none"
            problems.append(Problem("input", "scenario_violation_invalid",
                                    f"{where}: no approved rule has id {rule_id!r}; approved rules: {known}", (rule_id,)))
            continue
        declared.setdefault(alias, set()).add(rule_id)
        if rule.origin != "business" or rule.type not in VIOLABLE:
            what = (f"an {rule.origin} rule (measured, not a business rule)" if rule.origin != "business"
                    else f"a {rule.type} rule (a generation guide or setting, not a constraint)")
            problems.append(Problem("input", "scenario_violation_invalid",
                                    f"{where}: {rule_id!r} is {what}; only approved business rules may be violated",
                                    (rule_id,)))
        elif rule.table != entities[alias][0]:
            problems.append(Problem("input", "scenario_violation_invalid",
                                    f"{where}: {rule_id!r} is on {rule.table}, but {alias} is a {entities[alias][0]} row",
                                    (rule_id,)))
        else:
            exceptions.setdefault(rule_id, set()).add(aliases[alias])
    for alias, (name, fixed) in entities.items():
        if alias in skip_rules:
            continue
        broken = {r.id for r in by_id.values() if r.table == name and _breaks(r, fixed)}
        for rule_id in sorted(broken - declared.get(alias, set())):
            problems.append(Problem("input", "scenario_rule_conflict",
                                    f"entity {alias}: its fixed values break approved rule {rule_id!r}. If this row is a "
                                    "negative test, declare it under violations; otherwise change the value",
                                    (rule_id,)))
        for rule_id in sorted({r for r in declared.get(alias, set()) if aliases[alias] in exceptions.get(r, set())} - broken):
            problems.append(Problem("input", "scenario_exception_unused",
                                    f"entity {alias}: declared as violating {rule_id!r}, but its fixed values don't break "
                                    "it; fix the values that break the rule", (rule_id,)))

    # shapes the generator can't pin rows into
    for name, table in tables.items():
        why = _unsupported(plan, table) if rows[name] else None
        if why:
            problems.append(Problem("unsupported", "scenario_unsupported", why))
    if problems:
        raise GenerationError(problems)
    fixed = {name: {} for name in tables}
    for alias, (name, values) in entities.items():
        fixed[name][aliases[alias][1]] = values
    for name, block, values in ordinary_fixed:
        for r in block:
            fixed[name][r] = dict(values)
    return ResolvedScenario(data, rows, aliases, exceptions, fixed, picks, pinned, source_sha256, filled)


def scenario_hook(resolved: ResolvedScenario):
    def pin_scenario_rows(plan: GenerationPlan) -> GenerationPlan:
        for name, t in plan.tables.items():
            t.scenario = TableScenario(resolved.pinned[name], resolved.fixed[name], resolved.picks[name])
        return plan

    return pin_scenario_rows


def load_scenario(path: Path) -> tuple[dict, str]:
    """(parsed scenario.json, sha256 of its bytes)."""
    try:
        raw = Path(path).read_bytes()
    except OSError as e:
        raise GenerationError([Problem("input", "scenario_unreadable", f"cannot read scenario {path}: {e.strerror or e}")]) from None
    try:
        return json.loads(raw.decode("utf-8")), hashlib.sha256(raw).hexdigest()
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise GenerationError([Problem("input", "scenario_invalid_json", f"scenario {path} is not valid JSON: {e}")]) from None
