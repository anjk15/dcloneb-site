"""Value providers (plan2 G4.2-G4.4): non-NULL values within a column's SQL type.

Providers know nothing about keys or relationships; `keys.py` decides which provider method to use.
Each provider owns one seeded RNG stream, so the same seed always gives the same values.
"""

import datetime as dt
import hashlib
import json
import random
import re
import string
import uuid
from decimal import Decimal
from fractions import Fraction
from typing import Optional

import polars as pl

from dcloneb.generate.errors import MAY_STILL_EXIST, GenerationError, Problem
from dcloneb.generate.types import EXACT, TypeSpec

def allocate(weights, n: int) -> list[int]:
    """Exact counts for `n` rows in proportion to `weights` (largest remainder; ties go to the earlier weight), so each
    count is within one row of its exact share (plan6 D3)."""
    shares = [Fraction(str(w)) for w in weights]
    total = sum(shares)
    exact = [s * n / total for s in shares]
    counts = [int(e) for e in exact]
    for i in sorted(range(len(exact)), key=lambda i: (-(exact[i] - counts[i]), i))[:n - sum(counts)]:
        counts[i] += 1
    return counts


# Conservative value ranges (plan2 Decisions); overridable from config later.
TEXT_MAX_LENGTH = 64
DATE_MIN = dt.date(2000, 1, 1)
DATE_MAX = dt.date(2030, 12, 31)
ALPHABET = string.ascii_lowercase + string.digits  # generic text: never spaces, so CHAR padding can't collide

_DAYS = (DATE_MAX - DATE_MIN).days + 1
_SECONDS = _DAYS * 86_400
_EPOCH = dt.datetime.combine(DATE_MIN, dt.time())


def subseed(seed: int, *parts: str) -> int:
    """A seed for one RNG stream, e.g. subseed(42, table, column, "values"). sha256, never `hash()`
    (randomized per process), so streams are stable across runs and independent of each other."""
    digest = hashlib.sha256(json.dumps([seed, *parts]).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def _base36(i: int) -> str:
    digits = ""
    while True:
        i, r = divmod(i, 36)
        digits = ALPHABET[(r + 26) % 36] + digits  # 0-9 then a-z
        if i == 0:
            return digits


def generator_capacity(label: str, requested: int, capacity: int, what: str) -> GenerationError:
    return GenerationError([Problem(
        "unsupported", "generator_capacity",
        f"{label}: {requested} distinct values requested, but the generator can produce at most {capacity} for {what}; "
        f"{MAY_STILL_EXIST}")])


class GenericProvider:
    """Type-appropriate synthetic values with no inferred meaning."""

    name = "generic"

    def __init__(self, spec: TypeSpec, seed: int, label: str = "column"):
        self.spec, self.label = spec, label
        self.rng = random.Random(seed)
        self.prefix = "".join(ch for ch in label.split(".")[-1].lower() if ch in ALPHABET or ch == "_")

    @property
    def text_length(self) -> int:
        s = self.spec
        return s.max_length if s.fixed_length else min(s.max_length or TEXT_MAX_LENGTH, TEXT_MAX_LENGTH)

    @property
    def capacity(self) -> Optional[int]:
        """Distinct values `unique()` can produce (None = unbounded)."""
        s = self.spec
        return {
            "int": s.domain_size,
            "decimal": 2 * 10 ** (s.precision or 0) - 1,
            "float": 2 ** 24 if s.dtype == pl.Float32 else 2 ** 53,  # integers a float holds exactly
            "bool": 2,
            "text": 36 ** self.text_length if self.text_length else None,
            "date": _DAYS,
            "timestamp": _SECONDS,
            "uuid": None,
        }[s.kind]

    # --- random values (duplicates allowed) ---------------------------------------------------------

    def values(self, n: int) -> list:
        return [self._one() for _ in range(n)]

    def _one(self):
        s, rng = self.spec, self.rng
        if s.kind == "int":
            return rng.randint(s.min_value, s.max_value)
        if s.kind == "decimal":
            bound = 10 ** s.precision - 1
            return Decimal(rng.randint(-bound, bound)).scaleb(-s.scale, context=EXACT)
        if s.kind == "float":
            return rng.randint(s.min_value * 100, s.max_value * 100) / 100
        if s.kind == "bool":
            return rng.random() < 0.5
        if s.kind == "text":
            length = self.text_length if s.fixed_length else rng.randint(1, self.text_length)
            return "".join(rng.choice(ALPHABET) for _ in range(length))
        if s.kind == "date":
            return DATE_MIN + dt.timedelta(days=rng.randrange(_DAYS))
        if s.kind == "timestamp":
            return _EPOCH + dt.timedelta(seconds=rng.randrange(_SECONDS))
        if s.kind == "uuid":
            return str(uuid.UUID(int=rng.getrandbits(128), version=4))
        raise ValueError(s.kind)

    # --- distinct values (by construction where possible) --------------------------------------------

    def unique(self, n: int) -> list:
        capacity = self.capacity
        if capacity is not None and n > capacity:
            raise generator_capacity(self.label, n, capacity, self.spec.sql)
        s = self.spec
        if s.kind == "int":  # 1, 2, ... then 0, -1, ...
            return [i if i <= s.max_value else s.max_value + 1 - i for i in range(1, n + 1)]
        if s.kind == "decimal":
            bound = 10 ** s.precision - 1
            return [Decimal(i if i <= bound else bound + 1 - i).scaleb(-s.scale, context=EXACT) for i in range(1, n + 1)]
        if s.kind == "float":
            return [float(i) for i in range(1, n + 1)]
        if s.kind == "bool":
            return [False, True][:n]
        if s.kind == "text":
            return self._unique_text(n)
        if s.kind == "date":
            step = max(1, _DAYS // max(n, 1))
            return [DATE_MIN + dt.timedelta(days=i * step) for i in range(n)]
        if s.kind == "timestamp":
            step = max(1, _SECONDS // max(n, 1))
            return [_EPOCH + dt.timedelta(seconds=i * step) for i in range(n)]
        if s.kind == "uuid":
            seen: dict[str, None] = {}
            while len(seen) < n:  # 122 random bits: a repeat is astronomically unlikely, but never assumed away
                seen.setdefault(self._one())
            return list(seen)
        raise ValueError(s.kind)

    def _unique_text(self, n: int) -> list[str]:
        length = self.text_length
        if self.spec.fixed_length:
            return [_base36(i).rjust(length, "0") for i in range(n)]
        widest = len(_base36(max(n - 1, 0)))
        if self.prefix and len(self.prefix) + 1 + widest <= length:
            return [f"{self.prefix}_{_base36(i)}" for i in range(n)]
        return [_base36(i) for i in range(n)]


# --- Faker hints (plan2 G4.3): a small fixed table; no LLM, no user mappings in this phase ---------------

MAX_ROUNDS = 20  # bounded retries for collisions
FAKER_ATTEMPTS = 5  # tries per value to find one that fits the declared length

# column name (exact, or the suffix after "_") -> Faker method. Longest match wins, so
# "billing_first_name" is first_name, not name.
HINTS = {
    "email": "email", "email_address": "email",
    "first_name": "first_name", "firstname": "first_name", "given_name": "first_name",
    "last_name": "last_name", "lastname": "last_name", "surname": "last_name", "family_name": "last_name",
    "full_name": "name",
    "phone": "phone_number", "phone_number": "phone_number",
    "street": "street_address", "street_address": "street_address", "address": "street_address",
    "city": "city", "state": "state", "country": "country",
    "zip": "postcode", "zip_code": "postcode", "postal_code": "postcode", "postcode": "postcode",
    "company": "company", "company_name": "company", "job_title": "job",
    "url": "url", "website": "url", "username": "user_name", "user_name": "user_name",
    "ip_address": "ipv4", "currency_code": "currency_code", "description": "sentence",
}


DATE_WORDS = {"date", "datetime", "timestamp", "dob", "birthday"}  # a word of the name: order_date, OrderDate
DATE_ENDINGS = {"at", "on", "ts"}  # the last word: created_at, updated_on, load_ts


def date_name(column_name: str) -> bool:
    """Whether a column's name says it holds a date (for a text column: a date stored as text)."""
    words = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", column_name).lower().split("_")
    return bool(DATE_WORDS & set(words)) or (len(words) > 1 and words[-1] in DATE_ENDINGS)


def hint_for(column_name: str) -> Optional[str]:
    name = column_name.lower()
    for key in sorted(HINTS, key=len, reverse=True):
        if name == key or name.endswith("_" + key):
            return HINTS[key]
    return None


class FakerProvider:
    """Recognizable values for a recognized column name. The declared type and length always win:
    a value that doesn't fit is retried, then truncated (non-unique) or replaced by a generic value."""

    def __init__(self, spec: TypeSpec, seed: int, locale: str, method: str, label: str = "column"):
        from faker import Faker  # imported here so the rest of the generator doesn't pay for it

        self.spec, self.label, self.method = spec, label, method
        self.name = f"faker.{method}"
        self.fake = Faker(locale)
        self.fake.seed_instance(seed)
        self.fallback = GenericProvider(spec, seed + 1, label)
        self.limit = self.fallback.text_length

    @property
    def capacity(self) -> Optional[int]:
        return self.fallback.capacity  # unique() can always fall back to generic values

    def _fitting(self) -> Optional[str]:
        for _ in range(FAKER_ATTEMPTS):
            value = str(getattr(self.fake, self.method)())
            if 1 <= len(value) <= self.limit:
                return value
        return None

    def values(self, n: int) -> list[str]:
        out = []
        for _ in range(n):
            value = self._fitting()
            if value is None:
                value = str(getattr(self.fake, self.method)())[: self.limit].rstrip(" ") or self.fallback.values(1)[0]
            out.append(value)
        return out

    def unique(self, n: int) -> list[str]:
        if self.capacity is not None and n > self.capacity:
            raise generator_capacity(self.label, n, self.capacity, self.spec.sql)
        seen: dict[str, None] = {}
        for _ in range(MAX_ROUNDS):
            missing = n - len(seen)
            if missing == 0:
                break
            for _ in range(missing):
                value = self._fitting()
                if value is not None:
                    seen.setdefault(value)
        if len(seen) < n:  # Faker ran dry: fill with generic distinct values that don't collide
            candidates = self.fallback.unique(min(self.capacity or 2 * n, 2 * n))
            seen.update(dict.fromkeys(v for v in candidates if v not in seen))
            if len(seen) < n:
                raise generator_capacity(self.label, n, len(seen), self.spec.sql)
        return list(seen)[:n]


# --- table-aware defaults (plan5 K5): a generic column is read from its table or prefix ----------------

GENERIC_COLUMNS = {"name", "title", "label", "display_name"}
NOUN_KINDS = {
    **dict.fromkeys(("product", "item", "sku", "good", "merchandise"), "product_name"),
    **dict.fromkeys(("category",), "category_name"),
    **dict.fromkeys(("company", "supplier", "vendor", "organization", "organisation", "brand", "manufacturer",
                     "publisher"), "company_name"),
    **dict.fromkeys(("customer", "user", "person", "people", "employee", "staff", "member", "author", "contact",
                     "patient", "student", "teacher", "client", "owner", "manager"), "person_name"),
    "city": "city", "country": "country", "state": "state",
}


def singular(word: str) -> str:
    word = word.lower()
    if word.endswith("ies") and len(word) > 4:
        return word[:-3] + "y"
    if word.endswith(("ses", "xes", "ches", "shes")):
        return word[:-2]
    if word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


def generic_noun(table: str, column: str) -> Optional[str]:
    """What a generic text column names: its table for `name`/`title`/`label`, its prefix for `x_name`/`x_title`."""
    name = column.lower()
    if name in GENERIC_COLUMNS and table:
        return singular(table.split(".")[-1])
    for suffix in ("_name", "_title"):
        if name.endswith(suffix) and len(name) > len(suffix):
            return singular(name[: -len(suffix)])
    return None


class LabelProvider:
    """Neutral, honest labels for a noun dcloneb doesn't know: "Order 12", "Store 7". Never a wrong guess
    (like a person's name for a product). Falls back to generic text when even that doesn't fit."""

    def __init__(self, noun: str, spec: TypeSpec, seed: int, label: str = "column"):
        self.name = f"label.{noun}"
        self.word = noun.replace("_", " ").title()
        self.rng = random.Random(seed)
        self.fallback = GenericProvider(spec, seed, label)
        self.limit = self.fallback.text_length

    @property
    def capacity(self) -> Optional[int]:
        return self.fallback.capacity

    def values(self, n: int) -> list:
        if len(f"{self.word} 9999") > self.limit:
            return self.fallback.values(n)
        return [f"{self.word} {self.rng.randint(1, 9999)}" for _ in range(n)]

    def unique(self, n: int) -> list:
        if len(f"{self.word} {n}") > self.limit:
            return self.fallback.unique(n)
        return [f"{self.word} {i}" for i in range(1, n + 1)]


def provider_for(column, spec: TypeSpec, seed: int, locale: str, label: str, table: str = ""):
    """The provider for a column without rules: a Faker hint for a specific name (`email`, `first_name`, ...),
    else dates (YYYY-MM-DD) for a name that says date (`order_date`, `created_at`), else a kind or neutral label for a generic one (`name`, `title`, `x_name`) read from its table or prefix,
    else generic values. CHAR(n) and non-text columns always get generic values."""
    if spec.kind != "text" or spec.fixed_length:
        return GenericProvider(spec, seed, label)
    method = hint_for(column.name)
    if method is not None:
        return FakerProvider(spec, seed, locale, method, label)
    from dcloneb.generate.kinds import KindProvider  # kinds imports this module

    if date_name(column.name):
        return KindProvider("date", spec.max_length, seed, locale, label)
    noun = generic_noun(table, column.name)
    if noun is None:
        return GenericProvider(spec, seed, label)

    kind = NOUN_KINDS.get(noun)
    if kind == "person_name" and column.name.lower() in ("title", "job_title"):
        kind = "job_title"  # an employee's title is their job
    if kind is not None:
        return KindProvider(kind, spec.max_length, seed, locale, label)
    return LabelProvider(noun, spec, seed, label)
