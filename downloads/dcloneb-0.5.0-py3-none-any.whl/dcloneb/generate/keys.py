"""Key and relationship assignment (plan2 G7): row-level building blocks used by the engine.

Parents are referenced by **row index** into a pool of complete key tuples, so the components of a
composite FK always come from the same parent row. Values are plain Python lists (None = NULL); the
engine turns them into Polars frames.
"""

import random
from math import prod
from typing import Callable, Optional, Sequence

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.providers import MAX_ROUNDS


def pool_of(data: dict[str, list], columns: Sequence[str]) -> list[tuple]:
    """Complete key tuples, one per parent row, in row order. Rows with a NULL component are skipped:
    they can't be referenced."""
    return [t for t in zip(*(data[c] for c in columns)) if None not in t]


def pick_with_replacement(m: int, n: int, rng: random.Random) -> list[int]:
    """Many-to-one: n row indices into a pool of m, parents may repeat."""
    return [rng.randrange(m) for _ in range(n)]


def pick_distinct(m: int, n: int, rng: random.Random) -> list[int]:
    """Unique FK: n distinct row indices (n <= m, checked by capacity). `random.sample` over a range
    doesn't materialize it, so huge pools are fine."""
    return rng.sample(range(m), n)


def pick_distinct_product(sizes: Sequence[int], n: int, rng: random.Random) -> list[tuple[int, ...]]:
    """Junction: n distinct combinations of row indices, one per pool. Sampled without replacement from
    the product space, so it never needs retries (n <= prod(sizes), checked by capacity)."""
    combos = []
    for flat in rng.sample(range(prod(sizes)), n):
        combo = []
        for size in reversed(sizes):
            flat, index = divmod(flat, size)
            combo.append(index)
        combos.append(tuple(reversed(combo)))
    return combos


def skip_columns(fk_plan, columns: dict) -> tuple[str, ...]:
    """The columns set NULL when a row skips the FK. MATCH FULL: all of them (partial NULLs are a
    violation). MATCH SIMPLE: every column the generator may null; one NULL is enough to skip."""
    fk = fk_plan.fk
    if fk.match == "full":
        return tuple(fk.columns)
    return tuple(c for c in fk.columns if columns[c].nullable)


def fk_values(columns: Sequence[str], pool: list[tuple], picks: Sequence[Optional[int]], null_columns: Sequence[str],
              rng: random.Random, fallback: Optional[dict[str, Callable[[], object]]] = None) -> dict[str, list]:
    """FK column values per row. picks[i] is a pool index, or None for a row that skips the FK: then
    `null_columns` are NULL and any other FK column takes its value from a random pool tuple, or from
    `fallback` when the pool is empty (the FK is skipped, so those values are unconstrained by it)."""
    out: dict[str, list] = {c: [] for c in columns}
    for pick in picks:
        if pick is not None:
            for c, v in zip(columns, pool[pick]):
                out[c].append(v)
            continue
        filler = pool[rng.randrange(len(pool))] if pool else None
        for i, c in enumerate(columns):
            if c in null_columns:
                out[c].append(None)
            else:
                out[c].append(filler[i] if filler is not None else fallback[c]())
    return out


def duplicate_rows(rows: Sequence[tuple], nulls_distinct: bool) -> list[int]:
    """Indices of rows whose key repeats an earlier row. With nulls distinct (the SQL default), a row
    with any NULL in the key never collides; with NULLS NOT DISTINCT, NULL compares like a value."""
    seen, duplicates = set(), []
    for i, key in enumerate(rows):
        if nulls_distinct and None in key:
            continue
        if key in seen:
            duplicates.append(i)
        else:
            seen.add(key)
    return duplicates


def enforce_unique(read: Callable[[], list[tuple]], regenerate: Callable[[list[int]], None], nulls_distinct: bool,
                   label: str, rounds: int = MAX_ROUNDS) -> None:
    """Make the whole key combination unique (never each component): regenerate only the colliding
    rows, at most `rounds` times. Exhaustion is reported as such, never as impossibility."""
    for _ in range(rounds):
        duplicates = duplicate_rows(read(), nulls_distinct)
        if not duplicates:
            return
        regenerate(duplicates)
    duplicates = duplicate_rows(read(), nulls_distinct)
    if duplicates:
        raise GenerationError([Problem(
            "retry_exhausted", "unique_retry_exhausted",
            f"{label}: {len(duplicates)} row(s) still collide after {rounds} rounds of regeneration; "
            "this is not proof that no valid dataset exists (try another seed or fewer rows)")])
