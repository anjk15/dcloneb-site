"""CSV export and the output bundle (plan2 G11).

The bundle is written to a staging directory, re-read and validated there, and only then renamed to
the output path. A failed run leaves nothing presented as a successful bundle.
"""

import hashlib
import json
import os
import platform
import re
import secrets
import shutil
from pathlib import Path
from importlib.metadata import version
from typing import Callable, Optional

import polars as pl

from dcloneb import __version__
from dcloneb.generate.config import GenerationConfig
from dcloneb.generate.engine import GeneratedData
from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.plan_input import LoadedPlan
from dcloneb.generate.rules.registry import ENGINE_VERSION
from dcloneb.generate.strategy import GenerationPlan
from dcloneb.generate.types import type_spec
from dcloneb.generate.validate import Report, validate

NOT_EVALUATED = ["triggers", "functions and procedures", "views", "row-level security policies",
                 "anything outside the declared PK/UNIQUE/FK/NOT NULL/type constraints"]

SAFE_NAME = re.compile(r"^[a-z0-9][a-z0-9_.-]*$")
RESERVED = {"manifest", "validation_report", "plan"}
CSV_DIR = "csv"  # only the table CSVs live here, so the folder can be zipped and shared as is
MAX_STEM = 100


def _hashed(name: str) -> str:
    stem = re.sub(r"[^a-z0-9_.-]+", "_", name.lower()).strip("._-")[:MAX_STEM] or "table"
    return f"{stem}-{hashlib.sha256(name.encode('utf-8')).hexdigest()[:10]}"


def file_names(tables) -> dict[str, str]:
    """Exact table name -> CSV file name. A name already safe on every filesystem keeps its name; any
    other gets a sanitized stem plus a hash of the exact name. Unique even case-insensitively."""
    plain = {t: t for t in tables if SAFE_NAME.match(t) and t not in RESERVED and len(t) <= MAX_STEM}
    folded = [t.lower() for t in plain]
    stems = {t: (t if t in plain and folded.count(t.lower()) == 1 else _hashed(t)) for t in sorted(tables)}
    return {t: f"{stem}.csv" for t, stem in stems.items()}


# Postgres `COPY ... WITH (FORMAT csv, HEADER true)` conventions (plan2 spike G0.1).
TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"
CSV_FORMAT = {
    "encoding": "utf-8 (no BOM)", "delimiter": ",", "quote": '"', "escape": '"" inside a quoted field',
    "header": True, "line_terminator": "\\n", "null": "unquoted empty field", "empty_string": '""',
    "integer": "plain digits", "decimal": "plain notation with exactly the column's scale, never an exponent",
    "boolean": "true/false", "date": "YYYY-MM-DD", "timestamp": "YYYY-MM-DD HH:MM:SS (no time zone)",
    "timestamp_utc": "YYYY-MM-DD HH:MM:SS+00:00 (an instant, in UTC)", "float": "shortest decimal that reads back exactly",
    "uuid": "lowercase hyphenated", "load_hint": "COPY <table> FROM '<file>' WITH (FORMAT csv, HEADER true)",
}


def write_csv(frame: pl.DataFrame, path: Path) -> None:
    zoned = [name for name, dtype in frame.schema.items() if isinstance(dtype, pl.Datetime) and dtype.time_zone]
    frame = frame.with_columns(pl.col(name).dt.strftime(TIMESTAMP_FORMAT + "%:z") for name in zoned)
    frame.write_csv(path, include_header=True, null_value="", quote_style="necessary", line_terminator="\n",
                    datetime_format=TIMESTAMP_FORMAT, include_bom=False)


def read_csv(path: Path, schema) -> pl.DataFrame:
    """Re-read an exported CSV with the exact schema it was written with."""
    return pl.read_csv(path, schema=schema, has_header=True, encoding="utf8")


def write_tables(directory: Path, frames: dict[str, pl.DataFrame], names: dict[str, str]) -> None:
    for table, frame in frames.items():
        write_csv(frame, directory / names[table])


def _invalid(message: str) -> GenerationError:
    return GenerationError([Problem("validation_failed", "serialized_output_invalid", message)])


def verify_tables(directory: Path, plan: LoadedPlan, frames: dict[str, pl.DataFrame], names: dict[str, str],
                  rows: dict[str, int], filled=(), pending: int = 0, rules=(), scenario=None) -> Report:
    """Re-read every CSV with its exact schema: it must equal the in-memory table, and the re-read
    tables must pass the validator on their own. Catches export corruption."""
    reread, problems = {}, []
    for table, frame in frames.items():
        try:
            reread[table] = read_csv(directory / names[table], frame.schema)
        except (pl.exceptions.PolarsError, OSError) as e:
            problems.append(f"{table} ({names[table]}) can't be read back: {str(e).splitlines()[0]}")
            continue
        if not reread[table].equals(frame):
            problems.append(f"{table} ({names[table]}) reads back different from what was generated")
    if problems:
        raise _invalid("; ".join(problems))
    report = validate(plan, reread, rows, filled, pending, rules, scenario)
    if not report.passed:
        failed = _failures(report)
        raise _invalid("serialized tables fail validation: " + "; ".join(failed[:10]))
    return report


def publish(out: Path, build: Callable[[Path], None], force: bool = False) -> None:
    """Build the bundle in a sibling staging directory, then rename it to `out`. With `force`, an
    existing `out` is replaced only after the build succeeded. On any failure, staging is removed and
    an existing `out` is left as it was."""
    out = Path(out)
    if out.exists() and not force:
        raise GenerationError([Problem("input", "output_exists",
                                       f"output {out} already exists; choose another --out or pass --force to replace it")])
    out.parent.mkdir(parents=True, exist_ok=True)
    staging = out.parent / f".{out.name}.staging-{secrets.token_hex(4)}"
    staging.mkdir()
    try:
        build(staging)
        if out.exists():
            backup = out.parent / f".{out.name}.old-{secrets.token_hex(4)}"
            os.rename(out, backup)
            try:
                os.rename(staging, out)
            except OSError:
                os.rename(backup, out)  # put the old bundle back
                raise
            if backup.is_dir():
                shutil.rmtree(backup)
            else:
                backup.unlink()
        else:
            os.rename(staging, out)
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def _fk_label(fk) -> str:
    return f"({', '.join(fk.columns)}) -> {fk.ref_table} ({', '.join(fk.ref_columns)})"


def manifest(loaded: LoadedPlan, plan: GenerationPlan, config: GenerationConfig, data: GeneratedData,
             names: dict[str, str], rules=None) -> dict:
    """Everything needed to reproduce and load the bundle. No timestamp, so identical runs are byte-identical."""
    filled: dict[tuple[str, int], int] = {}
    for entry in data.filled:
        filled[(entry.table, entry.fk_index)] = filled.get((entry.table, entry.fk_index), 0) + 1
    tables = {}
    for table in loaded.schema.tables:
        t = plan.tables[table.name]
        tables[table.name] = {
            "file": f"{CSV_DIR}/{names[table.name]}",
            "rows": t.rows,
            "columns": [{"name": c.name, "type": c.type, "csv": type_spec(c).csv_format} for c in table.columns],
            "identity_columns": [{"name": c.name, "kind": c.identity, "needs_overriding_system_value": c.identity == "always"}
                                 for c in table.columns if c.identity],
            "inferred_columns": {c: p for c, p in data.providers[table.name].items()  # guesses from names, not rules
                                 if p.startswith(("faker.", "kind.", "label.")) and not t.columns[c].rule_ids},
            "forced_nulls": {_fk_label(t.fks[i].fk): n for (name, i), n in sorted(plan.forced_nulls.items()) if name == table.name},
        }
        if rules is not None:
            tables[table.name]["ruled_columns"] = {c.name: list(c.rule_ids) for c in t.columns.values() if c.rule_ids}
    backfills = []
    for b in plan.backfills:
        index = loaded.schema.table(b.table).foreign_keys.index(b.fk)
        backfills.append({"table": b.table, "foreign_key": list(b.fk.columns), "references": b.fk.ref_table,
                          "null_columns": list(b.null_columns), "retained_columns": list(b.retained_columns),
                          "rows_filled": filled.get((b.table, index), 0)})
    return {
        "generator": f"dcloneb {__version__}",
        "dependencies": {"python": platform.python_version(), "faker": version("faker"), "polars": version("polars"),
                         "sqlglot": version("sqlglot")},
        "plan_sha256": loaded.sha256,
        "config": config.raw,
        "seed": config.seed,
        "resolved": {"seed": config.seed, "null_probability": config.null_probability, "locale": config.locale,
                     "rows": {name: t.rows for name, t in plan.tables.items()}},
        "csv_format": CSV_FORMAT,
        "tables": tables,
        "backfills": backfills,
        "plan_hooks_applied": plan.plan_hooks_applied,
        "constraints_not_evaluated": NOT_EVALUATED,
        "validation": "passed",
    } | ({} if rules is None else {"rules": {
        "engine_version": ENGINE_VERSION, "sha256": rules.sha256, "source_sha256": rules.source_sha256,
        "ids": sorted(r.id for r in rules.rules)}})


def _write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def _failures(report: Report) -> list[str]:
    return ([f"{c.table}: {c.check} {c.constraint}" for c in report.checks if c.violations]
            + [f"{r.table}.{r.column}: rule {r.rule_id!r} ({r.violations} violation(s))" for r in report.rules if r.violations])


def validated(loaded: LoadedPlan, plan: GenerationPlan, data: GeneratedData, rules=None, scenario=None) -> Report:
    """The in-memory validation report; GenerationError (validation_failed) if anything fails."""
    report = validate(loaded, data.frames, {name: t.rows for name, t in plan.tables.items()}, data.filled, len(data.ledger),
                      rules.rules if rules else (), scenario)
    if not report.passed:
        failed = _failures(report)
        raise GenerationError([Problem("validation_failed", "generated_data_invalid",
                                       "generated tables fail validation (a dcloneb bug): " + "; ".join(failed[:10]))])
    return report


def export_bundle(out: Path, loaded: LoadedPlan, plan: GenerationPlan, config: GenerationConfig, data: GeneratedData,
                  force: bool = False, extra_files: Optional[dict[str, str]] = None, rules=None,
                  manifest_extra: Optional[dict] = None, scenario=None) -> dict:
    """Validate in memory, write CSVs to staging, re-read and validate them, then publish. Returns the manifest.
    `scenario` (resolved) adds its checks to both validation passes."""
    rows = {name: t.rows for name, t in plan.tables.items()}
    in_memory = validated(loaded, plan, data, rules, scenario)
    names = file_names(data.frames)
    result = manifest(loaded, plan, config, data, names, rules) | dict(manifest_extra or {})
    extra = dict(extra_files or {}) | ({} if rules is None else {"rules.json": rules.to_json()})

    def build(staging: Path) -> None:
        (staging / CSV_DIR).mkdir()
        write_tables(staging / CSV_DIR, data.frames, names)
        serialized = verify_tables(staging / CSV_DIR, loaded, data.frames, names, rows, data.filled, len(data.ledger),
                                   rules.rules if rules else (), scenario)
        result["validation"] = serialized.verdict["status"]  # of the CSVs as written
        _write_json(staging / "validation_report.json", {"in_memory": in_memory.to_dict(), "serialized": serialized.to_dict()})
        _write_json(staging / "manifest.json", result)
        for name, text in extra.items():
            (staging / name).write_text(text, encoding="utf-8")

    publish(out, build, force)
    return result
