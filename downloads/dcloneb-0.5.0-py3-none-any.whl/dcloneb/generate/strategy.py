"""Generation planning (plan2 G5): decide how every column, FK and key is produced, before any value exists.

The GenerationPlan is the seam for business rules: `plan_hooks` run on it after planning and before
generation, so they can change providers or strategies (the rules.json engine is one such hook).
"""

from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence

from dcloneb.generate.config import GenerationConfig, resolve_rows
from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.plan_input import LoadedPlan, PlanBackfill
from dcloneb.generate.providers import provider_for, subseed
from dcloneb.generate.types import TypeSpec, type_spec
from dcloneb.model import ForeignKey, Schema, Table


@dataclass
class ColumnPlan:
    name: str
    spec: TypeSpec
    role: str  # identity (1..N) | fk (from parent tuples) | free_key (in a PK/UNIQUE, no FK) | value
    nullable: bool  # the generator may write NULL here
    sql_nullable: bool = False  # SQL allows NULL here (used for capacity proofs)
    provider: object = None  # None for identity and fk columns
    rule_ids: tuple[str, ...] = ()  # business rules that shaped this column (plan3)
    always_null: bool = False  # rules leave no non-NULL value, but NULL passes them and the schema
    null_rate: Optional[float] = None  # plan6 D3: exact share of NULL rows instead of `null_probability`


@dataclass
class FkPlan:
    fk: ForeignKey
    unique: bool  # the child's FK columns are unique: sample parents without replacement
    can_be_null: bool  # SQL lets a row skip this FK (MATCH SIMPLE: any column NULL; FULL: all NULL)
    nullable: bool  # ... and the generator may write that NULL pattern (no never-NULL column is needed)
    backfill: Optional[PlanBackfill] = None
    reserved: bool = False  # retained columns come from the parent's pre-allocated key (G5.2)


@dataclass
class KeyPlan:
    columns: tuple[str, ...]
    nulls_distinct: bool
    primary: bool
    strategy: str  # identity | fk_groups | single_free | composite | implied (by a smaller key)
    groups: tuple[int, ...] = ()  # fk_groups: indices into TablePlan.fks whose columns make up the key


ANY = "any"  # a scenario FK pick: an ordinary (background) parent row, chosen by the generator


@dataclass
class TableScenario:
    """plan6 E2: rows a scenario pins. The first `pinned` rows are its entities; the rest are ordinary."""
    pinned: int
    fixed: dict  # row -> column -> typed value, never changed by the generator
    picks: dict  # FK index -> per row: parent row index, None (NULL), or ANY


@dataclass
class TablePlan:
    name: str
    rows: int
    columns: dict[str, ColumnPlan]  # in plan column order
    fks: list[FkPlan]
    keys: list[KeyPlan]  # PK first, then unique keys in plan order
    conditionals: list = field(default_factory=list)  # plan6 D4: (when column, value, then column, value)
    scenario: Optional[TableScenario] = None  # plan6 E2


@dataclass
class GenerationPlan:
    seed: int
    null_probability: float
    locale: str
    order: list[str]
    tables: dict[str, TablePlan]
    backfills: list[PlanBackfill]
    reservations: dict[str, list[tuple[str, ...]]] = field(default_factory=dict)  # parent -> keys to pre-allocate
    forced_nulls: dict[tuple[str, int], int] = field(default_factory=dict)  # (table, fk index) -> rows that must skip it
    plan_hooks_applied: list[str] = field(default_factory=list)


PlanHook = Callable[[GenerationPlan], GenerationPlan]


def referenced_columns(schema: Schema, table: Table) -> set[str]:
    """Columns of `table` that some FK (from any table, including itself) references."""
    return {c for t in schema.tables for fk in t.foreign_keys if fk.ref_table == table.name for c in fk.ref_columns}


def _never_null(schema: Schema, table: Table) -> set[str]:
    nnd = {c for k in table.unique_keys if not k.nulls_distinct for c in k.columns}
    identity = {c.name for c in table.columns if c.identity}
    return set(table.primary_key or ()) | nnd | identity | referenced_columns(schema, table)


def _role(table: Table, name: str, identity: bool) -> str:
    if any(name in fk.columns for fk in table.foreign_keys):
        return "fk"  # FK wins over identity: values must match a parent
    if identity:
        return "identity"
    if any(name in key for key in table.keys()):
        return "free_key"
    return "value"


def _fk_plan(table: Table, fk: ForeignKey, columns: dict[str, ColumnPlan], backfill: Optional[PlanBackfill]) -> FkPlan:
    gen_nullable = [columns[c].nullable for c in fk.columns]
    nullable = all(gen_nullable) if fk.match == "full" else any(gen_nullable)
    return FkPlan(fk, table.is_unique(fk.columns), fk.can_be_null(table), nullable, backfill)


def _implied(i: int, declared: list) -> bool:
    """Key i is unique automatically if another key is a strict subset of it, or the same set declared earlier."""
    cols = set(declared[i][0])
    return any(set(other) < cols or (set(other) == cols and j < i) for j, (other, _, _) in enumerate(declared) if j != i)


def _key_plans(table: Table, columns: dict[str, ColumnPlan], fks: list[FkPlan]) -> list[KeyPlan]:
    declared = ([(table.primary_key, True, True)] if table.primary_key else []) + \
               [(k.columns, k.nulls_distinct, False) for k in table.unique_keys]
    plans = []
    for i, (cols, nulls_distinct, primary) in enumerate(declared):
        groups = tuple(n for n, f in enumerate(fks) if set(f.fk.columns) <= set(cols))
        if _implied(i, declared):
            strategy = "implied"
        elif any(columns[c].role == "identity" for c in cols):
            strategy = "identity"
        elif groups and set(cols) == {c for n in groups for c in fks[n].fk.columns}:
            strategy = "fk_groups"
        elif len(cols) == 1 and columns[cols[0]].role == "free_key":
            strategy = "single_free"
        else:
            strategy = "composite"
        plans.append(KeyPlan(tuple(cols), nulls_distinct, primary, strategy, groups if strategy == "fk_groups" else ()))
    return plans


def _table_plan(plan: LoadedPlan, config: GenerationConfig, table: Table, rows: int) -> TablePlan:
    never_null = _never_null(plan.schema, table)
    columns = {}
    for c in table.columns:
        spec, role = type_spec(c), _role(table, c.name, c.identity is not None)
        provider = None
        if role in ("free_key", "value"):
            provider = provider_for(c, spec, subseed(config.seed, table.name, c.name, "values"), config.locale,
                                    f"{table.name}.{c.name}", table=table.name)
        columns[c.name] = ColumnPlan(c.name, spec, role, c.nullable and c.name not in never_null, c.nullable, provider)
    backfills = {b.fk: b for b in plan.backfills if b.table == table.name}
    fks = [_fk_plan(table, fk, columns, backfills.get(fk)) for fk in table.foreign_keys]
    return TablePlan(table.name, rows, columns, fks, _key_plans(table, columns, fks))


def _reservations(tables: dict[str, TablePlan]) -> dict[str, list[tuple[str, ...]]]:
    """A backfill that keeps some FK columns (MATCH SIMPLE) needs the parent's key before the child's rows
    exist, so the child can copy the retained part of a real parent tuple. The parent key is pre-allocated,
    which works only if the generator alone decides it (identity or free key columns, not FK-derived)."""
    reservations: dict[str, list[tuple[str, ...]]] = {}
    problems = []
    for table in tables.values():
        for f in table.fks:
            if f.backfill is None or not f.backfill.retained_columns:
                continue
            parent = tables[f.fk.ref_table]
            derived = [c for c in f.fk.ref_columns if parent.columns[c].role not in ("identity", "free_key")]
            if derived:
                problems.append(Problem(
                    "unsupported", "backfill_reservation_unsupported",
                    f"backfill of {table.name}({', '.join(f.fk.columns)}) keeps {', '.join(f.backfill.retained_columns)}, "
                    f"so {parent.name}'s key must be pre-allocated, but "
                    f"{', '.join(f'{parent.name}.{c}' for c in derived)} come(s) from a foreign key"))
                continue
            f.reserved = True
            keys = reservations.setdefault(parent.name, [])
            if f.fk.ref_columns not in keys:
                keys.append(f.fk.ref_columns)
    if problems:
        raise GenerationError(problems)
    return reservations


def build_generation_plan(plan: LoadedPlan, config: GenerationConfig, plan_hooks: Sequence[PlanHook] = ()) -> GenerationPlan:
    """Plan generation for a plan that passed `support.check_support`. Hooks run last, before any value exists."""
    rows = resolve_rows(config, [t.name for t in plan.schema.tables])
    tables = {t.name: _table_plan(plan, config, t, rows[t.name]) for t in plan.schema.tables}
    result = GenerationPlan(config.seed, config.null_probability, config.locale, list(plan.order), tables,
                            list(plan.backfills), _reservations(tables))
    for hook in plan_hooks:
        result = hook(result)
        result.plan_hooks_applied.append(getattr(hook, "__name__", repr(hook)))
    return result
