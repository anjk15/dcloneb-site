"""Support matrix and the pre-generation support check (plan2 G3).

Anything outside the matrix is rejected before generation, with every problem reported together.
Nothing is ignored silently.
"""

from itertools import combinations

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.plan_input import LoadedPlan
from dcloneb.model import Column, Table

MAX_DECIMAL_PRECISION = 38  # Polars Decimal limit (plan2 spike G0.3)

# type_info.name -> how it's generated (rendered in the README support matrix)
SUPPORTED_TYPES = {
    "SMALLINT": "full type range; keys sequential from 1",
    "INT": "full type range; keys sequential from 1",
    "BIGINT": "full type range; keys sequential from 1",
    "TINYINT": "full type range; keys sequential from 1",
    "SMALLSERIAL": "identity: 1..N",
    "SERIAL": "identity: 1..N",
    "BIGSERIAL": "identity: 1..N",
    "DECIMAL": f"exact decimals within (p, s), p <= {MAX_DECIMAL_PRECISION}; unparameterized: (12, 2) values",
    "FLOAT": "32-bit, within +-1,000,000 (about 7 significant digits); keys 1..N",
    "DOUBLE": "64-bit, two decimals within +-1,000,000; keys 1..N",
    "BOOLEAN": "true/false",
    "VARCHAR": "ASCII, length <= min(n, 64)",
    "TEXT": "ASCII, length <= 64",
    "CHAR": "exactly n ASCII characters, no trailing spaces",
    "DATE": "YYYY-MM-DD in 2000-01-01..2030-12-31",
    "TIMESTAMP": "YYYY-MM-DD HH:MM:SS (whole seconds) in the same range",
    "TIMESTAMPNTZ": "as TIMESTAMP (Databricks TIMESTAMP_NTZ)",
    "TIMESTAMPTZ": "an instant, YYYY-MM-DD HH:MM:SS+00:00 in UTC, same range (Databricks TIMESTAMP)",
    "UUID": "lowercase hyphenated v4 from the seeded RNG",
}

# Plan diagnostic code -> what the generator does with it. "structural": decided from the plan's
# structured fields instead (CHECK, generated, COLLATE), so it isn't reported twice. Codes missing
# from this table, including ones the planner adds later, are rejected.
DIAGNOSTICS = {
    "statement_ignored": ("allowed", "doesn't define tables or keys"),
    "not_deferrable_normalized": ("allowed", "meaning unchanged"),
    "index_not_used": ("allowed", "non-unique indexes don't constrain data"),
    "fk_action_not_used": ("allowed", "ON DELETE/UPDATE only act on changes"),
    "default_not_used": ("allowed", "an explicit value is always valid"),
    "identity_column": ("allowed", "identity values are generated as 1..N"),
    "constraint_not_valid": ("allowed", "the data satisfies the constraint anyway"),
    "nary_link_not_classified": ("allowed", "its keys and FKs are still enforced"),
    "fk_deferrable_not_used": ("allowed", "the data satisfies the FK immediately"),
    "constraint_not_enforced": ("allowed", "the data satisfies the constraint anyway"),
    "databricks_property_not_used": ("allowed", "Delta storage and layout properties don't constrain the data"),
    "collate_not_used": ("structural", "allowed except on PK/UNIQUE/FK columns"),
    "check_not_evaluated": ("structural", "CHECK constraints are not supported"),
    "generated_column": ("structural", "generated columns are not supported"),
    "table_property_not_used": ("rejected", "a table property may affect loading (e.g. partitioning)"),
    "partial_unique_index_not_modeled": ("rejected", "the planner doesn't model this uniqueness"),
    "expression_unique_index_not_modeled": ("rejected", "the planner doesn't model this uniqueness"),
}


def _problem(code: str, message: str) -> Problem:
    return Problem("unsupported", code, message)


def type_problems(table: Table, column: Column) -> list[Problem]:
    label = f"{table.name}.{column.name}"
    if column.type_name not in SUPPORTED_TYPES:
        return [_problem("unsupported_type", f"{label}: type {column.type} is not supported; "
                         f"supported: {', '.join(sorted(SUPPORTED_TYPES))}")]
    if column.type_name == "DECIMAL" and column.type_params and column.type_params[0] > MAX_DECIMAL_PRECISION:
        return [_problem("unsupported_decimal_precision",
                         f"{label}: {column.type} has precision above {MAX_DECIMAL_PRECISION}, which is not supported")]
    if column.type_name == "DECIMAL" and len(column.type_params) == 2 and column.type_params[1] > column.type_params[0]:
        return [_problem("unsupported_decimal_scale", f"{label}: {column.type} has a scale above its precision, which is not supported")]
    return []


def diagnostic_problems(diagnostics: list[dict]) -> list[Problem]:
    problems = []
    for d in diagnostics:
        status, why = DIAGNOSTICS.get(d["code"], ("rejected", "not in the generator's support matrix"))
        if status == "rejected":
            problems.append(_problem("unsupported_plan_diagnostic",
                                     f"plan diagnostic {d['code']} ({why}): {d['message']}"))
    return problems


def key_columns(table: Table) -> set[str]:
    """Columns whose comparison semantics decide uniqueness or references: PK, UNIQUE, FK."""
    return {c for key in table.keys() for c in key} | {c for fk in table.foreign_keys for c in fk.columns}


def constraint_problems(table: Table) -> list[Problem]:
    problems = [_problem("check_constraint", f"{table.name}: CHECK ({check}) is not supported") for check in table.checks]
    problems += [_problem("generated_column", f"{table.name}.{c.name} is a generated column, which is not supported")
                 for c in table.columns if c.generated]
    keys = key_columns(table)
    problems += [_problem("collation_on_key",
                          f"{table.name}.{c.name}: COLLATE {c.collation} on a key column may change what counts as equal")
                 for c in table.columns if c.collation and c.name in keys]
    # identical FKs (only the name differs) constrain the same thing once, so they don't overlap
    fks = {(fk.columns, fk.ref_table, fk.ref_columns, fk.match): fk for fk in table.foreign_keys}.values()
    for a, b in combinations(fks, 2):
        shared = [c for c in a.columns if c in b.columns]
        if shared:
            problems.append(_problem(
                "overlapping_foreign_keys",
                f"{table.name}: foreign keys ({', '.join(a.columns)}) -> {a.ref_table} and ({', '.join(b.columns)}) -> "
                f"{b.ref_table} share column(s) {', '.join(shared)}; overlapping foreign keys are not supported yet"))
    return problems


def check_support(plan: LoadedPlan) -> None:
    """Raise GenerationError (kind `unsupported`) listing every unsupported feature, or return None."""
    problems = diagnostic_problems(plan.diagnostics)
    for table in plan.schema.tables:
        for column in table.columns:
            problems += type_problems(table, column)
        problems += constraint_problems(table)
    if problems:
        raise GenerationError(problems)


# Constraints and features (rendered in the README; the checks above enforce the "unsupported" rows).
FEATURES = [
    ("NOT NULL, PRIMARY KEY (single and composite)", "supported", "never NULL; PK values unique"),
    ("UNIQUE / unique index, nulls distinct", "supported", "the whole combination is unique; no component is made unique on its own"),
    ("UNIQUE NULLS NOT DISTINCT", "supported", "NULL compares as a value; the generator never writes NULL there"),
    ("FOREIGN KEY, MATCH SIMPLE / FULL, single or composite, to a PK or UNIQUE", "supported", "complete parent tuples only"),
    ("one-to-one (unique FK), many-to-one, junction tables, n-ary links", "supported", "unique FKs never reuse a parent"),
    ("backfills: self-references, multi-table cycles, retained columns", "supported", "retained columns need a parent key the generator decides (identity or plain key columns)"),
    ("DEFERRABLE / INITIALLY DEFERRED, NOT VALID foreign keys", "supported", "the data satisfies them immediately"),
    ("identity (ALWAYS / BY DEFAULT), SERIAL types", "supported", "values 1..N; ALWAYS is flagged in the manifest (load with OVERRIDING SYSTEM VALUE)"),
    ("DEFAULT", "supported", "ignored: explicit values are always valid"),
    ("COLLATE", "supported off key columns", "rejected on PK/UNIQUE/FK columns (`collation_on_key`)"),
    ("FKs sharing child columns with another FK", "unsupported", "`overlapping_foreign_keys`"),
    ("CHECK", "unsupported", "`check_constraint`"),
    ("generated columns", "unsupported", "`generated_column`"),
    ("partial or expression unique indexes, table properties", "unsupported", "`unsupported_plan_diagnostic`"),
    ("triggers, functions, views, row-level security", "not evaluated", "the CSVs satisfy declared constraints only"),
]


def render_matrix() -> str:
    """The README support matrix, rendered from the tables in this module."""
    lines = ["#### Column types", "", "| `type_info.name` | Generated values |", "|---|---|"]
    lines += [f"| `{name}` | {how} |" for name, how in SUPPORTED_TYPES.items()]
    lines += ["", f"Any other type is rejected (`unsupported_type`), as is `DECIMAL` with precision above "
              f"{MAX_DECIMAL_PRECISION} or a scale above its precision.", "",
              "#### Constraints and features", "", "| Feature | Status | Notes |", "|---|---|---|"]
    lines += [f"| {feature} | {status} | {notes} |" for feature, status, notes in FEATURES]
    lines += ["", "#### Plan diagnostics", "",
              "Any diagnostic code not listed here, including codes the planner adds later, is rejected.", "",
              "| Diagnostic | Generator | Why |", "|---|---|---|"]
    lines += [f"| `{code}` | {status} | {why} |" for code, (status, why) in DIAGNOSTICS.items()]
    return "\n".join(lines)
