"""Python API for the generator (plan2 G12.1). The CLI is a thin wrapper around `generate`, and a
future MCP wrapper can call `generate_tables` directly.

Order: load inputs -> support check -> generation plan (+ plan hooks) -> capacity -> tables -> backfills
-> validation (-> CSV bundle). Every failure is a GenerationError.
"""

import hashlib
import json
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Optional, Sequence, Union

from dcloneb.generate.backfill_exec import run_backfills
from dcloneb.generate.capacity import check_capacity
from dcloneb.generate.config import GenerationConfig, load_config, parse_config, resolve_rows
from dcloneb.generate.engine import GeneratedData
from dcloneb.generate.engine import generate_tables as _generate
from dcloneb.generate.export import export_bundle, validated
from dcloneb.generate.plan_input import LoadedPlan, load_plan, parse_plan
from dcloneb.generate.rules.contract import RuleSet, load_rules, parse_rules
from dcloneb.generate.rules.hook import rules_hook
from dcloneb.generate.rules.preflight import NormalizedRules, preflight
from dcloneb.generate.scenario import ResolvedScenario, load_scenario, scenario_hook
from dcloneb.generate.scenario import preflight_scenario as _preflight_scenario
from dcloneb.generate.strategy import GenerationPlan, PlanHook, build_generation_plan
from dcloneb.generate.support import check_support
from dcloneb.plan import analyze

MAKE_DEFAULTS = {"seed": 42, "default_rows": 100}

PlanInput = Union[LoadedPlan, dict, str, Path]
ConfigInput = Union[GenerationConfig, dict, str, Path]
RulesInput = Union[RuleSet, dict, str, Path]
ScenarioInput = Union[dict, str, Path]


@dataclass(frozen=True)
class Result:
    out: Path
    manifest: dict


def _plan(plan: PlanInput) -> LoadedPlan:
    if isinstance(plan, LoadedPlan):
        return plan
    return parse_plan(plan) if isinstance(plan, dict) else load_plan(Path(plan))


def _config(config: ConfigInput) -> GenerationConfig:
    if isinstance(config, GenerationConfig):
        return config
    return parse_config(config) if isinstance(config, dict) else load_config(Path(config))


def _rules(rules: RulesInput) -> RuleSet:
    if isinstance(rules, RuleSet):
        return rules
    return parse_rules(rules) if isinstance(rules, dict) else load_rules(Path(rules))


def preflight_rules(plan: PlanInput, rules: RulesInput, config: Optional[ConfigInput] = None) -> NormalizedRules:
    """Validate and normalize rules against a plan without generating or writing anything. With a
    config, row counts are known and capacity is checked too. A future MCP tool calls this."""
    loaded = _plan(plan)
    check_support(loaded)
    rows = None
    if config is not None:
        rows = resolve_rows(_config(config), [t.name for t in loaded.schema.tables])
    return preflight(loaded, _rules(rules), rows)


def _scenario(loaded: LoadedPlan, rules: Optional[RulesInput], scenario: ScenarioInput,
              config: Optional[GenerationConfig] = None) -> ResolvedScenario:
    """The rules are normalized first (their scales type the fixed values), then the scenario is resolved to rows.
    With a config, the tables the scenario doesn't mention get the config's row counts."""
    normalized = None if rules is None else preflight(loaded, _rules(rules))
    data, sha = (scenario, None) if isinstance(scenario, dict) else load_scenario(Path(scenario))
    fill = None if config is None else resolve_rows(config, [t.name for t in loaded.schema.tables])
    return _preflight_scenario(loaded, normalized, data, sha, fill)


def preflight_scenario(plan: PlanInput, rules: Optional[RulesInput], scenario: ScenarioInput,
                       config: Optional[ConfigInput] = None) -> ResolvedScenario:
    """Check a scenario against a plan and its rules and resolve it to exact rows, without generating anything.
    With a config, the tables the scenario doesn't mention are filled with its row counts."""
    loaded = _plan(plan)
    check_support(loaded)
    return _scenario(loaded, rules, scenario, None if config is None else _config(config))


@dataclass(frozen=True)
class _Prepared:
    loaded: LoadedPlan
    config: GenerationConfig
    generation: GenerationPlan
    rules: Optional[NormalizedRules]
    scenario: Optional[ResolvedScenario]


def _prepare(plan: PlanInput, config: ConfigInput, plan_hooks: Sequence[PlanHook], rules: Optional[RulesInput],
             scenario: Optional[ScenarioInput] = None) -> _Prepared:
    """Support check, then (with a scenario) its exact row counts in place of the config's, then (with rules)
    preflight against the row counts, then the generation plan with the rules and scenario hooks first, then
    generator capacity."""
    loaded, cfg = _plan(plan), _config(config)
    check_support(loaded)
    resolved = None
    if scenario is not None:
        resolved = _scenario(loaded, rules, scenario, cfg)
        cfg = replace(cfg, table_rows=dict(resolved.rows))
    normalized, hooks = None, list(plan_hooks)
    if resolved is not None:
        hooks = [scenario_hook(resolved), *hooks]
    if rules is not None:
        rows = resolve_rows(cfg, [t.name for t in loaded.schema.tables])
        normalized = preflight(loaded, _rules(rules), rows)
        hooks = [rules_hook(normalized), *hooks]
    generation = build_generation_plan(loaded, cfg, hooks)
    check_capacity(generation)
    return _Prepared(loaded, cfg, generation, normalized, resolved)


def generate_tables(plan: PlanInput, config: ConfigInput, rules: Optional[RulesInput] = None,
                    plan_hooks: Sequence[PlanHook] = (), scenario: Optional[ScenarioInput] = None) -> GeneratedData:
    """Generate and validate every table in memory (schema constraints and every rule); nothing is written.
    With a scenario, its rows and counts replace the config's row counts."""
    p = _prepare(plan, config, plan_hooks, rules, scenario)
    data = run_backfills(p.generation, _generate(p.generation))
    validated(p.loaded, p.generation, data, p.rules, p.scenario)
    return data


def generate(plan: PlanInput, config: ConfigInput, out: Union[str, Path], force: bool = False,
             rules: Optional[RulesInput] = None, plan_hooks: Sequence[PlanHook] = (),
             extra_files: Optional[dict[str, str]] = None, manifest_extra: Optional[dict] = None,
             scenario: Optional[ScenarioInput] = None) -> Result:
    """Generate, validate, and publish the CSV bundle at `out` (see export.export_bundle). `extra_files` and
    `manifest_extra` add files and manifest sections (the MCP server records plan.json and the approval).
    With a scenario, the bundle also keeps plan.json, scenario.json and generation.json, so the run folder
    reproduces it."""
    extra = dict(extra_files or {})
    if scenario is not None and "plan.json" not in extra:
        text = _plan_text(plan)
        if text is not None:
            extra["plan.json"] = text
    return _bundle(_plan(plan), config, out, force, plan_hooks, rules, extra, manifest_extra, scenario)


def _plan_text(plan: PlanInput) -> Optional[str]:
    """The plan as given: a file's exact text, or a dict as `dcloneb analyze` writes it (None for a loaded plan)."""
    if isinstance(plan, LoadedPlan):
        return None
    if isinstance(plan, dict):
        return json.dumps(plan, sort_keys=True, indent=2) + "\n"
    return Path(plan).read_text(encoding="utf-8")


def _jsonable(value):
    return value if value is None or isinstance(value, (bool, int, float, str)) else str(value)


def _scenario_manifest(p: _Prepared, data: GeneratedData) -> dict:
    """Where each alias landed (table, row index, its primary key values) and what the run is meant to show."""
    rows = {}
    for alias, (table, row) in sorted(p.scenario.aliases.items()):
        pk = p.loaded.schema.table(table).primary_key or ()
        rows[alias] = {"table": table, "row_index": row,
                       "keys": {c: _jsonable(data.frames[table][c][row]) for c in pk}}
    return {"rows": rows, "violations": p.scenario.raw.get("violations", []),
            "expected_outcome": p.scenario.expected_outcome,
            "sha256": hashlib.sha256(p.scenario.to_json().encode("utf-8")).hexdigest()}


def _bundle(loaded: LoadedPlan, config: ConfigInput, out: Union[str, Path], force: bool, plan_hooks: Sequence[PlanHook],
            rules: Optional[RulesInput], extra_files: Optional[dict[str, str]] = None,
            manifest_extra: Optional[dict] = None, scenario: Optional[ScenarioInput] = None) -> Result:
    p = _prepare(loaded, config, plan_hooks, rules, scenario)
    data = run_backfills(p.generation, _generate(p.generation))
    extra, sections = dict(extra_files or {}), dict(manifest_extra or {})
    if p.scenario is not None:
        extra |= {"scenario.json": p.scenario.to_json(),
                  "generation.json": json.dumps(p.config.raw, sort_keys=True, indent=2) + "\n"}
        sections["scenario"] = _scenario_manifest(p, data)
    return Result(Path(out), export_bundle(Path(out), p.loaded, p.generation, p.config, data, force, extra, p.rules,
                                           sections, p.scenario))


def make(ddl: str, out: Union[str, Path] = "generated", rows: Optional[int] = None, seed: Optional[int] = None,
         config: Optional[ConfigInput] = None, force: bool = False, rules: Optional[RulesInput] = None,
         plan_hooks: Sequence[PlanHook] = (), scenario: Optional[ScenarioInput] = None) -> Result:
    """DDL text straight to a CSV bundle: analyze (PostgreSQL), then generate. Defaults: 100 rows per
    table, seed 42. `config` (a generation.json path or dict) sets the rest; `rows`/`seed` override it.
    The plan is kept in the bundle as plan.json, and accepted rules as rules.json."""
    plan_text = analyze(ddl, "postgres").to_json()
    loaded = parse_plan(json.loads(plan_text), hashlib.sha256(plan_text.encode("utf-8")).hexdigest())
    base = {} if config is None else (config if isinstance(config, dict) else _config(config).raw)
    settings = {**MAKE_DEFAULTS, **base}
    if rows is not None:
        settings["default_rows"] = rows
    if seed is not None:
        settings["seed"] = seed
    return _bundle(loaded, settings, out, force, plan_hooks, rules, {"plan.json": plan_text}, scenario=scenario)
