"""Load plan.json into dcloneb.model objects (plan2 G2.3).

The plan is the only schema source: nothing here reads DDL. A plan without the 0.2.0 generator
metadata (G1) is rejected rather than guessed at.
"""

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.model import Column, ForeignKey, Key, Schema, Table

FORMAT_VERSION = 1
COLUMN_METADATA = ("type_info", "identity", "has_default", "collation")
TABLE_METADATA = ("unique_keys", "checks")
RERUN = "re-run `dcloneb analyze` (0.2.0 or later) to add generator metadata"


@dataclass(frozen=True)
class PlanBackfill:
    table: str
    fk: ForeignKey
    null_columns: tuple[str, ...]  # temporarily NULL until the backfill runs
    retained_columns: tuple[str, ...]  # keep their values
    fill: tuple[tuple[str, str], ...]  # (child column, parent column)


@dataclass(frozen=True)
class LoadedPlan:
    schema: Schema  # tables only; plan diagnostics are kept as dicts in `diagnostics`
    order: list[str]
    backfills: list[PlanBackfill]
    diagnostics: list[dict]
    sha256: Optional[str] = None  # of the file bytes, when loaded from a file


class _Malformed(Exception):
    pass


def _fail(code: str, message: str) -> GenerationError:
    return GenerationError([Problem("input", code, message)])


def _column(data: dict) -> Column:
    info = data["type_info"]
    return Column(data["name"], data["type"], data["nullable"], data["generated"], info["name"], tuple(info["params"]),
                  data["identity"], data["has_default"], data["collation"])


def _fk(data: dict) -> ForeignKey:
    return ForeignKey(data["name"], tuple(data["columns"]), data["references"]["table"], tuple(data["references"]["columns"]),
                      data["match"], data["deferrable"], data["initially_deferred"])


def _table(name: str, data: dict) -> Table:
    pk = data["primary_key"]
    return Table(
        name=name,
        columns=tuple(_column(c) for c in data["columns"]),
        primary_key=tuple(pk) if pk else None,
        unique_keys=tuple(Key(tuple(k["columns"]), k["nulls_distinct"]) for k in data["unique_keys"]),
        foreign_keys=tuple(_fk(f) for f in data["foreign_keys"]),
        checks=tuple(data["checks"]),
    )


def _backfill(data: dict) -> PlanBackfill:
    return PlanBackfill(data["table"], _fk(data["foreign_key"]), tuple(data["null_columns"]), tuple(data["retained_columns"]),
                        tuple((f["column"], f["parent_column"]) for f in data["fill"]))


def _missing_metadata(tables: dict) -> list[str]:
    missing = []
    for name, table in tables.items():
        missing += [f"{name}.{key}" for key in TABLE_METADATA if key not in table]
        missing += [f"{name}.{c.get('name')}.{key}" for c in table.get("columns", []) for key in COLUMN_METADATA if key not in c]
    return missing


def _check_references(schema: Schema, order: list[str], backfills: list[PlanBackfill]) -> None:
    names = [t.name for t in schema.tables]
    if sorted(order) != sorted(names):
        raise _Malformed("execution_order must list every table exactly once")
    for table in schema.tables:
        columns = {c.name for c in table.columns}
        keys = [table.primary_key or ()] + [k.columns for k in table.unique_keys]
        if not all(set(k) <= columns for k in keys):
            raise _Malformed(f"{table.name}: a key names an unknown column")
        for fk in table.foreign_keys:
            parent = schema.table(fk.ref_table)
            if parent is None or not set(fk.columns) <= columns or len(fk.columns) != len(fk.ref_columns) \
                    or not set(fk.ref_columns) <= {c.name for c in parent.columns}:
                raise _Malformed(f"{table.name}: foreign key ({', '.join(fk.columns)}) -> {fk.ref_table} doesn't resolve")
    for b in backfills:
        if schema.table(b.table) is None or b.fk not in schema.table(b.table).foreign_keys:
            raise _Malformed(f"backfill on {b.table}: its foreign key is not in the table")


def parse_plan(data, sha256: Optional[str] = None) -> LoadedPlan:
    if not isinstance(data, dict):
        raise _fail("plan_not_object", "plan must be a JSON object")
    if data.get("format_version") != FORMAT_VERSION:
        raise _fail("plan_unsupported_format",
                    f"plan format_version {data.get('format_version')!r} is not supported; expected {FORMAT_VERSION}")
    if data.get("status") != "ok":
        errors = [f"{d.get('code')}: {d.get('message')}" for d in data.get("diagnostics", []) if d.get("severity") == "error"]
        raise _fail("plan_has_errors", "the plan has errors; fix the DDL and re-run `dcloneb analyze`"
                    + (": " + "; ".join(errors) if errors else ""))
    try:
        tables = data["tables"]
        missing = _missing_metadata(tables)
        if missing:
            raise _fail("plan_missing_metadata", f"{RERUN}; missing: {', '.join(missing[:5])}"
                        + (f" (+{len(missing) - 5} more)" if len(missing) > 5 else ""))
        schema = Schema(tables=tuple(_table(name, t) for name, t in tables.items()), diagnostics=())
        order = list(data["execution_order"])
        backfills = [_backfill(b) for b in data["backfill"]]
        _check_references(schema, order, backfills)
    except (KeyError, TypeError, ValueError, AttributeError, _Malformed) as e:
        detail = f"missing key {e}" if isinstance(e, KeyError) else str(e)
        raise _fail("plan_malformed", f"plan is malformed: {detail}") from None
    return LoadedPlan(schema, order, backfills, list(data.get("diagnostics", [])), sha256)


def load_plan(path: Path) -> LoadedPlan:
    try:
        raw = Path(path).read_bytes()
        data = json.loads(raw.decode("utf-8"))
    except OSError as e:
        raise _fail("plan_unreadable", f"cannot read plan {path}: {e.strerror or e}") from None
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise _fail("plan_invalid_json", f"plan {path} is not valid JSON: {e}") from None
    return parse_plan(data, hashlib.sha256(raw).hexdigest())
