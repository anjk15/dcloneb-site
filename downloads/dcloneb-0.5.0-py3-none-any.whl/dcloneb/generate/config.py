"""generation.json: parse and validate (plan2 G2.1-G2.2)."""

import json
from dataclasses import dataclass, field
from pathlib import Path

from faker.config import AVAILABLE_LOCALES

from dcloneb.generate.errors import GenerationError, Problem

REQUIRED = ("seed", "default_rows")
DEFAULTS = {"table_rows": {}, "null_probability": 0.1, "locale": "en_US"}


@dataclass(frozen=True)
class GenerationConfig:
    seed: int
    default_rows: int
    table_rows: dict[str, int]
    null_probability: float
    locale: str
    raw: dict = field(compare=False)  # as given, for the manifest


def _is_int(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)  # JSON true/false are not ints


def _is_count(value) -> bool:
    return _is_int(value) and value >= 0


def _invalid(key: str, why: str) -> Problem:
    return Problem("input", "config_invalid_value", f"{key}: {why}")


def parse_config(data) -> GenerationConfig:
    if not isinstance(data, dict):
        raise GenerationError([Problem("input", "config_not_object", "generation config must be a JSON object")])
    problems = [Problem("input", "config_missing_key", f"missing required key '{k}'") for k in REQUIRED if k not in data]
    problems += [Problem("input", "config_unknown_key", f"unknown key '{k}'; allowed: {', '.join(REQUIRED + tuple(DEFAULTS))}")
                 for k in data if k not in REQUIRED and k not in DEFAULTS]
    values = {**DEFAULTS, **data}
    if "seed" in data and not _is_int(data["seed"]):
        problems.append(_invalid("seed", "must be an integer"))
    if "default_rows" in data and not _is_count(data["default_rows"]):
        problems.append(_invalid("default_rows", "must be a nonnegative integer"))
    table_rows = values["table_rows"]
    if not isinstance(table_rows, dict):
        problems.append(_invalid("table_rows", "must be an object mapping table name to row count"))
    else:
        problems += [_invalid(f"table_rows.{name}", "must be a nonnegative integer")
                     for name, n in table_rows.items() if not _is_count(n)]
    p = values["null_probability"]
    if not (isinstance(p, (int, float)) and not isinstance(p, bool) and 0 <= p <= 1):
        problems.append(_invalid("null_probability", "must be a number from 0 to 1"))
    if values["locale"] not in AVAILABLE_LOCALES:
        problems.append(_invalid("locale", f"{values['locale']!r} is not a Faker locale (e.g. en_US, de_DE)"))
    if problems:
        raise GenerationError(problems)
    return GenerationConfig(values["seed"], values["default_rows"], dict(table_rows), float(p), values["locale"], data)


def load_config(path: Path) -> GenerationConfig:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError) as e:
        raise GenerationError([Problem("input", "config_unreadable", f"cannot read config {path}: {e}")]) from None
    except json.JSONDecodeError as e:
        raise GenerationError([Problem("input", "config_invalid_json", f"config {path} is not valid JSON: {e}")]) from None
    return parse_config(data)


def resolve_rows(config: GenerationConfig, tables) -> dict[str, int]:
    """Exact row count per plan table: its `table_rows` override, else `default_rows`. Names must match exactly."""
    names = list(tables)
    unknown = sorted(set(config.table_rows) - set(names))
    if unknown:
        listed = ", ".join(sorted(names))
        raise GenerationError([Problem("input", "unknown_table", f"table_rows: '{name}' is not in the plan; plan tables: {listed}")
                               for name in unknown])
    return {name: config.table_rows.get(name, config.default_rows) for name in names}
