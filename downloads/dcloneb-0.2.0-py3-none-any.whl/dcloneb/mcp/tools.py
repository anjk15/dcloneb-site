"""The plain functions behind each MCP tool (plan4 M2-M4). They call `dcloneb.generate.api` and return
plain JSON. Errors come back as {"ok": false, "problems": [...]}, never as tracebacks. No MCP import here.
"""

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import polars as pl

from dcloneb.generate.api import generate as generate_bundle
from dcloneb.generate.api import preflight_rules as api_preflight
from dcloneb.generate.config import parse_config, resolve_rows
from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.plan_input import LoadedPlan, parse_plan
from dcloneb.generate.rules.contract import SCHEMA
from dcloneb.generate.rules.registry import COMBINING, NULL_BEHAVIOR, REGISTRY
from dcloneb.generate.support import FEATURES, SUPPORTED_TYPES, check_support
from dcloneb.mcp.approval import Approval, request_sha256
from dcloneb.mcp.hints import hint_for
from dcloneb.mcp.limits import Limits
from dcloneb.mcp.summary import request_details, request_summary
from dcloneb.mcp.workspace import Workspace
from dcloneb.plan import analyze

PRIVACY = ("Generation runs locally and files stay in the workspace. What tools return (schema details, rules, "
           "summaries, errors, file paths) becomes part of the conversation and reaches the agent's model provider. "
           "Generated values are returned only by preview_rows, and only when called.")

EXAMPLE_RULES = {"rules_version": 1, "rules": [
    {"id": "positive_amount", "type": "range", "table": "orders", "column": "amount",
     "min": "0", "min_inclusive": False, "null_policy": "forbid"},
    {"id": "order_status", "type": "allowed_values", "table": "orders", "column": "status",
     "values": ["pending", "paid", "cancelled"], "null_policy": "forbid"},
    {"id": "contact_email", "type": "format", "table": "customers", "column": "contact_detail",
     "format": "email", "null_policy": "allow"},
    {"id": "customer_names", "type": "value_kind", "table": "customers", "column": "full_name",
     "kind": "person_name", "null_policy": "forbid"},
]}


@dataclass
class State:
    workspace: Workspace
    limits: Limits
    plans: dict = field(default_factory=dict)  # plan_id -> analyzed plan, kept in memory only
    asked: set = field(default_factory=set)  # request hashes the user has been shown an approval form for


def _rule_types() -> dict:
    return {name: {"column_kinds": list(t.kinds), "meaning": t.meaning, "generation": t.generation}
            for name, t in REGISTRY.items()}


def get_capabilities(state: State) -> dict:
    return {
        "column_types": dict(SUPPORTED_TYPES),
        "features": [{"feature": f, "status": s, "notes": n} for f, s, n in FEATURES],
        "rule_types": _rule_types(),
        "limits": {"max_rows_per_table": state.limits.per_table, "max_rows_total": state.limits.total},
        "workspace": str(state.workspace.root),
        "privacy": PRIVACY,
    }


def get_rules_contract(state: State) -> dict:
    semantics = f"{NULL_BEHAVIOR} null_policy is required on every rule. {COMBINING}"
    return {"schema": SCHEMA, "rule_types": _rule_types(), "semantics": semantics, "example": EXAMPLE_RULES}


@dataclass(frozen=True)
class AnalyzedPlan:
    loaded: LoadedPlan
    plan_text: str  # plan.json, kept for the bundle
    ddl: str


def problems_result(error: GenerationError) -> dict:
    return {"ok": False, "problems": [{"kind": p.kind, "code": p.code, "message": p.message, "rule_ids": list(p.rule_ids),
                                       "hint": hint_for(p)} for p in error.problems]}


def _fail(code: str, message: str) -> GenerationError:
    return GenerationError([Problem("input", code, message)])


def _table_summary(table) -> dict:
    return {
        "columns": [{"name": c.name, "type": c.type, "nullable": c.nullable, "identity": c.identity} for c in table.columns],
        "primary_key": list(table.primary_key) if table.primary_key else None,
        "unique": [list(k.columns) for k in table.unique_keys],
        "foreign_keys": [{"columns": list(fk.columns), "references": {"table": fk.ref_table, "columns": list(fk.ref_columns)}}
                         for fk in table.foreign_keys],
    }


def analyze_schema(state: State, ddl: Optional[str] = None, path: Optional[str] = None) -> dict:
    """Analyze PostgreSQL DDL (text, or a .sql file inside the workspace). Nothing is written; the plan is
    kept in memory under its `plan_id` for the other tools."""
    try:
        if (ddl is None) == (path is None):
            raise _fail("schema_input_invalid", "pass exactly one of `ddl` (the SQL text) or `path` (a file in the workspace)")
        if path is not None:
            ddl = state.workspace.resolve(path, must_exist=True).read_text(encoding="utf-8")
        plan = analyze(ddl, "postgres")
        plan_text = plan.to_json()
        if plan.status == "error":
            raise GenerationError([Problem("input", d.code, d.message) for d in plan.diagnostics if d.severity == "error"])
        loaded = parse_plan(json.loads(plan_text), hashlib.sha256(plan_text.encode("utf-8")).hexdigest())
    except GenerationError as e:
        return problems_result(e)
    except UnicodeDecodeError:
        return problems_result(_fail("schema_unreadable", f"{path!r} is not UTF-8 text"))
    plan_id = loaded.sha256[:16]
    state.plans[plan_id] = AnalyzedPlan(loaded, plan_text, ddl)
    try:
        check_support(loaded)
        unsupported = []
    except GenerationError as e:
        unsupported = problems_result(e)["problems"]
    return {
        "ok": True, "plan_id": plan_id, "generation_supported": not unsupported, "unsupported": unsupported,
        "execution_order": loaded.order,
        "tables": {t.name: _table_summary(t) for t in loaded.schema.tables},
        "backfills": [{"table": b.table, "columns": list(b.fk.columns), "references": b.fk.ref_table} for b in loaded.backfills],
        "notes": [{"severity": d["severity"], "code": d["code"], "message": d["message"]} for d in loaded.diagnostics],
    }


DEFAULT_ROWS, DEFAULT_SEED, DEFAULT_NULL_PROBABILITY = 100, 42, 0.1


@dataclass(frozen=True)
class Request:
    """One fully checked generation request: what preflight accepted and what approval will cover."""
    plan: AnalyzedPlan
    config: dict  # generation.json content
    rows: dict  # table -> rows, resolved
    rules: object  # NormalizedRules, or None without rules


def _plan(state: State, plan_id: str) -> AnalyzedPlan:
    if plan_id not in state.plans:
        raise _fail("unknown_plan_id", f"no analyzed schema with plan_id {plan_id!r}; call analyze_schema first")
    return state.plans[plan_id]


def check_request(state: State, plan_id: str, rules: Optional[dict], rows: int = DEFAULT_ROWS,
                  table_rows: Optional[dict] = None, seed: int = DEFAULT_SEED,
                  null_probability: float = DEFAULT_NULL_PROBABILITY) -> Request:
    """Everything generation needs, checked: supported schema, valid config, limits, rules preflight."""
    analyzed = _plan(state, plan_id)
    check_support(analyzed.loaded)
    config = {"seed": seed, "default_rows": rows, "table_rows": dict(table_rows or {}), "null_probability": null_probability}
    resolved = resolve_rows(parse_config(config), [t.name for t in analyzed.loaded.schema.tables])
    state.limits.check(resolved)
    normalized = api_preflight(analyzed.loaded, rules, config) if rules is not None else None
    return Request(analyzed, config, resolved, normalized)


def preflight_rules(state: State, plan_id: str, rules: Optional[dict], rows: int = DEFAULT_ROWS,
                    table_rows: Optional[dict] = None, seed: int = DEFAULT_SEED,
                    null_probability: float = DEFAULT_NULL_PROBABILITY) -> dict:
    """Check rules, row counts and settings against an analyzed schema. Read-only: nothing is generated."""
    try:
        request = check_request(state, plan_id, rules, rows, table_rows, seed, null_probability)
    except GenerationError as e:
        return problems_result(e)
    return {
        "ok": True,
        "rules": request.rules.to_dict()["rules"] if request.rules else [],
        "always_null": sorted(f"{t}.{c}" for t, c in request.rules.always_null) if request.rules else [],
        "rows": request.rows, "total_rows": sum(request.rows.values()),
        "settings": {"seed": seed, "null_probability": null_probability},
    }


# --- generation (plan4 M3): prepare -> the user approves -> run ---------------------------------------

@dataclass(frozen=True)
class Prepared:
    request: Request
    output: Path
    summary: str
    sha: str  # request_sha256: what an approval is bound to
    details: Optional[dict] = None  # the same request laid out for the approval page


def prepare_generation(state: State, plan_id: str, rules: Optional[dict] = None, rows: int = DEFAULT_ROWS,
                       table_rows: Optional[dict] = None, seed: int = DEFAULT_SEED,
                       null_probability: float = DEFAULT_NULL_PROBABILITY, output: str = "generated"):
    """Check a request fully and describe it, without writing anything. Returns Prepared, or a problems
    result. Side-effect free, so it can run while asking for approval (resolvers may re-run)."""
    try:
        request = check_request(state, plan_id, rules, rows, table_rows, seed, null_probability)
        out = state.workspace.free_output(output)
    except GenerationError as e:
        return problems_result(e)
    return Prepared(request, out, request_summary(request, out), request_sha256(request, out),
                    request_details(request, out))


def run_generation(state: State, prepared: Prepared, approval: Approval, approved_sha: str) -> dict:
    """Generate only if the user approved this exact request; return paths and check results, never values."""
    if not approval.approved:
        return {"ok": False, "status": "not_approved", "message": f"nothing was generated: {approval.reason or 'not approved'}"}
    if approved_sha != prepared.sha:
        return {"ok": False, "status": "request_changed",
                "message": "the request changed after it was approved; nothing was generated. Ask again."}
    r = prepared.request
    try:
        result = generate_bundle(r.plan.loaded, r.config, prepared.output, rules=r.rules.to_dict() if r.rules else None,
                                 extra_files={"plan.json": r.plan.plan_text},
                                 manifest_extra={"approval": {"method": approval.method, "request_sha256": prepared.sha}})
    except GenerationError as e:
        return problems_result(e)
    report = json.loads((prepared.output / "validation_report.json").read_text())["serialized"]
    m = result.manifest
    return {
        "ok": True, "output": str(prepared.output),
        "files": {t: str(prepared.output / info["file"]) for t, info in m["tables"].items()},
        "rows": {t: info["rows"] for t, info in m["tables"].items()},
        "validation": {"passed": report["passed"], "checks": len(report["checks"]),
                       "rules": [{k: rule[k] for k in ("rule_id", "table", "column", "rows_evaluated", "violations")}
                                 for rule in report["rules"]]},
        "approval": {"method": approval.method, "request_sha256": prepared.sha},
    }


# --- preview (plan4 M4): the only tool that returns data values --------------------------------------

PREVIEW_MAX = 5
PREVIEW_NOTE = "These values are now part of the conversation and reach the agent's model provider."


def preview_rows(state: State, output: str, table: str, n: int = PREVIEW_MAX) -> dict:
    """Up to 5 rows of one table from a dcloneb bundle in the workspace. NULL is None; "" is an empty string."""
    try:
        if n < 1:
            raise _fail("preview_invalid", "n must be at least 1")
        folder = state.workspace.resolve(output, must_exist=True)
        manifest_path = folder / "manifest.json"
        manifest = json.loads(manifest_path.read_text()) if manifest_path.is_file() else {}
        if not str(manifest.get("generator", "")).startswith("dcloneb"):
            raise GenerationError([Problem("input", "not_a_bundle", f"{output!r} is not a dcloneb output folder")])
        if table not in manifest.get("tables", {}):
            raise _fail("unknown_table", f"{table!r} is not in {output!r}; its tables: {', '.join(sorted(manifest['tables']))}")
        csv = state.workspace.resolve(str(folder / manifest["tables"][table]["file"]), must_exist=True)
        frame = pl.read_csv(csv, infer_schema=False, n_rows=min(n, PREVIEW_MAX))  # strings; NULL stays None
    except GenerationError as e:
        return problems_result(e)
    return {"ok": True, "table": table, "columns": frame.columns, "rows": [list(r) for r in frame.rows()], "note": PREVIEW_NOTE}
