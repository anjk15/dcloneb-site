"""The plain-English summary of a generation request (plan4 M5). The same text goes to the agent and into
the user's approval form, so the user approves exactly what the agent was told.

Built from the *normalized* rules (canonical values, sorted), so rule order never changes it. Each ruled
column is one line; whether it may be empty uses the combined NULL acceptability (schema NOT NULL wins).
"""

from collections import defaultdict

MAX_LISTED = 10
KIND_WORDS = {"person_name": "people's full names", "first_name": "first names", "last_name": "last names",
              "company_name": "company names", "product_name": "product names", "category_name": "category names",
              "city": "city names", "state": "state names", "country": "country names",
              "street_address": "street addresses", "postal_code": "postal codes", "phone_number": "phone numbers",
              "url": "web addresses", "username": "usernames", "job_title": "job titles", "word": "single words",
              "sentence": "short sentences", "code": "codes like AB-1234"}


def _value(value, kind: str) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return f'"{value}"' if kind == "text" else str(value)


def _rule_phrase(rule: dict, kind: str) -> str:
    if rule["type"] == "range":
        parts = []
        if "min" in rule:
            parts.append(f"{'at least' if rule['min_inclusive'] else 'greater than'} {rule['min']}")
        if "max" in rule:
            parts.append(f"{'at most' if rule['max_inclusive'] else 'less than'} {rule['max']}")
        return " and ".join(parts)
    if rule["type"] == "allowed_values":
        values = [_value(v, kind) for v in rule["values"]]
        if len(values) == 1:
            return values[0]
        shown = ", ".join(values[:MAX_LISTED])
        return f"one of {shown}" + (f" and {len(values) - MAX_LISTED} more" if len(values) > MAX_LISTED else "")
    if rule["type"] == "value_kind":
        return KIND_WORDS[rule["kind"]]
    return "an email address"


def _reading_order(rule: dict) -> tuple:
    """Lower bounds read before upper bounds ("greater than 0 and at most 500"); then lists, then formats."""
    rank = {"range": 0 if "min" in rule else 1, "allowed_values": 2, "format": 3, "value_kind": 4}[rule["type"]]
    return rank, rule["id"]


def _column_details(table: str, column: str, rules: list[dict], domain, always_null: bool,
                    sql_nullable: bool) -> dict:
    meaning = " and ".join(_rule_phrase(r, domain.kind) for r in sorted(rules, key=_reading_order))
    if always_null:
        empty = "always empty"
    elif domain.nulls_ok:
        empty = "may be empty"
    elif not sql_nullable:
        empty = "never empty, because the schema requires a value"
    else:
        empty = "never empty"
    return {"table": table, "column": column, "meaning": meaning, "empty": empty,
            "rule_ids": sorted(r["id"] for r in rules), "always_empty": always_null}


def request_details(request, output) -> dict:
    """The request as data: what the approval page lays out. `request_summary` is the same content as text."""
    rules = []
    normalized = request.rules
    if normalized and normalized.rules:
        by_column: dict[tuple[str, str], list[dict]] = defaultdict(list)
        for rule in normalized.to_dict()["rules"]:
            by_column[(rule["table"], rule["column"])].append(rule)
        schema = request.plan.loaded.schema
        rules = [_column_details(table, column, column_rules, normalized.domains[(table, column)],
                                 (table, column) in normalized.always_null, schema.table(table).column(column).nullable)
                 for (table, column), column_rules in sorted(by_column.items())]
    return {"total_rows": sum(request.rows.values()),
            "tables": [{"name": table, "rows": n} for table, n in sorted(request.rows.items())],
            "rules": rules, "rule_count": len(normalized.rules) if normalized else 0,
            "seed": request.config["seed"], "empty_percent": round(request.config["null_probability"] * 100),
            "output": str(output)}


def _rule_line(rule: dict) -> str:
    ids = rule["rule_ids"]
    label = f"rule{'s' if len(ids) > 1 else ''} {', '.join(ids)}"
    if rule["always_empty"]:
        return f"- {rule['table']}.{rule['column']}: {rule['meaning']}, so no value fits; it will always be empty ({label})"
    return f"- {rule['table']}.{rule['column']}: {rule['meaning']}; {rule['empty']} ({label})"


def request_summary(request, output) -> str:
    d = request_details(request, output)
    lines = [f"Generate {d['total_rows']} rows on this computer, into {d['output']}:"]
    lines += [f"- {t['name']}: {t['rows']} rows" for t in d["tables"]]
    lines.append("")
    if d["rules"]:
        lines.append(f"Business rules ({d['rule_count']}):")
        lines += [_rule_line(r) for r in d["rules"]]
    else:
        lines.append("No business rules: values follow the schema only.")
    lines.append("")
    empties = ("no values are left empty" if d["empty_percent"] == 0
               else f"where a column may be empty, about {d['empty_percent']}% of its values are empty")
    lines.append(f"Settings: seed {d['seed']}; {empties}.")
    lines.append("Keys, relationships, and the schema's constraints are always kept. "
                 "Files stay in your workspace; nothing is overwritten.")
    return "\n".join(lines)
