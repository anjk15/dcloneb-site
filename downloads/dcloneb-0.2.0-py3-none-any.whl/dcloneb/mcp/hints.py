"""Hints for the agent (plan4 M8): what to do about each problem, by code, with a fallback per kind.
Agent-facing advice lives here, not in the core, so the CLI's messages stay exactly as they are."""

from dcloneb.generate.errors import Problem

HINTS = {
    # rules.json shape
    "rules_invalid_json": "Send rules as a JSON object matching get_rules_contract.",
    "rules_malformed": "Fix the named field so the rule matches the schema from get_rules_contract; don't add fields it doesn't define.",
    "rules_unreadable": "Check that the rules file exists in the workspace.",
    "rules_unsupported_version": "Use \"rules_version\": 1.",
    "rule_duplicate_id": "Give every rule its own id.",
    "rule_type_unsupported": "Only range, allowed_values, format, and value_kind exist. Explain to the user that this request isn't "
                             "supported yet (see get_capabilities) and offer the closest supported rule.",
    "rule_format_unsupported": "Only format \"email\" is supported; explain this to the user.",
    "rule_kind_unsupported": "Use a kind from get_rules_contract (e.g. product_name, person_name, city); for anything "
                             "else, leave the column without a value_kind.",
    "rule_kind_conflict": "A column can have one value_kind, and not together with format email; ask the user which fits.",
    # rules against the schema
    "rule_unknown_table": "Use a table name exactly as analyze_schema lists it.",
    "rule_unknown_column": "Use a column name exactly as analyze_schema lists it.",
    "rule_type_mismatch": "This rule type doesn't fit the column's type (see get_rules_contract: column_kinds); pick another "
                          "rule or ask the user what they meant.",
    "rule_value_invalid": "Write values in the column's form: JSON integers for integer columns, decimal strings like "
                          "\"19.99\" for decimals, strings for text, true/false for booleans; and make them fit the column.",
    "rule_precision_unsupported": "Use at most 6 decimals for this NUMERIC column.",
    "rule_target_unsupported": "Rules can't target key columns (primary, identity, foreign, referenced) or CHAR(n) columns. "
                               "Keys and relationships are already enforced; explain this and remove the rule.",
    # rules against each other and the row counts
    "rule_conflict": "These rules together allow no value. Ask the user which one to change, or allow NULL (null_policy "
                     "\"allow\") if an empty value is acceptable.",
    "rule_unsatisfiable": "No value of this column can satisfy the rule; ask the user to change it.",
    "rule_domain_capacity": "The unique column needs more distinct values than the rules allow: ask for fewer rows or "
                            "allow more values.",
    # MCP layer
    "row_limit_exceeded": "Ask for fewer rows; the limits are set when dcloneb is installed.",
    "unknown_plan_id": "Call analyze_schema first and use the plan_id it returns.",
    "schema_input_invalid": "Pass either ddl (the CREATE TABLE text) or path (a .sql file in the workspace), not both.",
    "schema_unreadable": "The schema file must be UTF-8 text.",
    "workspace_path_outside": "Only files inside the user's dcloneb workspace can be used; ask the user to put the file there.",
    "workspace_path_missing": "Check the file name; paths are relative to the workspace.",
    "workspace_name_invalid": "Use letters, digits, '.', '_' or '-' for the output name.",
    "unknown_table": "Use table names exactly as analyze_schema lists them.",
    "not_a_bundle": "Pass the output folder that generate_data returned.",
    "preview_invalid": "Ask for between 1 and 5 rows.",
    "generator_capacity": "dcloneb's generator can't produce enough distinct values here (a valid dataset may exist): ask "
                          "for fewer rows or wider rules.",
    "unsupported_type": "Explain that this column type isn't supported yet (see get_capabilities); the schema can't be "
                        "generated as is.",
}

FALLBACK = {
    "input": "Fix the input named in the message, or ask the user.",
    "unsupported": "Explain to the user that this isn't supported yet (see get_capabilities).",
    "impossible": "No valid dataset exists for this request; ask the user what to change (rows or rules).",
    "retry_exhausted": "Try again with another seed or fewer rows; this is not proof that no dataset exists.",
    "validation_failed": "This is a dcloneb bug: nothing was published. Tell the user and include the message.",
}


def hint_for(problem: Problem) -> str:
    return HINTS.get(problem.code, FALLBACK[problem.kind])
