"""The dcloneb MCP server (plan4): tools that wrap `dcloneb.generate.api`, run locally over stdio.

The only module that imports the `mcp` SDK (installed with `dcloneb[mcp]`).
"""

import json
import secrets
import time
import webbrowser
from dataclasses import dataclass
from typing import Annotated, Any, Optional

from mcp.server.mcpserver import Context, Elicit, MCPServer, Resolve
from mcp.types import ToolAnnotations
from pydantic import BaseModel, Field

from dcloneb import __version__
from dcloneb.generate.rules.contract import SCHEMA
from dcloneb.generate.rules.registry import COMBINING, NULL_BEHAVIOR, render_rules_table
from dcloneb.generate.support import render_matrix
from dcloneb.mcp import tools
from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.mcp.approval import Approval
from dcloneb.mcp.approval_page import ApprovalPage
from dcloneb.mcp.limits import Limits
from dcloneb.mcp.workflow import INSTRUCTIONS, create_test_data_prompt
from dcloneb.mcp.workspace import Workspace

class Approve(BaseModel):
    """The approval form the client shows the user."""
    approve: bool = Field(title="Approve", description="Tick to generate exactly the data described above")


@dataclass(frozen=True)
class NotAsked:
    reason: str  # problems | no_user_channel | local_page


WRITES_NEW_FILES = ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=False, open_world_hint=False)
def _pending(request_id: str, page: ApprovalPage, summary: str) -> dict[str, Any]:
    return {"ok": False, "status": "pending_approval", "request_id": request_id, "approval_url": page.url,
            "summary": summary,
            "message": "Nothing generated yet. The user must approve on the page that opened in their browser "
                       "(or open approval_url); then call generate_data again with the same arguments and request_id."}


READ_ONLY = ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=False)


def build_server(workspace: Workspace, limits: Limits, opener=webbrowser.open, clock=time.monotonic) -> MCPServer:
    """`opener` opens the local approval page in the user's browser; tests pass a no-op."""
    state = tools.State(workspace, limits)
    pending: dict[str, tuple[ApprovalPage, str]] = {}  # request_id -> (local approval page, request hash)

    def page_flow(prepared: tools.Prepared, request_id: Optional[str]) -> dict[str, Any]:
        """The fallback for clients without approval forms: the user approves on a local page, then the agent
        calls again with request_id. Generates only the exact request the user approved."""
        if request_id is None:
            page = ApprovalPage(prepared.summary, prepared.sha, opener=opener, clock=clock,
                                details=prepared.details)
            try:
                page.start()
            except OSError as e:
                return {"ok": False, "status": "approval_unavailable",
                        "message": f"couldn't open a local approval page ({e}); nothing was generated"}
            request_id = secrets.token_hex(8)
            pending[request_id] = (page, prepared.sha)
            return _pending(request_id, page, prepared.summary)
        if request_id not in pending:
            return tools.problems_result(GenerationError([Problem(
                "input", "unknown_request_id", f"no pending approval {request_id!r}; call generate_data without request_id")]))
        page, approved_sha = pending[request_id]
        if approved_sha != prepared.sha:
            del pending[request_id]
            page.close()
            return {"ok": False, "status": "request_changed",
                    "message": "these arguments differ from the request the user was asked about; nothing was generated"}
        decision = page.decision
        if decision is None:
            return _pending(request_id, page, prepared.summary)
        del pending[request_id]
        page.close()
        if decision == "expired":
            return {"ok": False, "status": "expired", "message": "the approval link expired; nothing was generated"}
        return tools.run_generation(state, prepared, Approval(decision == "approved", "local_page",
                                                              "the user declined on the approval page"), prepared.sha)
    server = MCPServer(name="dcloneb", version=__version__, instructions=INSTRUCTIONS, log_level="WARNING")

    @server.tool(annotations=READ_ONLY)
    def get_capabilities() -> dict[str, Any]:
        """What dcloneb supports: column types, schema features, rule types, row limits, and the privacy note."""
        return tools.get_capabilities(state)

    @server.tool(annotations=READ_ONLY)
    def get_rules_contract() -> dict[str, Any]:
        """The rules.json contract: its JSON Schema, what each rule type means, and an example. Draft rules only from this."""
        return tools.get_rules_contract(state)

    @server.tool(annotations=READ_ONLY)
    def analyze_schema(ddl: Optional[str] = None, path: Optional[str] = None) -> dict[str, Any]:
        """Analyze a PostgreSQL schema: pass `ddl` (the CREATE TABLE text) or `path` (a .sql file inside the
        workspace). Returns a plan_id and a summary of tables, keys, and relationships. Writes nothing."""
        return tools.analyze_schema(state, ddl=ddl, path=path)

    @server.tool(annotations=READ_ONLY)
    def preflight_rules(plan_id: str, rules: Optional[dict[str, Any]] = None, rows: int = tools.DEFAULT_ROWS,
                        table_rows: Optional[dict[str, int]] = None, seed: int = tools.DEFAULT_SEED,
                        null_probability: float = tools.DEFAULT_NULL_PROBABILITY) -> dict[str, Any]:
        """Check business rules (rules.json, optional) and row counts against an analyzed schema, before
        generating. Returns the normalized rules and resolved rows, or problems to resolve. Writes nothing."""
        return tools.preflight_rules(state, plan_id, rules, rows, table_rows, seed, null_probability)

    def ask_user(plan_id: str, ctx: Context, rules: Optional[dict[str, Any]] = None, rows: int = tools.DEFAULT_ROWS,
                 table_rows: Optional[dict[str, int]] = None, seed: int = tools.DEFAULT_SEED,
                 null_probability: float = tools.DEFAULT_NULL_PROBABILITY, output: str = "generated",
                 request_id: Optional[str] = None):
        """Resolver for `approval`: describe the request and ask the *user* through the client's own UI.
        Never returns an outcome object of its own (the SDK would coerce it into an acceptance; plan4 M0)."""
        if request_id is not None:
            return NotAsked("local_page")  # a second call for a page approval: don't ask again here
        prepared = tools.prepare_generation(state, plan_id, rules, rows, table_rows, seed, null_probability, output)
        if not isinstance(prepared, tools.Prepared):
            return NotAsked("problems")  # the tool body returns those problems; the user is never asked
        caps = ctx.client_capabilities
        if not (caps and caps.elicitation):
            return NotAsked("no_user_channel")
        state.asked.add(prepared.sha)  # idempotent: the body generates only a request that was shown to the user
        return Elicit(f"{prepared.summary}\n\nApprove generating this data? (request {prepared.sha[:12]})", Approve)

    @server.tool(annotations=WRITES_NEW_FILES)
    def generate_data(plan_id: str, approval: Annotated[Any, Resolve(ask_user)], rules: Optional[dict[str, Any]] = None,
                      rows: int = tools.DEFAULT_ROWS, table_rows: Optional[dict[str, int]] = None,
                      seed: int = tools.DEFAULT_SEED, null_probability: float = tools.DEFAULT_NULL_PROBABILITY,
                      output: str = "generated", request_id: Optional[str] = None) -> dict[str, Any]:
        """Generate test data locally into a new folder in the workspace (never overwriting). The user is asked
        to approve a plain-English summary first, in Claude Desktop's own form; nothing is written without that.
        If the result is pending_approval, give the user the approval_url (it also opens in their browser), and
        after they approve call generate_data again with the same arguments plus request_id.
        Returns file paths, row counts, and check results, not data values."""
        prepared = tools.prepare_generation(state, plan_id, rules, rows, table_rows, seed, null_probability, output)
        if not isinstance(prepared, tools.Prepared):
            return prepared  # problems, found before asking anyone
        if request_id is not None or (isinstance(approval, NotAsked) and approval.reason == "no_user_channel"):
            return page_flow(prepared, request_id)
        approved = isinstance(approval, Approve) and approval.approve is True and prepared.sha in state.asked
        state.asked.discard(prepared.sha)
        decision = Approval(approved, "elicitation", "" if approved else "the user didn't approve")
        return tools.run_generation(state, prepared, decision, prepared.sha if approved else "")

    @server.resource("dcloneb://rules/schema.json", mime_type="application/json",
                     description="The rules.json JSON Schema (version 1). Rules must validate against it.")
    def rules_schema() -> str:
        return json.dumps(SCHEMA, indent=2)

    @server.resource("dcloneb://rules/semantics.md", mime_type="text/markdown",
                     description="What each rule type means, how NULL policies work, and how rules combine.")
    def rules_semantics() -> str:
        return f"# dcloneb rule semantics\n\n{render_rules_table()}\n\n**NULL policy.** {NULL_BEHAVIOR}\n\n**Combining.** {COMBINING}\n"

    @server.resource("dcloneb://support-matrix.md", mime_type="text/markdown",
                     description="Supported column types, schema features, and plan diagnostics.")
    def support_matrix() -> str:
        return f"# dcloneb support matrix\n\n{render_matrix()}\n"

    @server.resource("dcloneb://rules/example.json", mime_type="application/json",
                     description="An example rules.json with one rule of each type.")
    def rules_example() -> str:
        return json.dumps(tools.EXAMPLE_RULES, indent=2)

    @server.prompt(name="create_test_data", description="Create test data from a schema and a plain-language request.")
    def create_test_data(request: str = "", schema: str = "") -> str:
        return create_test_data_prompt(request, schema)

    @server.tool(annotations=READ_ONLY)
    def preview_rows(output: str, table: str, n: int = tools.PREVIEW_MAX) -> dict[str, Any]:
        """Show up to 5 generated rows of one table. Only call this when the user asks to see data: the values
        are sent to the model provider. Other tools return only summaries, counts, and file paths."""
        return tools.preview_rows(state, output, table, n)

    return server
