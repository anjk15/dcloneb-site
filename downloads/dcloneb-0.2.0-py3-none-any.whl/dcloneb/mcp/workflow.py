"""The agent workflow (plan4 M6): instructions sent at initialization, and the create_test_data prompt.

dcloneb never calls a language model: the agent translates the user's request into rules.json, and
dcloneb's preflight and validator are the safety net. These instructions keep that translation honest.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class Guide:
    """A common request and what the agent should do. `rules` + `expect_code` are checked against real preflight
    by the tests (None = accepted), so this guidance can't drift from what dcloneb accepts."""
    request: str
    response: str  # ask | rule | unsupported | schema_enforces
    advice: str
    rules: list = field(default_factory=list)
    expect_code: Optional[str] = None


GUIDANCE_SCHEMA = """
CREATE TABLE customers (id SERIAL PRIMARY KEY, email VARCHAR(100) NOT NULL UNIQUE, contact_detail VARCHAR(60));
CREATE TABLE products (id SERIAL PRIMARY KEY, name VARCHAR(80));
CREATE TABLE orders (id SERIAL PRIMARY KEY, customer_id INT NOT NULL REFERENCES customers (id),
                     price NUMERIC(10, 2), discount NUMERIC(10, 2), status TEXT, placed_at TIMESTAMP);
"""


def _rule(id, table, column, **fields):
    return {"id": id, "table": table, "column": column, **fields}


GUIDANCE = [
    Guide("prices between 10 and 20", "ask",
          "ask whether 10 and 20 themselves are allowed, and whether price may be empty; then write a range rule",
          [_rule("price_band", "orders", "price", type="range", min="10", min_inclusive=True, max="20", max_inclusive=True,
                 null_policy="forbid")]),
    Guide("status is pending, paid, or cancelled", "ask",
          "ask whether status may be empty (null_policy); then write an allowed_values rule with exactly those values",
          [_rule("status", "orders", "status", type="allowed_values", values=["pending", "paid", "cancelled"],
                 null_policy="forbid")]),
    Guide("contact_detail holds email addresses", "rule",
          "write a format rule with format email; ask whether it may be empty",
          [_rule("contact", "customers", "contact_detail", type="format", format="email", null_policy="allow")]),
    Guide("orders placed after 2020", "unsupported",
          "explain that date and timestamp ranges aren't supported yet; don't write a rule for it",
          [_rule("recent", "orders", "placed_at", type="range", min=2020, min_inclusive=False, null_policy="allow")],
          "rule_type_unsupported"),
    Guide("discount is less than price", "unsupported",
          "explain that rules comparing two columns aren't supported yet; offer a fixed range on discount instead"),
    Guide("customer_id must be a real customer", "schema_enforces",
          "explain that foreign keys are always enforced already; rules on key columns are rejected",
          [_rule("real_customer", "orders", "customer_id", type="range", min=1, min_inclusive=True, null_policy="forbid")],
          "rule_target_unsupported"),
    Guide("product names should look like products", "rule",
          "write a value_kind rule with kind product_name for that column; value kinds also work for any column name "
          "whose meaning you can tell from the schema",
          [_rule("product_names", "products", "name", type="value_kind", kind="product_name", null_policy="forbid")]),
    Guide("unique emails", "schema_enforces",
          "explain that uniqueness comes from the schema (customers.email is UNIQUE); there's no uniqueness rule type"),
]


def _guidance_lines() -> str:
    return "\n".join(f'- "{g.request}": {g.advice}.' for g in GUIDANCE)


INSTRUCTIONS = """\
dcloneb generates synthetic test data locally from a PostgreSQL schema and optional business rules (rules.json).
Files stay on the user's computer, in their dcloneb workspace. Work in this order:

1. Schema: call analyze_schema with the user's CREATE TABLE text (ddl) or a .sql file in the workspace (path).
   If it reports problems or generation_supported is false, explain them plainly; don't work around them.
2. Rules: if the user describes constraints on values, call get_rules_contract and write rules.json using only
   the rule types, fields, and value forms it defines (range, allowed_values, format: email, value_kind). Never invent rule
   types, operators, or fields. If a request is unsupported (date ranges, cross-column or conditional rules,
   rules on key columns), say so and offer the closest supported alternative.
   Give each text column whose meaning is clear from the schema a value_kind rule (e.g. products.name -> product_name,
   vendors.title -> company_name), so the data reads naturally; if a column's meaning isn't clear, ask the user.
3. When the meaning is missing, ask the user instead of guessing: null_policy is required on every rule (may the
   value be empty?), and ask about inclusive vs exclusive bounds, exact allowed values, and row counts if unclear.
4. Check: call preflight_rules. If it returns problems, explain each one in plain words (they name the rule ids)
   and resolve them with the user before going on.
5. Summary: show the user the tables, row counts, and every rule in plain English, and confirm it's what they want.
6. Generate: call generate_data with exactly what was checked. dcloneb then asks the user to approve the summary
   themselves, in Claude Desktop's own form; it generates nothing without that approval. If it returns
   pending_approval, an approval page has opened in the user's browser: give them approval_url, wait until they
   say they approved, then call generate_data again with the same arguments plus request_id. If it returns
   approval_unavailable, tell the user approval couldn't be shown. Report the folder and file paths.

Never edit, move, or delete files yourself, and never claim data was generated unless generate_data says ok.
Privacy: everything tools return (schema details, rules, summaries, errors, paths) reaches the model provider as
part of this conversation. Data values are returned only by preview_rows: call it only when the user asks to see
rows, and say that the values will be shared with the model provider.

Common requests and what to do:
""" + _guidance_lines()


def create_test_data_prompt(request: str = "", schema: str = "") -> str:
    parts = [INSTRUCTIONS, "", "The user's request:", request or "(ask the user what data they need)"]
    if schema:
        parts += ["", f"Their schema: {schema} (a workspace path, or paste the CREATE TABLE text into analyze_schema)."]
    parts += ["", "Start with step 1 (analyze_schema)."]
    return "\n".join(parts)
