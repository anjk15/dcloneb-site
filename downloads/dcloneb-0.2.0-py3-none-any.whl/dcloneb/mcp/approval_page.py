"""The local approval page (plan4 M9): the fallback channel for clients that can't show an approval form.

A one-time page on 127.0.0.1 shows the plain-English summary; the *user* clicks Approve or Decline in their
own browser. Guards:
- loopback only;
- an unguessable URL token, and a separate CSRF token on the form;
- the Host header must be this server (blocks DNS rebinding);
- single use, and expiry after `ttl` seconds;
- the summary is HTML-escaped.

Stated limit (plan4): an agent that also has browser-automation or shell tools could act on this page.
"""

import html
import secrets
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Optional

TTL_SECONDS = 600

STYLE = """
  body { font: 16px/1.55 system-ui, sans-serif; max-width: 44rem; margin: 2rem auto; padding: 0 1rem; color: #1a1a1a;
         background: #fff; }
  h1 { font-size: 1.6rem; line-height: 1.25; margin-bottom: .3rem; }
  h2 { font-size: 1.05rem; margin: 1.8rem 0 .5rem; }
  .lede { color: #444; margin-top: 0; }
  table { border-collapse: collapse; min-width: 16rem; }
  td { padding: .3rem 1.2rem .3rem 0; border-bottom: 1px solid #e5e5e5; }
  td.n { text-align: right; font-variant-numeric: tabular-nums; }
  tfoot td { border: 0; font-weight: 600; }
  code { background: #f2f2f2; padding: .1rem .35rem; border-radius: 4px; word-break: break-all; }
  ul.rules { padding-left: 1.2rem; } ul.rules li { margin: .35rem 0; }
  .ids { color: #777; font-size: .85rem; }
  .warn { color: #8a3b00; }
  .note { color: #555; font-size: .95rem; }
  .check { background: #fff8e1; border: 1px solid #f0d27a; border-radius: 8px; padding: .8rem 1.2rem; margin-top: 1.8rem; }
  .check h2 { margin-top: .2rem; } .check ol { margin: .3rem 0; padding-left: 1.3rem; } .check li { margin: .3rem 0; }
  form { margin: 1.6rem 0; display: flex; flex-wrap: wrap; gap: .7rem; }
  button { font-size: 1rem; padding: .7rem 1.3rem; border-radius: 8px; border: 1px solid #888; background: #fff;
           cursor: pointer; }
  .approve { background: #1f6f43; color: #fff; border-color: #1f6f43; font-weight: 600; }
  details { margin-top: 1.5rem; color: #444; } pre { white-space: pre-wrap; background: #f4f4f4; padding: 1rem;
  border-radius: 6px; font-size: .9rem; }
  footer { color: #777; font-size: .85rem; margin-top: 1.5rem; }
"""

PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>dcloneb: approve test data</title>
<style>{style}</style></head>
<body>
<h1>Claude wants to create test data on your computer</h1>
<p class="lede">Nothing is created until you approve. Only you can approve, here in your browser.</p>
{body}
<div class="check">
  <h2>Before you approve, check</h2>
  <ol>
    <li>The tables and row counts are what you asked for.</li>
    <li>The rules match what you meant. A wrong rule means wrong data.</li>
    <li>The folder is where you want the files. Existing files are never overwritten.</li>
  </ol>
  <p>If anything looks wrong, click <strong>Decline</strong> and tell Claude what to change.</p>
</div>
<form method="post">
  <input type="hidden" name="csrf" value="{csrf}">
  <button class="approve" name="decision" value="approve">Approve and create the data</button>
  <button name="decision" value="decline">Decline</button>
</form>
<details><summary>The exact request Claude received</summary><pre>{summary}</pre></details>
<footer>Request {request}. This page works once and expires in {minutes} minutes.</footer>
</body></html>
"""

DONE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>dcloneb</title></head>
<body style="font: 16px/1.55 system-ui, sans-serif; max-width: 44rem; margin: 2rem auto; padding: 0 1rem">
<h1>{title}</h1><p>{text}</p></body></html>
"""

APPROVED = ("Now go back to Claude and tell it you approved. It will create the data and show you where the files are. "
            "You can close this tab.")
DECLINED = "Nothing was created. Go back to Claude and tell it what to change. You can close this tab."


def _e(value) -> str:
    return html.escape(str(value))


def _rule_item(rule: dict) -> str:
    ids = rule["rule_ids"]
    label = f'<span class="ids">(rule{"s" if len(ids) > 1 else ""} {_e(", ".join(ids))})</span>'
    where = f"<strong>{_e(rule['table'])} → {_e(rule['column'])}:</strong>"
    if rule["always_empty"]:
        return (f'<li class="warn">{where} {_e(rule["meaning"])}. No value fits these rules, so this column will '
                f"always be empty. {label}</li>")
    empty = "sometimes empty" if rule["empty"] == "may be empty" else "always filled in"
    return f"<li>{where} {_e(rule['meaning'])}, {empty} {label}</li>"


def render_details(d: dict) -> str:
    """What will be created, the rules in plain words, and what is always kept."""
    rows = "".join(f'<tr><td>{_e(t["name"])}</td><td class="n">{t["rows"]:,} rows</td></tr>' for t in d["tables"])
    out = [f"<h2>What will be created</h2><table><tbody>{rows}</tbody>"
           f'<tfoot><tr><td></td><td class="n">{d["total_rows"]:,} rows in total</td></tr></tfoot></table>',
           f"<p>Files go into this folder: <code>{_e(d['output'])}</code></p>",
           "<h2>Rules for the values</h2>"]
    if d["rules"]:
        out.append(f'<ul class="rules">{"".join(_rule_item(r) for r in d["rules"])}</ul>')
    else:
        out.append("<p>No business rules: values only follow your schema.</p>")
    empties = ("No values are left empty." if d["empty_percent"] == 0
               else f"Where a column may be empty, about {d['empty_percent']}% of its values are empty.")
    out.append(f'<p class="note">Always kept: keys, relationships between tables, and your schema\'s constraints. '
               f"{empties} Seed {_e(d['seed'])}: the same request always gives the same data.</p>")
    return "\n".join(out)


class ApprovalPage:
    def __init__(self, summary: str, request_sha: str, opener: Callable[[str], object] = webbrowser.open,
                 clock: Callable[[], float] = time.monotonic, ttl: float = TTL_SECONDS, details: Optional[dict] = None):
        """`details` (summary.request_details) lays the request out readably; `summary` is the same as text."""
        self.summary, self.request_sha, self.details = summary, request_sha, details
        self.opener, self.clock, self.ttl = opener, clock, ttl
        self.token = secrets.token_urlsafe(32)
        self.csrf = secrets.token_urlsafe(32)
        self.host = "127.0.0.1"
        self._decision: Optional[str] = None  # approved | declined
        self._lock = threading.Lock()
        self._server: Optional[ThreadingHTTPServer] = None
        self._started = 0.0

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self._server.server_port}/approve/{self.token}"

    @property
    def expired(self) -> bool:
        return self.clock() - self._started > self.ttl

    @property
    def decision(self) -> Optional[str]:
        """approved | declined | expired | None (still waiting)."""
        with self._lock:
            if self._decision is None and self.expired:
                return "expired"
            return self._decision

    def start(self) -> str:
        page = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):  # stdout belongs to the MCP stdio transport: never print
                pass

            def _send(self, status: int, body: str) -> None:
                data = body.encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'")
                self.end_headers()
                self.wfile.write(data)

            def _guard(self) -> bool:
                expected_host = f"{page.host}:{page._server.server_port}"
                if self.headers.get("Host") != expected_host or self.path != f"/approve/{page.token}":
                    self._send(403, DONE.format(title="Not allowed", text="This link isn't valid."))
                    return False
                with page._lock:
                    used = page._decision is not None
                if used or page.expired:
                    self._send(410, DONE.format(title="This approval link is no longer valid",
                                                text="It was already used or it expired. Ask the agent to try again."))
                    return False
                return True

            def do_GET(self):
                if self._guard():
                    body = render_details(page.details) if page.details else f"<pre>{_e(page.summary)}</pre>"
                    self._send(200, PAGE.format(style=STYLE, body=body, summary=_e(page.summary), csrf=page.csrf,
                                                request=page.request_sha[:12], minutes=int(page.ttl // 60)))

            def do_POST(self):
                if not self._guard():
                    return
                length = min(int(self.headers.get("Content-Length") or 0), 4096)
                form = urllib.parse.parse_qs(self.rfile.read(length).decode("utf-8", "replace"))
                if not secrets.compare_digest(form.get("csrf", [""])[0], page.csrf):
                    self._send(403, DONE.format(title="Not allowed", text="This form isn't valid."))
                    return
                choice = form.get("decision", [""])[0]
                if choice not in ("approve", "decline"):
                    self._send(400, DONE.format(title="Unknown choice", text="Choose Approve or Decline."))
                    return
                with page._lock:
                    if page._decision is None:
                        page._decision = "approved" if choice == "approve" else "declined"
                if choice == "approve":
                    self._send(200, DONE.format(title="Approved", text=APPROVED))
                else:
                    self._send(200, DONE.format(title="Declined", text=DECLINED))

        self._server = ThreadingHTTPServer((self.host, 0), Handler)
        self._started = self.clock()
        threading.Thread(target=self._server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True).start()
        self.opener(self.url)
        return self.url

    def close(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
