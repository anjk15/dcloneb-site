"""Assemble and serialize the plan (plan Phase 10).

`analyze` runs read → resolve → eligibility/graph → cycle breaking → order → relationships and
returns planning metadata only: nothing here touches a database or writes data.
"""

import json
from dataclasses import dataclass
from typing import Optional

from dcloneb import __version__
from dcloneb.backfill import Backfill, break_cycles
from dcloneb.dialects import read_ddl
from dcloneb.eligibility import fk_eligibility
from dcloneb.graph import build_graph
from dcloneb.model import Diagnostic, Schema, Table
from dcloneb.order import execution_order
from dcloneb.relationships import ManyToMany, Relationship, many_to_many, relationships, unique_columns, unique_combinations
from dcloneb.resolve import resolve

FORMAT_VERSION = 1


@dataclass
class Plan:
    dialect: str
    schema: Schema  # resolved
    backfills: list[Backfill]
    execution_order: Optional[list[str]]  # None when there are errors
    relationships: list[Relationship]
    many_to_many: list[ManyToMany]
    diagnostics: list[Diagnostic]

    @property
    def status(self) -> str:
        return "error" if any(d.severity == "error" for d in self.diagnostics) else "ok"

    def _table(self, table: Table) -> dict:
        foreign_keys = []
        for fk in table.foreign_keys:
            e = fk_eligibility(self.schema, table, fk)
            foreign_keys.append({
                "name": fk.name,
                "columns": list(fk.columns),
                "references": {"table": fk.ref_table, "columns": list(fk.ref_columns)},
                "match": fk.match,
                "deferrable": fk.deferrable,
                "initially_deferred": fk.initially_deferred,
                "optional": fk.can_be_null(table),
                "backfill_eligible": e.eligible,
                "ineligible_reasons": {col: list(reasons) for col, reasons in e.reasons.items()},
            })
        return {
            "columns": [{"name": c.name, "type": c.type, "nullable": c.nullable, "generated": c.generated,
                         "type_info": {"name": c.type_name, "params": list(c.type_params)}, "identity": c.identity,
                         "has_default": c.has_default, "collation": c.collation} for c in table.columns],
            "primary_key": list(table.primary_key) if table.primary_key else None,
            "unique_columns": unique_columns(table),
            "unique_combinations": unique_combinations(table),
            "unique_keys": sorted(({"columns": list(k.columns), "nulls_distinct": k.nulls_distinct} for k in table.unique_keys),
                                  key=lambda k: (k["columns"], k["nulls_distinct"])),
            "checks": list(table.checks),
            "foreign_keys": foreign_keys,
        }

    def to_dict(self) -> dict:
        ok = self.status == "ok"
        return {
            "format_version": FORMAT_VERSION,
            "tool": f"dcloneb {__version__}",
            "dialect": self.dialect,
            "status": self.status,
            "execution_order": self.execution_order if ok else None,
            "backfill": [b.to_dict() for b in self.backfills] if ok else None,
            "tables": {t.name: self._table(t) for t in self.schema.tables},
            "relationships": [
                {"kind": r.kind, "from": {"table": r.from_table, "columns": list(r.from_columns)},
                 "to": {"table": r.to_table, "columns": list(r.to_columns)}, "optional": r.optional,
                 "foreign_key": r.foreign_key}
                for r in self.relationships
            ],
            "many_to_many": [
                {"junction": m.junction, "tables": list(m.tables),
                 "via": [{"columns": list(cols), "references": parent} for cols, parent in m.via]}
                for m in self.many_to_many
            ],
            "diagnostics": [
                {"severity": d.severity, "code": d.code, "message": d.message,
                 "location": {"statement": d.statement, "line": d.line}}
                for d in self.diagnostics
            ],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, indent=2) + "\n"


def analyze(sql: str, dialect: str) -> Plan:
    schema = resolve(read_ddl(sql, dialect))
    cycles = break_cycles(build_graph(schema))
    links, link_diagnostics = many_to_many(schema)
    diagnostics = list(schema.diagnostics) + cycles.diagnostics + link_diagnostics
    has_errors = any(d.severity == "error" for d in diagnostics)
    return Plan(
        dialect=dialect.strip().lower(),
        schema=schema,
        backfills=cycles.backfills,
        execution_order=execution_order(cycles.active, errors=has_errors),
        relationships=relationships(schema),
        many_to_many=links,
        diagnostics=diagnostics,
    )
