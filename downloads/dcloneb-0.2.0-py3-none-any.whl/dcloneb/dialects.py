"""Dialect registry: which SQL dialects are supported, planned, or unknown (plan 3.1-3.2)."""

from typing import Callable

from dcloneb.model import Schema
from dcloneb.readers.postgres import read_postgres

SUPPORTED: dict[str, Callable[[str], Schema]] = {"postgres": read_postgres}
PLANNED = ("databricks", "snowflake")


class UnsupportedDialect(ValueError):
    """The dialect is planned but not implemented, or not known at all."""


def check_dialect(dialect: str) -> str:
    """The normalized dialect name, or UnsupportedDialect if it's planned or unknown."""
    name = dialect.strip().lower()
    if name in SUPPORTED:
        return name
    supported = ", ".join(sorted(SUPPORTED))
    if name in PLANNED:
        raise UnsupportedDialect(f"dialect '{name}' is planned, not implemented yet; supported: {supported}")
    raise UnsupportedDialect(f"unknown dialect '{name}'; supported: {supported}; planned: {', '.join(PLANNED)}")


def read_ddl(sql: str, dialect: str) -> Schema:
    return SUPPORTED[check_dialect(dialect)](sql)
