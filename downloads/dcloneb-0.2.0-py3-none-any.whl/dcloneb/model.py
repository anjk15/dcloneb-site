"""Dialect-free model of the tables, keys and foreign keys read from DDL (plan Phase 2)."""

from dataclasses import dataclass, field
from typing import Optional

MATCH_TYPES = ("simple", "full")  # MATCH PARTIAL is rejected by the reader (Postgres doesn't implement it)


@dataclass(frozen=True)
class Column:
    name: str
    type: str
    nullable: bool
    generated: bool = False
    type_name: str = ""  # sqlglot DataType name, e.g. "DECIMAL" (plan2 G1)
    type_params: tuple = ()  # type parameters in order, ints where numeric, e.g. (10, 2)
    identity: Optional[str] = None  # "always" | "by_default" | "serial"
    has_default: bool = False
    collation: Optional[str] = None


# Where something was defined in the DDL (statement number, line). Excluded from equality.
def _location():
    return field(default=None, compare=False)


@dataclass(frozen=True)
class Key:
    columns: tuple[str, ...]
    nulls_distinct: bool = True  # False for UNIQUE NULLS NOT DISTINCT
    statement: Optional[int] = _location()
    line: Optional[int] = _location()


@dataclass(frozen=True)
class ForeignKey:
    name: Optional[str]
    columns: tuple[str, ...]
    ref_table: str
    ref_columns: Optional[tuple[str, ...]]  # None until resolved to the referenced table's PK (Phase 4)
    match: str = "simple"  # Postgres default
    deferrable: bool = False
    initially_deferred: bool = False
    statement: Optional[int] = _location()
    line: Optional[int] = _location()

    def __post_init__(self):
        if self.match not in MATCH_TYPES:
            raise ValueError(f"match must be 'simple' or 'full', got {self.match!r}")

    def can_be_null(self, table: "Table") -> bool:
        """Whether a row may skip this FK. MATCH SIMPLE: any FK column NULL is enough; MATCH FULL: all must be NULL."""
        nullable = []
        for name in self.columns:
            column = table.column(name)
            if column is None:
                raise KeyError(f"{table.name} has no column {name!r}")
            nullable.append(column.nullable)
        return all(nullable) if self.match == "full" else any(nullable)


@dataclass(frozen=True)
class Table:
    name: str
    columns: tuple[Column, ...]
    primary_key: Optional[tuple[str, ...]] = None
    unique_keys: tuple[Key, ...] = ()
    foreign_keys: tuple[ForeignKey, ...] = ()
    check_columns: frozenset[str] = field(default_factory=frozenset)
    checks: tuple[str, ...] = ()  # CHECK expressions as SQL text, in declared order
    statement: Optional[int] = _location()
    line: Optional[int] = _location()

    def column(self, name: str) -> Optional[Column]:
        return next((c for c in self.columns if c.name == name), None)

    def keys(self) -> list[tuple[str, ...]]:
        """Column sets of the PK and every unique key."""
        return ([self.primary_key] if self.primary_key else []) + [k.columns for k in self.unique_keys]

    def is_unique(self, columns) -> bool:
        """True if some PK/unique key is a subset of `columns`, so those columns together are unique."""
        wanted = set(columns)
        return any(set(key) <= wanted for key in self.keys())


SEVERITIES = ("error", "warning", "info")


@dataclass(frozen=True)
class Diagnostic:
    severity: str  # error: the plan can't be trusted; warning: construct not modeled; info: recognized, not used
    code: str  # stable identifier, e.g. "fk_unknown_table"
    message: str
    statement: Optional[int] = None  # 1-based statement number in the DDL file
    line: Optional[int] = None  # 1-based line in the DDL file

    def __post_init__(self):
        if self.severity not in SEVERITIES:
            raise ValueError(f"severity must be one of {', '.join(SEVERITIES)}, got {self.severity!r}")


@dataclass(frozen=True)
class Schema:
    tables: tuple[Table, ...]
    diagnostics: tuple[Diagnostic, ...]

    @property
    def has_errors(self) -> bool:
        return any(d.severity == "error" for d in self.diagnostics)

    def table(self, name: str) -> Optional[Table]:
        return next((t for t in self.tables if t.name == name), None)
