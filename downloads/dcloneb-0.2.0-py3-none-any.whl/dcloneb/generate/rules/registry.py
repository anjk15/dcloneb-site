"""Rule registry (plan3 R3.2): one entry per rule type. It says which column kinds a rule applies to,
what it means, and how a non-NULL value is checked. NULL handling is `null_policy`'s job, the same for
every type. The validator uses `check` on actual values; generation (plan3 R7) restricts providers.
"""

from dataclasses import dataclass
from decimal import Decimal
from typing import Callable

from dcloneb.generate.rules.contract import AllowedValuesRule, FormatRule, RangeRule, ValueKindRule
from dcloneb.generate.rules.emails import is_email

ENGINE_VERSION = 1  # bump when rule meaning, generation, or checks change
COMBINING = ("All rules on a column combine with AND (any forbid makes NULL unacceptable); rule order never matters; "
             "explicit rules override column-name inference and never override schema constraints.")
NULL_BEHAVIOR = "null_policy allow: NULL passes; forbid: NULL fails. Non-NULL values must satisfy the rule."


@dataclass(frozen=True)
class RuleType:
    name: str
    kinds: tuple[str, ...]  # column kinds from types.TypeSpec.kind
    meaning: str
    generation: str
    null_behavior: str
    check: Callable[[object, object], bool]  # (rule, non-NULL value) -> satisfied?


def _number(value) -> Decimal:
    """Exact Decimal for a bound or value: decimal strings and ints are converted, Decimals kept as they are."""
    return value if isinstance(value, Decimal) else Decimal(value)


def _in_range(rule: RangeRule, value) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, Decimal)):
        return False
    v = _number(value)  # exact: Decimal comparisons never round
    if rule.min is not None:
        low = _number(rule.min)
        if v < low or (v == low and not rule.min_inclusive):
            return False
    if rule.max is not None:
        high = _number(rule.max)
        if v > high or (v == high and not rule.max_inclusive):
            return False
    return True


def same_value(listed, value) -> bool:
    """`listed` (a rules.json value) equals `value` (a generated or read value). Booleans only equal
    booleans; decimal strings compare by value; text compares exactly (case-sensitive)."""
    if isinstance(listed, bool) or isinstance(value, bool):
        return isinstance(listed, bool) and isinstance(value, bool) and listed == value
    if isinstance(value, Decimal):
        return isinstance(listed, (int, str)) and _number(listed) == value
    return type(listed) is type(value) and listed == value


def _allowed(rule: AllowedValuesRule, value) -> bool:
    return any(same_value(listed, value) for listed in rule.values)


def _format(rule: FormatRule, value) -> bool:
    return rule.format == "email" and is_email(value)


def _kind(rule: ValueKindRule, value) -> bool:
    return isinstance(value, str) and value != ""  # a guide: what *kind* a value is can't be proven, only its form


REGISTRY = {
    "range": RuleType(
        "range", ("int", "decimal"),
        "the value is >= / > min and <= / < max (whichever bounds are given), compared exactly",
        "uniform over the effective interval: integers, or decimals at the column's scale",
        NULL_BEHAVIOR, _in_range),
    "allowed_values": RuleType(
        "allowed_values", ("int", "decimal", "text", "bool"),
        "the value is one of `values` (decimals by value, text exact and case-sensitive)",
        "uniform over the effective set; without replacement for unique columns",
        NULL_BEHAVIOR, _allowed),
    "format": RuleType(
        "format", ("text",),
        "the value matches the format; only `email` (the documented strict ASCII syntax)",
        "Faker emails that pass the check, else generated `u<n>@example.com` forms down to `a@b.co`; never truncated",
        NULL_BEHAVIOR, _format),
    "value_kind": RuleType(
        "value_kind", ("text",),
        "a generation guide for what the values are (product names, cities, ...); checked as non-empty text that fits",
        "values of that kind (Faker or built-in word lists) that fit the column; never truncated mid-word",
        NULL_BEHAVIOR, _kind),
}


def check(rule, value) -> bool:
    """Does a non-NULL value satisfy the rule?"""
    return REGISTRY[rule.type].check(rule, value)


def render_rules_table() -> str:
    """The README's rule table, rendered from the registry so the two can't drift apart."""
    lines = ["| Rule | Column types | Meaning | Generation |", "|---|---|---|---|"]
    lines += [f"| `{t.name}` | {', '.join(t.kinds)} | {t.meaning} | {t.generation} |" for t in REGISTRY.values()]
    return "\n".join(lines)
