"""Connect accepted rules to generation (plan3 R8): a plan hook that runs before any value exists.

For each ruled column it swaps in a rule provider (allowed set, else email, else a value kind, else range), applies
`forbid`, and records the rule ids. Rules only ever narrow what the schema allows: NOT NULL,
uniqueness, keys, and relationships are left exactly as planned.
"""

from dataclasses import replace

import polars as pl

from dcloneb.generate.kinds import KindProvider
from dcloneb.generate.providers import subseed
from dcloneb.generate.rules.preflight import NormalizedRules
from dcloneb.generate.rules.providers import ChoiceProvider, EmailProvider, RangeProvider
from dcloneb.generate.strategy import ColumnPlan, GenerationPlan


def _provider(plan: GenerationPlan, table: str, column: ColumnPlan, d):
    seed, label = subseed(plan.seed, table, column.name, "rules"), f"{table}.{column.name}"
    if d.allowed is not None:
        return ChoiceProvider(d.allowed, seed, label)
    if "email" in d.formats:
        return EmailProvider(column.spec.max_length, seed, plan.locale, label)
    if d.value_kind is not None:
        return KindProvider(d.value_kind, column.spec.max_length, seed, plan.locale, label)
    return RangeProvider(d.kind, d.low, d.high, d.scale, seed, label)


def rules_hook(normalized: NormalizedRules):
    def apply_business_rules(plan: GenerationPlan) -> GenerationPlan:
        for (table, name), d in normalized.domains.items():
            column = plan.tables[table].columns[name]
            if d.kind == "decimal" and d.scale != column.spec.scale:  # unparameterized NUMERIC: the rules' scale
                column.spec = replace(column.spec, scale=d.scale, dtype=pl.Decimal(38, d.scale))
            column.always_null = (table, name) in normalized.always_null
            column.provider = _provider(plan, table, column, d)
            column.nullable = column.nullable and d.nulls_ok  # forbid removes NULL; allow never adds it
            column.rule_ids = d.rule_ids
        return plan

    return apply_business_rules
