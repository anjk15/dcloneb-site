"""The rules.json contract (plan3 R2): validate the shape against the published JSON Schema and build
typed rules. Meaning (types, bounds, conflicts) is checked later, against the plan, by preflight."""

import hashlib
import json
import re
from dataclasses import dataclass, replace
from importlib.resources import files
from pathlib import Path
from typing import Optional, Union

import jsonschema

from dcloneb.generate.errors import GenerationError, Problem

DECIMAL_STRING = re.compile(r"-?(0|[1-9][0-9]*)(\.[0-9]+)?")  # the schema's bound pattern, also for listed decimals
SCHEMA = json.loads(files("dcloneb.generate.rules").joinpath("rules.schema.json").read_text(encoding="utf-8"))
_VALIDATOR = jsonschema.Draft202012Validator(SCHEMA)


@dataclass(frozen=True)
class RangeRule:
    id: str
    table: str
    column: str
    null_policy: str
    min: Union[int, str, None] = None  # int for integer columns, decimal string for decimal columns
    min_inclusive: Optional[bool] = None
    max: Union[int, str, None] = None
    max_inclusive: Optional[bool] = None
    type: str = "range"


@dataclass(frozen=True)
class AllowedValuesRule:
    id: str
    table: str
    column: str
    null_policy: str
    values: tuple
    type: str = "allowed_values"


@dataclass(frozen=True)
class FormatRule:
    id: str
    table: str
    column: str
    null_policy: str
    format: str
    type: str = "format"


@dataclass(frozen=True)
class ValueKindRule:
    """A generation guide: what the column's values are (plan5). Not a provable constraint."""
    id: str
    table: str
    column: str
    null_policy: str
    kind: str
    type: str = "value_kind"


KINDS = tuple(next(branch for branch in SCHEMA["properties"]["rules"]["items"]["allOf"]
                   if branch["if"]["properties"]["type"]["const"] == "value_kind")["then"]["properties"]["kind"]["enum"])

Rule = Union[RangeRule, AllowedValuesRule, FormatRule, ValueKindRule]


@dataclass(frozen=True)
class RuleSet:
    version: int
    rules: tuple
    source_sha256: Optional[str] = None


def _rule(data: dict) -> Rule:
    head = (data["id"], data["table"], data["column"], data["null_policy"])
    if data["type"] == "range":
        return RangeRule(*head, data.get("min"), data.get("min_inclusive"), data.get("max"), data.get("max_inclusive"))
    if data["type"] == "allowed_values":
        return AllowedValuesRule(*head, tuple(data["values"]))
    if data["type"] == "value_kind":
        return ValueKindRule(*head, data["kind"])
    return FormatRule(*head, data["format"])


def _where(data, path: list) -> str:
    if len(path) >= 2 and path[0] == "rules" and isinstance(path[1], int):
        item = data["rules"][path[1]]
        rule_id = item.get("id") if isinstance(item, dict) else None
        return f"rules[{path[1]}]" + (f" (id {rule_id!r})" if isinstance(rule_id, str) and rule_id else "")
    return "rules.json"


def _rule_id(data, path: list) -> tuple[str, ...]:
    if len(path) >= 2 and path[0] == "rules" and isinstance(path[1], int):
        item = data["rules"][path[1]]
        if isinstance(item, dict) and isinstance(item.get("id"), str) and item["id"]:
            return (item["id"],)
    return ()


def _problem(data, error: jsonschema.ValidationError) -> Problem:
    return replace(_shape_problem(data, error), rule_ids=_rule_id(data, list(error.absolute_path)))


def _shape_problem(data, error: jsonschema.ValidationError) -> Problem:
    path = list(error.absolute_path)
    where = _where(data, path)
    if path == ["rules_version"]:
        return Problem("input", "rules_unsupported_version",
                       f"{where}: rules_version {error.instance!r} is not supported; expected 1")
    if error.validator == "enum" and path[-1:] == ["type"]:
        return Problem("unsupported", "rule_type_unsupported",
                       f"{where}: rule type {error.instance!r} is not supported; supported: {', '.join(error.validator_value)}")
    if error.validator == "enum" and path[-1:] == ["format"]:
        return Problem("unsupported", "rule_format_unsupported",
                       f"{where}: format {error.instance!r} is not supported; supported: {', '.join(error.validator_value)}")
    if error.validator == "enum" and path[-1:] == ["kind"]:
        return Problem("unsupported", "rule_kind_unsupported",
                       f"{where}: kind {error.instance!r} isn't one of the supported kinds: {', '.join(error.validator_value)}")
    field = ".".join(str(p) for p in path[2:]) if where != "rules.json" else ".".join(str(p) for p in path)
    return Problem("input", "rules_malformed", f"{where}{': ' + field if field else ''}: {error.message}")


def _duplicate_ids(data) -> list[Problem]:
    rules = data.get("rules") if isinstance(data, dict) else None
    if not isinstance(rules, list):
        return []
    seen: dict[str, int] = {}
    problems = []
    for i, rule in enumerate(rules):
        rule_id = rule.get("id") if isinstance(rule, dict) else None
        if isinstance(rule_id, str) and rule_id:
            if rule_id in seen:
                problems.append(Problem("input", "rule_duplicate_id",
                                        f"rules[{i}]: id {rule_id!r} is already used by rules[{seen[rule_id]}]", (rule_id,)))
            else:
                seen[rule_id] = i
    return problems


def parse_rules(data, source_sha256: Optional[str] = None) -> RuleSet:
    """Validate rules.json's shape (every problem at once) and build typed rules, in file order."""
    problems = [_problem(data, e) for e in sorted(_VALIDATOR.iter_errors(data), key=lambda e: list(map(str, e.absolute_path)))]
    problems += _duplicate_ids(data)
    if problems:
        raise GenerationError(problems)
    return RuleSet(data["rules_version"], tuple(_rule(r) for r in data["rules"]), source_sha256)


def load_rules(path: Path) -> RuleSet:
    try:
        raw = Path(path).read_bytes()
    except OSError as e:
        raise GenerationError([Problem("input", "rules_unreadable", f"cannot read rules {path}: {e.strerror or e}")]) from None
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise GenerationError([Problem("input", "rules_invalid_json", f"rules {path} is not valid JSON: {e}")]) from None
    return parse_rules(data, hashlib.sha256(raw).hexdigest())
