"""ColumnDomain (plan3 R5): the AND of every rule on one column, normalized and order-independent.

Numeric bounds become an exact **inclusive** interval of representable values: integers, or decimals
at the column's scale (an exclusive bound steps by one unit of that scale). Allowed lists intersect and
are filtered by the range and formats. Every original rule id is kept for reporting.
"""

from dataclasses import dataclass
from decimal import ROUND_CEILING, ROUND_FLOOR, Decimal
from typing import Optional

from dcloneb.generate.rules.contract import AllowedValuesRule, FormatRule, RangeRule, ValueKindRule
from dcloneb.generate.rules.emails import MIN_LENGTH, is_email
from dcloneb.generate.rules.registry import same_value
from dcloneb.generate.types import EXACT, TypeSpec
from dcloneb.model import Column

BARE_NUMERIC_DEFAULT_SCALE = 2


@dataclass(frozen=True)
class ColumnDomain:
    table: str
    column: str
    kind: str
    rule_ids: tuple[str, ...]  # sorted
    nulls_ok: bool  # SQL allows NULL and no rule forbids it
    forbid_ids: tuple[str, ...] = ()  # rules with null_policy "forbid"
    scale: Optional[int] = None  # decimals: the scale values are generated and compared at
    low: object = None  # inclusive bounds (int or Decimal); None = unbounded on that side
    high: object = None
    allowed: Optional[tuple] = None  # canonical, sorted; None = no allowed list
    formats: tuple[str, ...] = ()
    max_length: Optional[int] = None  # text
    value_kind: Optional[str] = None  # plan5: what the values are (a generation guide); allowed values take precedence

    @property
    def size(self) -> Optional[int]:
        """How many distinct non-NULL values satisfy every rule (None = more than any row count)."""
        if self.allowed is not None:
            return len(self.allowed)
        if "email" in self.formats and self.max_length is not None and self.max_length < MIN_LENGTH:
            return 0
        if self.low is None or self.high is None:
            return None
        if self.low > self.high:
            return 0
        if self.kind == "int":
            return self.high - self.low + 1
        return int((self.high - self.low).scaleb(self.scale, context=EXACT)) + 1


def _decimal_places(value) -> int:
    return max(0, -Decimal(value).normalize(EXACT).as_tuple().exponent) if isinstance(value, str) else 0


def generation_scale(spec: TypeSpec, column: Column, rules) -> Optional[int]:
    """Decimals: the column's scale, or for an unparameterized NUMERIC max(2, decimals the rules use)."""
    if spec.kind != "decimal":
        return None
    if column.type_params:
        return spec.scale
    used = [_decimal_places(v) for r in rules for v in _rule_values(r)]
    return max([BARE_NUMERIC_DEFAULT_SCALE, *used])


def _rule_values(rule) -> list:
    if isinstance(rule, RangeRule):
        return [v for v in (rule.min, rule.max) if v is not None]
    if isinstance(rule, AllowedValuesRule):
        return list(rule.values)
    return []


def canonical(kind: str, scale: Optional[int], value):
    """A listed value as the generator and validator hold it: Decimals at the scale, others as they are."""
    if kind == "decimal":
        return Decimal(value).quantize(Decimal(1).scaleb(-scale), context=EXACT)
    return value


def _low(kind, scale, bound, inclusive):
    if kind == "int":
        return bound if inclusive else bound + 1
    step = Decimal(1).scaleb(-scale)
    value = Decimal(bound)
    return value.quantize(step, ROUND_CEILING, EXACT) if inclusive else value.quantize(step, ROUND_FLOOR, EXACT) + step


def _high(kind, scale, bound, inclusive):
    if kind == "int":
        return bound if inclusive else bound - 1
    step = Decimal(1).scaleb(-scale)
    value = Decimal(bound)
    return value.quantize(step, ROUND_FLOOR, EXACT) if inclusive else value.quantize(step, ROUND_CEILING, EXACT) - step


def _type_bounds(spec: TypeSpec, column: Column):
    if spec.kind == "int" or (spec.kind == "decimal" and column.type_params):
        return spec.min_value, spec.max_value
    return None, None  # unparameterized NUMERIC: no type limit


def build_domain(table: str, spec: TypeSpec, column: Column, rules) -> ColumnDomain:
    scale = generation_scale(spec, column, rules)
    low, high = _type_bounds(spec, column)
    allowed = None
    formats = sorted({r.format for r in rules if isinstance(r, FormatRule)})
    for r in rules:
        if isinstance(r, RangeRule):
            if r.min is not None:
                bound = _low(spec.kind, scale, r.min, r.min_inclusive)
                low = bound if low is None else max(low, bound)
            if r.max is not None:
                bound = _high(spec.kind, scale, r.max, r.max_inclusive)
                high = bound if high is None else min(high, bound)
        elif isinstance(r, AllowedValuesRule):
            values = [canonical(spec.kind, scale, v) for v in r.values]
            allowed = values if allowed is None else [v for v in allowed if any(same_value(w, v) for w in values)]
    if allowed is not None:
        allowed = [v for v in allowed
                   if (low is None or v >= low) and (high is None or v <= high) and ("email" not in formats or is_email(v))]
        allowed = tuple(sorted(set(allowed)))
    return ColumnDomain(
        table=table, column=column.name, kind=spec.kind, rule_ids=tuple(sorted(r.id for r in rules)),
        nulls_ok=column.nullable and all(r.null_policy == "allow" for r in rules),
        forbid_ids=tuple(sorted(r.id for r in rules if r.null_policy == "forbid")), scale=scale,
        low=low, high=high, allowed=allowed, formats=tuple(formats),
        max_length=spec.max_length if spec.kind == "text" else None,
        value_kind=next((r.kind for r in rules if isinstance(r, ValueKindRule)), None))
