"""Values of a kind (plan5): product names, cities, people's names, ... for any column, by meaning.

Used by the `value_kind` rule (the agent labels a column) and by table-aware default inference. Values
always fit the column and are never cut mid-word: a value that doesn't fit is redrawn, then shorter
whole forms are tried, and if nothing of the kind can fit, that's a generator limit.
"""

import random
from typing import Optional

from dcloneb.generate.providers import MAX_ROUNDS, generator_capacity

UNBOUNDED_TEXT = 200  # a TEXT column has no limit; kind values stay readable well within this

FAKER_METHODS = {
    "person_name": "name", "first_name": "first_name", "last_name": "last_name", "company_name": "company",
    "city": "city", "state": "state", "country": "country", "street_address": "street_address",
    "postal_code": "postcode", "phone_number": "phone_number", "url": "url", "username": "user_name",
    "job_title": "job", "word": "word", "sentence": "sentence",
}

PRODUCT_ADJECTIVES = ("Steel", "Oak", "Organic", "Wireless", "Classic", "Compact", "Deluxe", "Eco", "Smart", "Vintage",
                      "Ceramic", "Bamboo", "Cotton", "Leather", "Glass", "Copper", "Portable", "Ergonomic", "Premium",
                      "Mini")
PRODUCT_NOUNS = ("Desk Lamp", "Water Bottle", "Notebook", "Backpack", "Coffee Mug", "Headphones", "Chair", "Phone Case",
                 "Candle", "Blanket", "Tea Set", "Cutting Board", "Wall Clock", "Speaker", "Keyboard", "Plant Pot",
                 "Tote Bag", "Picture Frame", "Bike Light", "Yoga Mat")
CATEGORIES = ("Home & Garden", "Kitchen & Dining", "Electronics", "Books", "Toys & Games", "Sports & Outdoors", "Beauty",
              "Health", "Clothing", "Shoes", "Jewelry", "Office Supplies", "Pet Supplies", "Automotive", "Music", "Movies",
              "Grocery", "Baby", "Tools", "Arts & Crafts", "Furniture", "Travel", "Stationery", "Lighting", "Bedding",
              "Fitness", "Outdoor Cooking", "Party Supplies", "Storage", "Video Games")
LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


class KindProvider:
    def __init__(self, kind: str, max_length: Optional[int], seed: int, locale: str, label: str = "column"):
        self.kind, self.label = kind, label
        self.name = f"kind.{kind}"
        self.limit = max_length if max_length is not None else UNBOUNDED_TEXT
        self.rng = random.Random(seed)
        self.fake = None
        if kind in FAKER_METHODS:
            from faker import Faker
            self.fake = Faker(locale)
            self.fake.seed_instance(seed)

    @property
    def capacity(self) -> None:
        return None  # large; unique() reports a generator limit if it can't produce enough

    # --- one value ----------------------------------------------------------------------------------

    def _draw(self) -> str:
        if self.fake is not None:
            return str(getattr(self.fake, FAKER_METHODS[self.kind])()).strip()
        if self.kind == "product_name":
            return f"{self.rng.choice(PRODUCT_ADJECTIVES)} {self.rng.choice(PRODUCT_NOUNS)}"
        if self.kind == "category_name":
            return self.rng.choice(CATEGORIES)
        if self.kind == "code":
            return self._code()
        raise ValueError(self.kind)

    def _code(self) -> str:
        if self.limit >= 7:
            return f"{self.rng.choice(LETTERS)}{self.rng.choice(LETTERS)}-{self.rng.randrange(10_000):04d}"
        return f"{self.rng.choice(LETTERS)}{self.rng.randrange(1_000):03d}"  # 4 characters: A123

    def _short_forms(self) -> list[str]:
        """Shorter whole values of the kind, for narrow columns."""
        if self.kind == "product_name":
            return [n for n in PRODUCT_NOUNS if len(n) <= self.limit] or [
                f"{a} {n}" for a in PRODUCT_ADJECTIVES for n in PRODUCT_NOUNS if len(f"{a} {n}") <= self.limit]
        if self.kind == "category_name":
            return [c for c in CATEGORIES if len(c) <= self.limit]
        return []

    def _fitting(self) -> Optional[str]:
        for _ in range(MAX_ROUNDS):
            value = self._draw()
            if value and len(value) <= self.limit:
                return value
        short = self._short_forms()
        return self.rng.choice(short) if short else None

    def _too_long(self, n: int):
        return generator_capacity(self.label, n, 0, f"{self.kind.replace('_', ' ')} values that fit {self.limit} characters")

    def values(self, n: int) -> list[str]:
        out = []
        for _ in range(n):
            value = self._fitting()
            if value is None:
                raise self._too_long(n)
            out.append(value)
        return out

    def unique(self, n: int) -> list[str]:
        """n distinct values: distinct draws first, then numbered variants ("Books 2") that still fit."""
        seen: dict[str, None] = {}
        for _ in range(MAX_ROUNDS):
            missing, before = n - len(seen), len(seen)
            if missing <= 0:
                break
            for _ in range(missing * 2):
                value = self._fitting()
                if value is None:
                    raise self._too_long(n)
                seen.setdefault(value)
                if len(seen) >= n:
                    break
            if len(seen) == before:
                break
        bases, number = list(seen), 2
        while len(seen) < n and bases:
            added = False
            for base in bases:
                variant = f"{base} {number}"
                if len(variant) <= self.limit and variant not in seen:
                    seen.setdefault(variant)
                    added = True
                    if len(seen) >= n:
                        break
            if not added:
                break
            number += 1
        if len(seen) < n:
            raise generator_capacity(self.label, n, len(seen), f"distinct {self.kind.replace('_', ' ')} values that fit "
                                                               f"{self.limit} characters")
        return list(seen)[:n]
