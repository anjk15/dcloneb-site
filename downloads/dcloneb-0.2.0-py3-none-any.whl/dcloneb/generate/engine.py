"""Generate tables in plan order (plan2 G8). In memory only: nothing is written or executed.

Per table: (1) identity and pre-allocated key columns, (2) FKs from complete parent tuples (junction
keys jointly), (3) free and value columns from providers, (4) composite keys made unique with bounded
retries, (5) a Polars frame. Parents are always generated before children, except for backfilled FKs.
"""

import random
from dataclasses import dataclass, field
from typing import Optional

import polars as pl

from dcloneb.generate.errors import GenerationError, Problem
from dcloneb.generate.keys import (duplicate_rows, enforce_unique, fk_values, pick_distinct, pick_distinct_product,
                                   pick_with_replacement, pool_of, skip_columns)
from dcloneb.generate.providers import MAX_ROUNDS, GenericProvider, subseed
from dcloneb.generate.strategy import FkPlan, GenerationPlan, KeyPlan, TablePlan


@dataclass(frozen=True)
class PendingFill:
    """Backfill ledger entry: this row's FK columns are temporarily NULL until the backfill runs."""
    table: str
    fk_index: int
    row: int
    reserved: Optional[int] = None  # index into the parent's pre-allocated key tuples, if reserved


@dataclass
class GeneratedData:
    frames: dict[str, pl.DataFrame]
    ledger: list[PendingFill] = field(default_factory=list)  # still temporarily NULL
    filled: list[PendingFill] = field(default_factory=list)  # backfilled: these rows must reference a parent
    providers: dict[str, dict[str, str]] = field(default_factory=dict)  # table -> column -> provider name


class _Engine:
    def __init__(self, plan: GenerationPlan):
        self.plan = plan
        self.data: dict[str, dict[str, list]] = {}  # generated tables, column -> values
        self.ledger: list[PendingFill] = []
        self.pre: dict[str, dict[str, list]] = {}  # pre-allocated key columns of reserved parents
        for name, keys in plan.reservations.items():
            self.preallocate(plan.tables[name], keys)

    def rng(self, *parts) -> random.Random:
        return random.Random(subseed(self.plan.seed, *map(str, parts)))

    def preallocate(self, t: TablePlan, keys: list[tuple[str, ...]]) -> None:
        """Generate a reserved parent's key columns before any table, so a backfilled child can copy the
        retained part of a real parent tuple. These columns are then fixed: nothing regenerates them."""
        columns = [c for c in t.columns.values() if any(c.name in k for k in keys)]
        singles = {k.columns[0] for k in t.keys if k.strategy == "single_free"}
        values = {}
        for c in columns:
            if c.role == "identity":
                values[c.name] = list(range(1, t.rows + 1))
            else:
                values[c.name] = c.provider.unique(t.rows) if c.name in singles else c.provider.values(t.rows)
        names = set(values)
        for key in t.keys:
            if key.strategy != "implied" and set(key.columns) <= names:
                enforce_unique(lambda k=key: list(zip(*(values[c] for c in k.columns))),
                               lambda rows, k=key: self.regenerate(t, k.columns, rows, values, fixed=()),
                               key.nulls_distinct, f"{t.name} ({', '.join(key.columns)}), pre-allocated")
        self.pre[t.name] = values

    def reserved_tuples(self, f: FkPlan) -> list[tuple]:
        pre = self.pre[f.fk.ref_table]
        return list(zip(*(pre[c] for c in f.fk.ref_columns)))

    # --- one table -----------------------------------------------------------------------------------

    def table(self, t: TablePlan) -> pl.DataFrame:
        n = t.rows
        values: dict[str, list] = {c: list(v) for c, v in self.pre.get(t.name, {}).items()}
        for c in t.columns.values():
            if c.role == "identity" and c.name not in values:
                values[c.name] = list(range(1, n + 1))
        assigned: set[int] = set()
        for key in t.keys:
            if key.strategy == "fk_groups" and len(key.groups) > 1:
                self.junction(t, key.groups, values)
                assigned |= set(key.groups)
        for i, f in enumerate(t.fks):
            if i not in assigned:
                self.foreign_key(t, i, f, values)
        singles = {k.columns[0] for k in t.keys if k.strategy == "single_free"}
        for c in t.columns.values():
            if c.name not in values:
                if c.always_null:
                    values[c.name] = [None] * n
                else:
                    values[c.name] = c.provider.unique(n) if c.name in singles else c.provider.values(n)
        self.apply_nulls(t, values)
        self.composite_keys(t, values)
        self.data[t.name] = values
        return pl.DataFrame([pl.Series(c.name, values[c.name], dtype=c.spec.dtype, strict=True) for c in t.columns.values()])

    def pool(self, f: FkPlan) -> list[tuple]:
        parent = self.data.get(f.fk.ref_table)
        if parent is None:
            raise RuntimeError(f"{f.fk.ref_table} must be generated before its children (plan order)")
        return pool_of(parent, f.fk.ref_columns)

    def skip_rows(self, t: TablePlan, i: int, rng: random.Random) -> set[int]:
        """Rows that skip FK i: each with `null_probability` if the generator may write its NULL pattern,
        topped up to the forced count (not enough parents)."""
        f, p = t.fks[i], self.plan.null_probability
        skipped = {r for r in range(t.rows) if rng.random() < p} if f.nullable else set()
        forced = self.plan.forced_nulls.get((t.name, i), 0)
        if len(skipped) < forced:
            skipped |= set(rng.sample(sorted(set(range(t.rows)) - skipped), forced - len(skipped)))
        return skipped

    def apply_nulls(self, t: TablePlan, values: dict[str, list]) -> None:
        """`null_probability` for free and value columns the generator may null (FKs decide their own)."""
        for c in t.columns.values():
            if c.nullable and c.role in ("free_key", "value"):
                rng = self.rng(t.name, c.name, "nulls")
                values[c.name] = [None if rng.random() < self.plan.null_probability else v for v in values[c.name]]

    def fallback(self, t: TablePlan, f: FkPlan) -> dict:
        """Values for NOT NULL columns of a skipped MATCH SIMPLE FK when the parent is empty."""
        out = {}
        for c in f.fk.columns:
            provider = GenericProvider(t.columns[c].spec, subseed(self.plan.seed, t.name, c, "fk-fallback"), f"{t.name}.{c}")
            out[c] = lambda p=provider: p.values(1)[0]
        return out

    def backfilled_key(self, t: TablePlan, i: int, f: FkPlan, values: dict[str, list]) -> None:
        """A deferred FK: rows that will reference a parent get `null_columns` temporarily NULL and a
        ledger entry; rows that skip the FK for good get its NULL pattern and no entry."""
        rng = self.rng(t.name, "fk", i)
        skipped = self.skip_rows(t, i, rng)
        pending = [r for r in range(t.rows) if r not in skipped]
        if not f.reserved:  # retained_columns is empty, so every FK column is nulled
            for c in f.fk.columns:
                values[c] = [None] * t.rows
            self.ledger += [PendingFill(t.name, i, r) for r in pending]
            return
        tuples = self.reserved_tuples(f)  # the parent's future key tuples, in its row order
        chosen = pick_distinct(len(tuples), len(pending), rng) if f.unique else pick_with_replacement(len(tuples), len(pending), rng)
        picks: list[Optional[int]] = [None] * t.rows
        for r, p in zip(pending, chosen):
            picks[r] = p
        values.update(fk_values(f.fk.columns, tuples, picks, skip_columns(f, t.columns), rng, self.fallback(t, f)))
        for r in pending:  # keep the retained part; the rest waits for the backfill
            for c in f.backfill.null_columns:
                values[c][r] = None
        self.ledger += [PendingFill(t.name, i, r, picks[r]) for r in pending]

    def foreign_key(self, t: TablePlan, i: int, f: FkPlan, values: dict[str, list]) -> None:
        if f.backfill is not None:
            return self.backfilled_key(t, i, f, values)
        rng = self.rng(t.name, "fk", i)
        pool = self.pool(f)
        skipped = self.skip_rows(t, i, rng)
        referenced = [r for r in range(t.rows) if r not in skipped]
        chosen = pick_distinct(len(pool), len(referenced), rng) if f.unique else pick_with_replacement(len(pool), len(referenced), rng)
        picks: list[Optional[int]] = [None] * t.rows
        for r, p in zip(referenced, chosen):
            picks[r] = p
        values.update(fk_values(f.fk.columns, pool, picks, skip_columns(f, t.columns), rng, self.fallback(t, f)))

    def junction(self, t: TablePlan, groups: tuple[int, ...], values: dict[str, list]) -> None:
        """FKs whose combined columns form a key: distinct combinations of parent rows, no retries."""
        rng = self.rng(t.name, "junction", *groups)
        fks = [t.fks[g] for g in groups]
        pools = [self.pool(f) for f in fks]
        skipped = [self.skip_rows(t, g, rng) for g in groups]
        complete = {r for r in range(t.rows) if not any(r in s for s in skipped)}
        combos = iter(pick_distinct_product([len(p) for p in pools], len(complete), rng))
        picks: list[list[Optional[int]]] = [[None] * t.rows for _ in groups]
        for r in range(t.rows):
            if r in complete:  # a row with any skipped FK can't collide (its key has a NULL)
                for side, index in enumerate(next(combos)):
                    picks[side][r] = index
            else:
                for side, pool in enumerate(pools):
                    if r not in skipped[side]:
                        picks[side][r] = rng.randrange(len(pool))
        for side, f in enumerate(fks):
            values.update(fk_values(f.fk.columns, pools[side], picks[side], skip_columns(f, t.columns), rng,
                                    self.fallback(t, f)))

    def composite_keys(self, t: TablePlan, values: dict[str, list]) -> None:
        """Make every composite key unique as a whole: regenerate only colliding rows' free columns
        (or, when a key has none, their parent choice), bounded by MAX_ROUNDS."""
        keys = [k for k in t.keys if k.strategy == "composite"]
        if not keys:
            return
        for _ in range(MAX_ROUNDS):
            for key in keys:
                label = f"{t.name} {'PRIMARY KEY' if key.primary else 'UNIQUE'} ({', '.join(key.columns)})"
                enforce_unique(lambda k=key: list(zip(*(values[c] for c in k.columns))),
                               lambda rows, k=key: self.regenerate(t, k.columns, rows, values), key.nulls_distinct, label)
            if all(not _duplicates(values, k) for k in keys):
                return
        raise GenerationError([Problem("retry_exhausted", "unique_retry_exhausted",
                                       f"{t.name}: its composite keys kept breaking each other after {MAX_ROUNDS} rounds; "
                                       "this is not proof that no valid dataset exists")])

    def regenerate(self, t: TablePlan, columns: tuple[str, ...], rows: list[int], values: dict[str, list],
                   fixed=None) -> None:
        fixed = self.pre.get(t.name, {}) if fixed is None else fixed  # pre-allocated columns never change
        free = [t.columns[c] for c in columns if t.columns[c].role in ("free_key", "value") and c not in fixed]
        if free:
            for c in free:
                for r, v in zip(rows, c.provider.values(len(rows))):
                    if values[c.name][r] is not None:  # keep intended NULLs
                        values[c.name][r] = v
            return
        for i, f in enumerate(t.fks):  # no free column: pick other parents for the colliding rows
            if set(f.fk.columns) & set(columns) and f.backfill is None:
                pool, rng = self.pool(f), self.rng(t.name, "fk-retry", i, rows[0])
                for r in rows:
                    if all(values[c][r] is not None for c in f.fk.columns):
                        for c, v in zip(f.fk.columns, pool[rng.randrange(len(pool))]):
                            values[c][r] = v
                return


def _duplicates(values: dict[str, list], key: KeyPlan) -> bool:
    return bool(duplicate_rows(list(zip(*(values[c] for c in key.columns))), key.nulls_distinct))


def generate_tables(plan: GenerationPlan) -> GeneratedData:
    """Generate every table in plan order (the plan must have passed `capacity.check_capacity`)."""
    engine = _Engine(plan)
    frames = {name: engine.table(plan.tables[name]) for name in plan.order}
    providers = {t.name: {c.name: getattr(c.provider, "name", c.role) for c in t.columns.values()} for t in plan.tables.values()}
    return GeneratedData(frames, ledger=engine.ledger, providers=providers)
