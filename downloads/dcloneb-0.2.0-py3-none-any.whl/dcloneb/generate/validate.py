"""Independent validator (plan2 G10): checks generated tables against the plan's declared constraints.

It never imports the generator's value, key, engine, or backfill code, so a bug there can't hide
itself here. Limits are the **SQL** limits from the plan, not the generator's own ranges.
"""

import re
from dataclasses import asdict, dataclass, field
from decimal import Decimal
from typing import Iterable

import polars as pl

from dcloneb.generate.plan_input import LoadedPlan
from dcloneb.generate.rules.registry import check as rule_check
from dcloneb.generate.types import type_spec
from dcloneb.model import Column, ForeignKey, Table

SAMPLES = 5
ROW = "__dcloneb_row"
UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


@dataclass(frozen=True)
class Check:
    check: str  # row_count | columns | type_limits | not_null | primary_key | unique | foreign_key | backfill
    table: str
    constraint: str
    rows_checked: int
    violations: int
    samples: tuple[int, ...] = ()  # up to 5 offending row indices


@dataclass(frozen=True)
class RuleResult:
    """One business rule checked against the actual values (plan3 R9)."""
    rule_id: str
    table: str
    column: str
    rows_evaluated: int
    null_count: int
    violations: int
    samples: tuple[int, ...] = ()
    coverage: str = "rows"  # rows | empty table | column missing


@dataclass
class Report:
    checks: list[Check]
    rules: list[RuleResult] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not any(c.violations for c in self.checks) and not any(r.violations for r in self.rules)

    def to_dict(self) -> dict:
        return {"passed": self.passed, "checks": [{**asdict(c), "samples": list(c.samples)} for c in self.checks],
                "rules": [{**asdict(r), "samples": list(r.samples)} for r in self.rules]}


def _check(check: str, table: str, constraint: str, rows_checked: int, bad: list[int]) -> Check:
    return Check(check, table, constraint, rows_checked, len(bad), tuple(sorted(bad)[:SAMPLES]))


def _value_ok(column: Column, value) -> bool:
    spec = type_spec(column)
    if spec.kind == "int":
        return spec.min_value <= value <= spec.max_value
    if spec.kind == "decimal":
        if not isinstance(value, Decimal) or not value.is_finite():
            return False
        if not column.type_params:  # unparameterized NUMERIC: any finite value
            return True
        # exact: no context rounding (as_tuple, copy_abs and comparisons never round)
        return value.as_tuple().exponent >= -spec.scale and value.copy_abs() <= spec.max_value
    if spec.kind == "text":
        return "\x00" not in value and (spec.max_length is None or len(value) <= spec.max_length)
    if spec.kind == "uuid":
        return bool(UUID.match(value))
    return True  # bool, date, timestamp: the frame's dtype already guarantees the type


def _type_limits(table: Table, frame: pl.DataFrame) -> list[Check]:
    checks = []
    for column in table.columns:
        if column.name in frame.columns:
            values = frame[column.name].to_list()
            bad = [i for i, v in enumerate(values) if v is not None and not _value_ok(column, v)]
            checks.append(_check("type_limits", table.name, f"{column.name} {column.type}", len(values), bad))
    return checks


def _dtype_ok(column: Column, dtype) -> bool:
    expected = type_spec(column).dtype
    if column.type_name == "DECIMAL" and not column.type_params:
        return isinstance(dtype, pl.Decimal)  # an unparameterized NUMERIC has no scale: any exact decimal is right
    return dtype == expected


def _columns(table: Table, frame: pl.DataFrame) -> Check:
    expected = [(c.name, type_spec(c).dtype) for c in table.columns]
    actual = list(frame.schema.items())
    bad = [i for i in range(max(len(expected), len(actual)))
           if i >= len(expected) or i >= len(actual) or expected[i][0] != actual[i][0]
           or not _dtype_ok(table.columns[i], actual[i][1])]
    return _check("columns", table.name, ", ".join(f"{n} {d}" for n, d in expected), len(actual), bad)


def _duplicates(frame: pl.DataFrame, columns: tuple[str, ...], nulls_distinct: bool) -> list[int]:
    """Rows repeating an earlier row's key. Nulls distinct: rows with any NULL never collide."""
    rows = frame.select(*columns).with_row_index(ROW)
    if nulls_distinct:
        rows = rows.drop_nulls(list(columns))
    groups = rows.group_by(list(columns), maintain_order=True).agg(pl.col(ROW)).filter(pl.col(ROW).list.len() > 1)
    return [r for group in groups[ROW].to_list() for r in sorted(group)[1:]]


def _fk_label(fk: ForeignKey) -> str:
    return f"FOREIGN KEY ({', '.join(fk.columns)}) -> {fk.ref_table} ({', '.join(fk.ref_columns)}) MATCH {fk.match.upper()}"


def _foreign_key(table: Table, fk: ForeignKey, frame: pl.DataFrame, parent: pl.DataFrame) -> Check:
    cols = list(fk.columns)
    rows = frame.select(*cols).with_row_index(ROW)
    nulls = pl.sum_horizontal(*(pl.col(c).is_null().cast(pl.Int32) for c in cols))
    partial = rows.filter((nulls > 0) & (nulls < len(cols)))[ROW].to_list() if fk.match == "full" else []
    complete = rows.filter(nulls == 0)
    keys = parent.select(*fk.ref_columns).drop_nulls().unique().rename(dict(zip(fk.ref_columns, cols)))
    missing = complete.join(keys, on=cols, how="anti")[ROW].to_list()
    return _check("foreign_key", table.name, _fk_label(fk), frame.height, partial + missing)


def _table_checks(plan: LoadedPlan, table: Table, frames: dict[str, pl.DataFrame], rows: int) -> list[Check]:
    frame = frames[table.name]
    checks = [_check("row_count", table.name, f"{rows} rows", frame.height, [0] * abs(frame.height - rows)),
              _columns(table, frame)]
    checks += _type_limits(table, frame)
    present = set(frame.columns)
    for column in table.columns:
        if not column.nullable and column.name in present:
            nulls = frame.with_row_index(ROW).filter(pl.col(column.name).is_null())[ROW].to_list()
            checks.append(_check("not_null", table.name, f"{column.name} NOT NULL", frame.height, nulls))
    if table.primary_key and set(table.primary_key) <= present:
        checks.append(_check("primary_key", table.name, f"PRIMARY KEY ({', '.join(table.primary_key)})", frame.height,
                             _duplicates(frame, table.primary_key, True)))
    for key in table.unique_keys:
        if set(key.columns) <= present:
            label = f"UNIQUE{'' if key.nulls_distinct else ' NULLS NOT DISTINCT'} ({', '.join(key.columns)})"
            checks.append(_check("unique", table.name, label, frame.height, _duplicates(frame, key.columns, key.nulls_distinct)))
    for fk in table.foreign_keys:
        parent = frames.get(fk.ref_table)
        if parent is not None and set(fk.columns) <= present and set(fk.ref_columns) <= set(parent.columns):
            checks.append(_foreign_key(table, fk, frame, parent))
    return checks


def _backfill_checks(plan: LoadedPlan, frames: dict[str, pl.DataFrame], filled: Iterable, pending: int) -> list[Check]:
    """Every backfilled row must now hold a complete FK tuple (the FK check proves it exists)."""
    by_table: dict[tuple[str, int], list[int]] = {}
    for entry in filled:
        by_table.setdefault((entry.table, entry.fk_index), []).append(entry.row)
    checks = []
    for (name, index), rows in sorted(by_table.items()):
        fk = plan.schema.table(name).foreign_keys[index]
        frame = frames[name]
        bad = [r for r in rows if r >= frame.height or any(frame[c][r] is None for c in fk.columns)]
        checks.append(_check("backfill", name, f"backfilled {_fk_label(fk)}", len(rows), bad))
    checks.append(Check("backfill", "", "no pending backfill rows", pending, pending))
    return checks


def _rule_result(rule, frames: dict[str, pl.DataFrame]) -> RuleResult:
    """Evaluate one rule on the actual values: NULL passes under `allow` and fails under `forbid`; every
    non-NULL value must satisfy the rule's registry check."""
    frame = frames.get(rule.table)
    if frame is None or rule.column not in frame.columns:
        return RuleResult(rule.id, rule.table, rule.column, 0, 0, 1, (), "column missing")
    values = frame[rule.column].to_list()
    nulls = sum(v is None for v in values)
    bad = [i for i, v in enumerate(values)
           if (v is None and rule.null_policy == "forbid") or (v is not None and not rule_check(rule, v))]
    return RuleResult(rule.id, rule.table, rule.column, len(values), nulls, len(bad), tuple(bad[:SAMPLES]),
                      "rows" if values else "empty table")


def validate(plan: LoadedPlan, frames: dict[str, pl.DataFrame], rows: dict[str, int], filled: Iterable = (),
             pending: int = 0, rules: Iterable = ()) -> Report:
    """Check every table against the plan, and every accepted business rule against the values.
    `filled` lists backfilled rows (table, fk_index, row); `pending` counts ledger rows never backfilled."""
    checks = []
    for table in sorted(plan.schema.tables, key=lambda t: t.name):
        if table.name not in frames:
            checks.append(_check("columns", table.name, "table present", 0, [0]))
            continue
        checks += _table_checks(plan, table, frames, rows[table.name])
    checks += _backfill_checks(plan, frames, filled, pending)
    ordered = sorted(rules, key=lambda r: (r.table, r.column, r.type, r.id))
    return Report(checks, [_rule_result(r, frames) for r in ordered])
