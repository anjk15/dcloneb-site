"""Python API for the generator (plan2 G12.1). The CLI is a thin wrapper around `generate`, and a
future MCP wrapper can call `generate_tables` directly.

Order: load inputs -> support check -> generation plan (+ plan hooks) -> capacity -> tables -> backfills
-> validation (-> CSV bundle). Every failure is a GenerationError.
"""

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence, Union

from dcloneb.generate.backfill_exec import run_backfills
from dcloneb.generate.capacity import check_capacity
from dcloneb.generate.config import GenerationConfig, load_config, parse_config, resolve_rows
from dcloneb.generate.engine import GeneratedData
from dcloneb.generate.engine import generate_tables as _generate
from dcloneb.generate.export import export_bundle, validated
from dcloneb.generate.plan_input import LoadedPlan, load_plan, parse_plan
from dcloneb.generate.rules.contract import RuleSet, load_rules, parse_rules
from dcloneb.generate.rules.hook import rules_hook
from dcloneb.generate.rules.preflight import NormalizedRules, preflight
from dcloneb.generate.strategy import GenerationPlan, PlanHook, build_generation_plan
from dcloneb.generate.support import check_support
from dcloneb.plan import analyze

MAKE_DEFAULTS = {"seed": 42, "default_rows": 100}

PlanInput = Union[LoadedPlan, dict, str, Path]
ConfigInput = Union[GenerationConfig, dict, str, Path]
RulesInput = Union[RuleSet, dict, str, Path]


@dataclass(frozen=True)
class Result:
    out: Path
    manifest: dict


def _plan(plan: PlanInput) -> LoadedPlan:
    if isinstance(plan, LoadedPlan):
        return plan
    return parse_plan(plan) if isinstance(plan, dict) else load_plan(Path(plan))


def _config(config: ConfigInput) -> GenerationConfig:
    if isinstance(config, GenerationConfig):
        return config
    return parse_config(config) if isinstance(config, dict) else load_config(Path(config))


def _rules(rules: RulesInput) -> RuleSet:
    if isinstance(rules, RuleSet):
        return rules
    return parse_rules(rules) if isinstance(rules, dict) else load_rules(Path(rules))


def preflight_rules(plan: PlanInput, rules: RulesInput, config: Optional[ConfigInput] = None) -> NormalizedRules:
    """Validate and normalize rules against a plan without generating or writing anything. With a
    config, row counts are known and capacity is checked too. A future MCP tool calls this."""
    loaded = _plan(plan)
    check_support(loaded)
    rows = None
    if config is not None:
        rows = resolve_rows(_config(config), [t.name for t in loaded.schema.tables])
    return preflight(loaded, _rules(rules), rows)


def _prepare(plan: PlanInput, config: ConfigInput, plan_hooks: Sequence[PlanHook], rules: Optional[RulesInput]
             ) -> tuple[LoadedPlan, GenerationConfig, GenerationPlan, Optional[NormalizedRules]]:
    """Support check, then (with rules) preflight against the config's row counts, then the generation plan
    with the rules hook first, then generator capacity."""
    loaded, cfg = _plan(plan), _config(config)
    check_support(loaded)
    normalized, hooks = None, list(plan_hooks)
    if rules is not None:
        rows = resolve_rows(cfg, [t.name for t in loaded.schema.tables])
        normalized = preflight(loaded, _rules(rules), rows)
        hooks = [rules_hook(normalized), *hooks]
    generation = build_generation_plan(loaded, cfg, hooks)
    check_capacity(generation)
    return loaded, cfg, generation, normalized


def generate_tables(plan: PlanInput, config: ConfigInput, rules: Optional[RulesInput] = None,
                    plan_hooks: Sequence[PlanHook] = ()) -> GeneratedData:
    """Generate and validate every table in memory (schema constraints and every rule); nothing is written."""
    loaded, _, generation, normalized = _prepare(plan, config, plan_hooks, rules)
    data = run_backfills(generation, _generate(generation))
    validated(loaded, generation, data, normalized)
    return data


def generate(plan: PlanInput, config: ConfigInput, out: Union[str, Path], force: bool = False,
             rules: Optional[RulesInput] = None, plan_hooks: Sequence[PlanHook] = (),
             extra_files: Optional[dict[str, str]] = None, manifest_extra: Optional[dict] = None) -> Result:
    """Generate, validate, and publish the CSV bundle at `out` (see export.export_bundle). `extra_files` and
    `manifest_extra` add files and manifest sections (the MCP server records plan.json and the approval)."""
    return _bundle(_plan(plan), config, out, force, plan_hooks, rules, extra_files, manifest_extra)


def _bundle(loaded: LoadedPlan, config: ConfigInput, out: Union[str, Path], force: bool, plan_hooks: Sequence[PlanHook],
            rules: Optional[RulesInput], extra_files: Optional[dict[str, str]] = None,
            manifest_extra: Optional[dict] = None) -> Result:
    loaded, cfg, generation, normalized = _prepare(loaded, config, plan_hooks, rules)
    data = run_backfills(generation, _generate(generation))
    return Result(Path(out), export_bundle(Path(out), loaded, generation, cfg, data, force, extra_files, normalized,
                                           manifest_extra))


def make(ddl: str, out: Union[str, Path] = "generated", rows: Optional[int] = None, seed: Optional[int] = None,
         config: Optional[ConfigInput] = None, force: bool = False, rules: Optional[RulesInput] = None,
         plan_hooks: Sequence[PlanHook] = ()) -> Result:
    """DDL text straight to a CSV bundle: analyze (PostgreSQL), then generate. Defaults: 100 rows per
    table, seed 42. `config` (a generation.json path or dict) sets the rest; `rows`/`seed` override it.
    The plan is kept in the bundle as plan.json, and accepted rules as rules.json."""
    plan_text = analyze(ddl, "postgres").to_json()
    loaded = parse_plan(json.loads(plan_text), hashlib.sha256(plan_text.encode("utf-8")).hexdigest())
    base = {} if config is None else (config if isinstance(config, dict) else _config(config).raw)
    settings = {**MAKE_DEFAULTS, **base}
    if rows is not None:
        settings["default_rows"] = rows
    if seed is not None:
        settings["seed"] = seed
    return _bundle(loaded, settings, out, force, plan_hooks, rules, {"plan.json": plan_text})
